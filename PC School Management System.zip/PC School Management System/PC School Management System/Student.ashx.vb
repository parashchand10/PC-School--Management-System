﻿Imports System.Web
Imports System.Web.Services
Imports System.Data.OleDb

Public Class Student1
    Implements System.Web.IHttpHandler

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        Dim id As Integer = context.Request.QueryString("ID").ToString

        Dim fileName As String = 0

        Dim dt As DataTable = New DataTable

        Dim sql = "SELECT [Photo],[Data],[Contenttype] FROM [Admission] WHERE [Admission_ID]=@ID"
        cmd = New OleDbCommand(sql, conn)
        cmd.Parameters.Add("@ID", OleDbType.Integer).Value = id


        If conn.State = ConnectionState.Closed Then
            cmd.Connection.Open()

            Dim reader As OleDbDataReader = cmd.ExecuteReader
            dt.Load(reader)
            Dim name As String = dt.Rows(0)("Photo").ToString()
            Dim documentbytes As Byte() = dt.Rows(0)("Data")
            Dim contenttype As String = dt.Rows(0)("Contenttype").ToString()

            context.Response.Buffer = True
            context.Response.Charset = ""

            If context.Request.QueryString("download") = "1" Then
                context.Response.AppendHeader("Content-Disposition", "attachment; filename=" & fileName)
            End If

            context.Response.Cache.SetCacheability(HttpCacheability.NoCache)
            context.Response.ContentType = "image/Jpeg"
            context.Response.BinaryWrite(documentbytes)
            context.Response.Flush()
            context.Response.End()
        End If

    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class