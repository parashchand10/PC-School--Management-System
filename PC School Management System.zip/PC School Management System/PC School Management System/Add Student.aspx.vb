﻿Imports System.Data.OleDb

Public Class Add_Student
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Dim a As Integer = Trim(DateTime.Now.Year.ToString().Substring(2))
        txtyear.Text = a
        Call classst()
        Call student()


        If Not IsPostBack Then

            BindGrid1()
        End If

      
        GridView1.Columns(8).Visible = False
        GridView1.Columns(17).Visible = False
        GridView1.Columns(18).Visible = False

        txtStudentID.Visible = False
        txtClasss.Visible = False
        txtClasssID.Visible = False
        txtD.Visible = False
        txtDiv.Visible = False
        txtDivNum.Visible = False
        txtyear.Visible = False
        TextBox1.Visible = False

    End Sub

    'Bind Data with GridView Control
    Private Sub BindGrid1()
        Dim sql = "SELECT a.Admission_ID,a.Admission_Class,a.Full_Name,a.Class_ID,a.Photo,a.Contenttype,a.Data,a.Email_ID,a.Password,a.Address,a.Caste_Category,a.Gender,a.Date_of_Birth,a.Mobile_Number,a.Father_Name,a.Mother_Name,a.Admission_Status,b.Student_Intake FROM [Admission] a,[Class] b WHERE a.Class_ID=b.Class_ID AND a.Admission_Status='UnAdmitted'"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        GridView1.DataSource = cmd.ExecuteReader()
        GridView1.DataBind()
        conn.Close()

    End Sub

    Private Sub student()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(50000, 90000)  ' Get random numbers 
        txtStudentID.Text = intResult.ToString
    End Sub

    Private Sub classst()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddAdmissionClass.DataSource = cmd.ExecuteReader()
                ddAdmissionClass.DataTextField = "Class_Standard"

                ddAdmissionClass.DataBind()
                conn.Close()
            End Using

            ddAdmissionClass.Items.Insert(0, New ListItem("--Select Class--", "0"))
        End If
    End Sub

    Public Sub gets()


        If Not IsPostBack Then
            Dim sql1 = "SELECT Student_Roll_Number FROM Student"
            cmd = New OleDbCommand(sql1, conn)

            conn.Open()
            Dim r As OleDbDataReader = cmd.ExecuteReader

            If (r.HasRows) Then
                If (r.Read()) Then
                    txtD.Text = r("Student_Roll_Number").ToString()
                Else
                    txtClasss.Text = "No rows found!"
                End If
            End If

            r.Close()
            conn.Close()

        End If



    End Sub

    Protected Sub ddAdmissionClass_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddAdmissionClass.SelectedIndexChanged

        Dim dt As New DataTable()

        conn.Open()
        If ddAdmissionClass.SelectedValue <> "" Then
            Dim cmd As New OleDb.OleDbCommand("SELECT a.Admission_ID,a.Admission_Class,a.Full_Name,a.Class_ID,a.Photo,a.Contenttype,a.Data,a.Email_ID,a.Password,a.Address,a.Caste_Category,a.Gender,a.Date_of_Birth,a.Mobile_Number,a.Father_Name,a.Mother_Name,a.Admission_Status,b.Student_Intake FROM [Admission] a,[Class] b WHERE a.Class_ID=b.Class_ID AND a.Admission_Status='UnAdmitted' AND b.Class_Standard=@Book", conn)
            cmd.Parameters.AddWithValue("@Book", ddAdmissionClass.SelectedValue)
            Dim da As New OleDb.OleDbDataAdapter(cmd)
            da.Fill(dt)
        End If
        conn.Close()

        GridView1.DataSource = dt
        GridView1.DataBind()

        GridView1.Visible = True

        If ddAdmissionClass.SelectedValue = "Playgroup" Then
            txtClasss.Text = 1
            txtD.Text = txtyear.Text + txtClasss.Text
        ElseIf ddAdmissionClass.SelectedValue = "Nursery" Then
            txtClasss.Text = 2
            txtD.Text = txtyear.Text + txtClasss.Text
        End If

        txtClasss.Text = txtDiv.Text
        Dim number As String = TextBox1.Text


    End Sub


    Protected Sub cmdAdd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdAdd.Click

        For Each gvrow As GridViewRow In GridView1.Rows
            Dim checkbox = TryCast(gvrow.FindControl("CheckBox1"), CheckBox)

            If checkbox.Checked Then
                Dim lblIntake = TryCast(gvrow.FindControl("lblIntake"), Label)
                Dim lbladds = TryCast(gvrow.FindControl("lblSNo"), Label)
                Dim lblstud = TryCast(gvrow.FindControl("Label4"), Label)
                Dim lblrno = TryCast(gvrow.FindControl("lblrno"), Label)
                Dim lblstd = TryCast(gvrow.FindControl("Label2"), Label)
                Dim lbladd = TryCast(gvrow.FindControl("Label1"), Label)
                Dim lblclass = TryCast(gvrow.FindControl("Label3"), Label)
                Dim lblPhoto = TryCast(gvrow.FindControl("lblPhoto"), Label)
                Dim lblData = TryCast(gvrow.FindControl("lblData"), Label)
                Dim lbltype = TryCast(gvrow.FindControl("lbltype"), Label)

                Dim lblEmail = TryCast(gvrow.FindControl("lblEmail"), Label)
                Dim lblPassword = TryCast(gvrow.FindControl("lblPassword"), Label)
                Dim lblAddress = TryCast(gvrow.FindControl("lblAddress"), Label)
                Dim lblCasteCategory = TryCast(gvrow.FindControl("lblCaste"), Label)
                Dim lblGender = TryCast(gvrow.FindControl("lblGender"), Label)
                Dim lblDateofBirth = TryCast(gvrow.FindControl("lblDateofBirth"), Label)
                Dim lblNumber = TryCast(gvrow.FindControl("lblNumber"), Label)
                Dim lblFatherName = TryCast(gvrow.FindControl("lblFatherName"), Label)
                Dim lblMotherName = TryCast(gvrow.FindControl("lblMotherName"), Label)
                Dim lblAdmissionStatus = TryCast(gvrow.FindControl("lblAdmissionStatus"), Label)

                If lblIntake.Text = "0" Then
                    MsgBox("Class Admission is Full. Please Choose Another Class", vbInformation)
                Else

                    Dim sql2 = "update [Class] set Student_Intake=" & lblIntake.Text - 1 & " where Class_ID=" & lblclass.Text & ""
                    cmd = New OleDbCommand(sql2, conn)

                    'ADD PARAMETERS

                    cmd.Parameters.AddWithValue("@Student_Intake", lblIntake.Text)

                    'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION

                    conn.Open()
                    cmd.ExecuteScalar()
                    conn.Close()

                    Dim sql = "update [Admission] set Admission_Status='" & ddSelect.Text & "' where Admission_ID=" & lbladd.Text & ""
                    cmd = New OleDbCommand(sql, conn)

                    'ADD PARAMETERS

                    cmd.Parameters.AddWithValue("@Admission_Status", lblAdmissionStatus.Text.Trim())

                    conn.Open()
                    cmd.ExecuteScalar()
                    conn.Close()


                    cmd = New OleDbCommand("insert into Student (Student_Roll_Number,Student_Name,Admission_ID,Class_ID,Photo,Data,Contenttype,Student_Email_ID,Student_Password,Student_Address,Student_Caste,Student_Gender,Student_Date_of_Birth,Student_Mobile_Number,Student_Father_Name,Student_Mother_Name) values (@Student_Roll_Number,@Student_Name,@Admission_ID,@Class_ID,@Photo,@Data,@Contenttype,@Student_Email_ID,@Student_Password,@Student_Address,@Student_Caste,@Student_Gender,@Student_Date_of_Birth,@Student_Mobile_Number,@Student_Father_Name,@Student_Mother_Name)", conn)

                    cmd.Parameters.AddWithValue("Student_Roll_Number", Trim(txtD.Text + lblrno.Text))
                    cmd.Parameters.AddWithValue("Student_Name", Trim(lblstud.Text))

                    cmd.Parameters.AddWithValue("Admission_ID", Trim(lbladd.Text))
                    cmd.Parameters.AddWithValue("Class_ID", Trim(lblclass.Text))
                    cmd.Parameters.AddWithValue("Photo", Trim(lblPhoto.Text))
                    cmd.Parameters.AddWithValue("Data", Trim(lblData.Text))
                    cmd.Parameters.AddWithValue("Contenttype", Trim(lbltype.Text))
                    cmd.Parameters.AddWithValue("Student_Email_ID", Trim(lblEmail.Text))
                    cmd.Parameters.AddWithValue("Student_Password", Trim(lblPassword.Text))
                    cmd.Parameters.AddWithValue("Student_Address", Trim(lblAddress.Text))
                    cmd.Parameters.AddWithValue("Student_Caste", Trim(lblCasteCategory.Text))
                    cmd.Parameters.AddWithValue("Student_Gender", Trim(lblGender.Text))
                    cmd.Parameters.AddWithValue("Student_Date_of_Birth", Trim(lblDateofBirth.Text))
                    cmd.Parameters.AddWithValue("Student_Mobile_Number", Trim(lblNumber.Text))
                    cmd.Parameters.AddWithValue("Student_Father_Name", Trim(lblFatherName.Text))
                    cmd.Parameters.AddWithValue("Student_Mother_Name", Trim(lblMotherName.Text))


                    'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
                    conn.Open()
                    If cmd.ExecuteNonQuery() > 0 Then
                        Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                        Dim meta As New HtmlMeta()
                        meta.HttpEquiv = "Refresh"
                        meta.Content = "0;url=Add Student.aspx"
                        Me.Page.Header.Controls.Add(meta)
                    End If
                    conn.Close()


                End If
            End If
        Next

    End Sub

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

  
End Class