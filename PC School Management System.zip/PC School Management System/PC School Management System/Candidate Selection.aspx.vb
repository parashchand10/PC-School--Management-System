﻿Imports System.Data.OleDb

Public Class Candidate_Selection
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call vacancy()


        If Not IsPostBack Then

            BindGrid1()
        End If
    End Sub

    Private Sub BindGrid1()
        Dim sql = "SELECT a.Candidate_ID,a.Candidate_Name,a.Candidate_Status,b.Vacancy_Designation FROM [Candidate] a,[Vacancy] b WHERE b.Vacancy_ID=a.Vacancy_ID AND a.Candidate_Status='In Progress'"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        GridView1.DataSource = cmd.ExecuteReader()
        GridView1.DataBind()
        conn.Close()

    End Sub

    Private Sub vacancy()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT Vacancy_Designation FROM [Vacancy]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddDesignation.DataSource = cmd.ExecuteReader()
                ddDesignation.DataTextField = "Vacancy_Designation"


                ddDesignation.DataBind()
                conn.Close()
            End Using

            ddDesignation.Items.Insert(0, New ListItem("--Select--", "0"))
        End If
    End Sub

    Protected Sub ddDesignation_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddDesignation.SelectedIndexChanged
        Dim dt As New DataTable()

        conn.Open()
        If ddDesignation.SelectedValue <> "" Then
            Dim cmd As New OleDb.OleDbCommand("SELECT a.Candidate_ID,a.Candidate_Name,a.Candidate_Status,b.Vacancy_Designation FROM [Candidate] a,[Vacancy] b WHERE b.Vacancy_ID=a.Vacancy_ID AND a.Candidate_Status='In Progress' AND b.Vacancy_Designation=@class", conn)
            cmd.Parameters.AddWithValue("@Class", ddDesignation.SelectedValue)
            Dim da As New OleDb.OleDbDataAdapter(cmd)
            da.Fill(dt)
        End If
        conn.Close()
        GridView1.DataSource = dt
        GridView1.DataBind()

    End Sub

   
    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        For Each gvrow As GridViewRow In GridView1.Rows
            Dim checkbox = TryCast(gvrow.FindControl("CheckBox1"), CheckBox)

            If checkbox.Checked Then
                Dim lblCandidatID = TryCast(gvrow.FindControl("lblCandidatID"), Label)
                Dim lblCandidateStatus = TryCast(gvrow.FindControl("lblCandidateStatus"), Label)


                Dim sql2 = "update Candidate set Candidate_Status='" & ddSelect.Text & "' where Candidate_ID=" & lblCandidatID.Text & ""
                cmd = New OleDbCommand(sql2, conn)
                'ADD PARAMETERS

                cmd.Parameters.AddWithValue("@Candidate_Status", lblCandidateStatus.Text)

                'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION

                conn.Open()

                If cmd.ExecuteNonQuery() > 0 Then

                    Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Candidate Selection.aspx"
                    Me.Page.Header.Controls.Add(meta)

                End If
                conn.Close()
            End If

        Next

    End Sub

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Public Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridView1.SelectedIndexChanged
        For Each gvrow As GridViewRow In GridView1.Rows
            Dim checkbox = TryCast(gvrow.FindControl("CheckBox1"), CheckBox)

            If checkbox.Checked Then
                Dim lblCandidatID = TryCast(gvrow.FindControl("lblCandidatID"), Label)
                Dim lbladds = TryCast(gvrow.FindControl("lblSNo"), Label)


        conn.Open()
                Dim com As OleDb.OleDbCommand = New OleDb.OleDbCommand("select CandidateResume,CandidateContenttype,CandidateData from Candidate where Candidate_ID=" & lblCandidatID.Text & "", conn)
                com.Parameters.AddWithValue("lblCandidatID", GridView1.SelectedRow.Cells(1).Text)
        Dim dr As OleDb.OleDbDataReader = com.ExecuteReader()

        If dr.Read() Then
            Response.Clear()
            Response.Buffer = True
            Response.ContentType = dr("CandidateContenttype").ToString()
            Response.AddHeader("content-disposition", "attachment;filename=" & dr("CandidateResume").ToString())
            Response.Charset = ""
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.BinaryWrite(CType(dr("CandidateData"), Byte()))
            Response.[End]()
                End If

            End If
        Next

        Response.Redirect(Request.Url.AbsoluteUri)

    End Sub

End Class