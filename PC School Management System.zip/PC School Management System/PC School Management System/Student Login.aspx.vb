﻿Imports System.Data.OleDb
Imports System.Drawing

Public Class Student_Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call type()

        lblStudent.Visible = False
        txtStudentID.Visible = False

    End Sub

    Protected Sub lbForgotPassword_Click(ByVal sender As Object, ByVal e As EventArgs) Handles lbForgotPassword.Click
        Response.Redirect("Forgot Password.aspx")
    End Sub

    Private Sub type()
         Dim sql1 = "SELECT Student_ID FROM Student WHERE Student_Email_ID='" & txtEmailID.Text & "' AND Student_Password='" & txtPassword.Text & "'"
        cmd = New OleDbCommand(sql1, conn)

        conn.Open()
        Dim r As OleDbDataReader = cmd.ExecuteReader

        If (r.HasRows) Then
            If (r.Read()) Then
                txtStudentID.Text = r("Student_ID").ToString()
            Else
                txtStudentID.Text = "No rows found!"
            End If
        End If

        r.Close()
        conn.Close()

    End Sub

    Protected Sub cmdLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdLogin.Click

        Try
            Dim cmd As New OleDbCommand("select * from Student where Student_ID=@Student_ID and Student_Email_ID =@Student_Email_ID and Student_Password=@Student_Password", conn)
            cmd.Parameters.AddWithValue("@Student_ID", txtStudentID.Text)
            cmd.Parameters.AddWithValue("@username", txtEmailID.Text)
            cmd.Parameters.AddWithValue("@password", txtPassword.Text)
            Dim da As New OleDbDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then

                Response.Write("<script language=""javascript"">alert('Login Successfully');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Student.aspx?tmp1=" + txtStudentID.Text
                Me.Page.Header.Controls.Add(meta)
            Else
                Response.Write("<script language=""javascript"">alert('Invalid Login');</script>")
            End If

        Catch ex As Exception

        End Try
        conn.Close()

    End Sub

    Protected Sub CheckBox1_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            Dim pass As String = txtPassword.Text
            txtPassword.TextMode = TextBoxMode.Password
            txtPassword.Attributes.Add("value", pass)
        End If

        If CheckBox1.Checked Then
            txtPassword.TextMode = TextBoxMode.SingleLine
        End If
    End Sub

    Protected Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class