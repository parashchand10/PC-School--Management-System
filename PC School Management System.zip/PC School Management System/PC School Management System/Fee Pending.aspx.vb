﻿Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Web

Public Class Fee_Pending
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call classst()
        Calendar1.Visible = False

    End Sub

    Private Sub classst()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddClassName.DataSource = cmd.ExecuteReader()
                ddClassName.DataTextField = "Class_Standard"

                ddClassName.DataBind()
                conn.Close()
            End Using

            ddClassName.Items.Insert(0, New ListItem("--Select Class--", "0"))
        End If
    End Sub

    Protected Sub cmdSubmit_Click(sender As Object, e As EventArgs) Handles cmdSubmit.Click
        Try

        Dim reportdocument As New ReportDocument()
        reportdocument.Load(Server.MapPath("School Fee Report.rpt"))

        reportdocument.SetParameterValue("@Class", ddClassName.Text)
        reportdocument.SetParameterValue("@Status", ddStatus.Text)
        reportdocument.SetParameterValue("@StartDate", txtStartDate.Text)
            CrystalReportViewer1.ReportSource = reportdocument

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub ImageButton1_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Calendar1.Visible = True
    End Sub

    Private Sub Calendar1_DayRender(sender As Object, e As System.Web.UI.WebControls.DayRenderEventArgs) Handles Calendar1.DayRender
        If e.Day.DayNumberText.CompareTo("1") = 1 Then
            e.Day.IsSelectable = False
        End If
    End Sub

    Protected Sub Calendar1_SelectionChanged(sender As Object, e As EventArgs) Handles Calendar1.SelectionChanged
        txtStartDate.Text = Calendar1.SelectedDate.ToShortDateString()
    End Sub

End Class