﻿Imports System.Data.OleDb

Public Class Fee
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call classstd()
      
        If Not IsPostBack Then

            BindGrid()
        End If
      
        txtStudentID.Visible = False
        txtStatus.Visible = False

    End Sub

    Private Sub BindGrid()
        Dim sql = "SELECT a.Student_ID,a.Student_Name,b.Class_ID,b.Class_Standard,c.Fee_ID,c.Quarterly_Fee,c.Fee_Start_Date,c.Fee_End_Date,c.Late_Fee,c.Total_Fee,d.Fee_Status FROM [Student] a,[Class] b,[Fee] c,[StudentClass] d WHERE a.Student_ID=d.Student_ID AND b.Class_ID=a.Class_ID AND c.Class_ID=b.Class_ID"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        GridView1.DataSource = cmd.ExecuteReader()
        GridView1.DataBind()
        conn.Close()

    End Sub

    Private Sub classstd()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddClassStandard.DataSource = cmd.ExecuteReader()
                ddClassStandard.DataTextField = "Class_Standard"

                ddClassStandard.DataBind()
                conn.Close()
            End Using

            ddClassStandard.Items.Insert(0, New ListItem("--Select Class--", "0"))
        End If
    End Sub

    Protected Sub ddClassStandard_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddClassStandard.SelectedIndexChanged

        Dim dt As New DataTable()

        conn.Open()
        If ddClassStandard.SelectedValue <> "" Then
            Dim cmd As New OleDb.OleDbCommand("SELECT a.Student_ID,a.Student_Name,b.Class_ID,b.Class_Standard,c.Fee_ID,c.Quarterly_Fee,c.Fee_Start_Date,c.Fee_End_Date,c.Late_Fee,c.Total_Fee,d.Fee_Status FROM [Student] a,[Class] b,[Fee] c,[StudentClass] d WHERE a.Student_ID=d.Student_ID AND b.Class_ID=a.Class_ID AND c.Class_ID=b.Class_ID AND b.Class_Standard=@Book", conn)
            cmd.Parameters.AddWithValue("@Book", ddClassStandard.SelectedValue)
            Dim da As New OleDb.OleDbDataAdapter(cmd)
            da.Fill(dt)
        End If
        conn.Close()

        GridView1.DataSource = dt
        GridView1.DataBind()

    End Sub

    Protected Sub CheckAll(ByVal sender As Object, ByVal e As EventArgs)
        Dim chckheader As CheckBox = CType(GridView1.HeaderRow.FindControl("CheckBox1"), CheckBox)

        For Each row As GridViewRow In GridView1.Rows
            Dim chckrw As CheckBox = CType(row.FindControl("CheckBox2"), CheckBox)

            If chckheader.Checked = True Then
                chckrw.Checked = True
            Else
                chckrw.Checked = False
            End If
        Next
    End Sub

    Protected Sub cmdFilter_Click(sender As Object, e As EventArgs) Handles cmdFilter.Click
        conn.Open()
        Dim da As OleDbDataAdapter = New OleDbDataAdapter("Select a.Student_ID,a.Student_Name,b.Class_ID,b.Class_Standard,c.Fee_ID,c.Quarterly_Fee,c.Fee_Start_Date,c.Fee_End_Date,c.Late_Fee,c.Total_Fee,d.Fee_Status FROM [Student] a,[Class] b,[Fee] c,[StudentClass] d WHERE a.Student_ID=d.Student_ID AND b.Class_ID=a.Class_ID AND c.Class_ID=b.Class_ID AND a.Student_Name like '%" & txtStudentName.Text & "%'", conn)
        Dim ds As DataSet = New DataSet()
        da.Fill(ds)
        GridView1.DataSource = ds
        GridView1.DataBind()

    End Sub
   

   
    Public Sub fees()

        For Each gvrow As GridViewRow In GridView1.Rows
            Dim checkbox = TryCast(gvrow.FindControl("CheckBox2"), CheckBox)

            If checkbox.Checked Then
                Dim lblstudid = TryCast(gvrow.FindControl("lblstudid"), Label)
                Dim lblstatus = TryCast(gvrow.FindControl("lblstatus"), Label)
                txtStudentID.Text = lblstudid.Text
            End If

            If checkbox.Checked Then

                Dim lblstatus = TryCast(gvrow.FindControl("lblstatus"), Label)

            End If

        Next

    End Sub

    Private Sub GridView1_RowCommand(sender As Object, e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView1.RowCommand
        For Each gvrow As GridViewRow In GridView1.Rows
            Dim checkbox = TryCast(gvrow.FindControl("CheckBox2"), CheckBox)

          
            If checkbox.Checked Then

                Dim lblstatus = TryCast(gvrow.FindControl("lblstatus"), Label)
                txtStatus.Text = lblstatus.Text
                If e.CommandName = "Payment" And txtStatus.Text = "Paid" Then
                    '  Dim id As Integer = Convert.ToInt32(e.CommandArgument)

                    Response.Write("<script language=""javascript"">alert('Already Paid');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Fee.aspx"
                    Me.Page.Header.Controls.Add(meta)

                ElseIf e.CommandName = "Payment" And txtStatus.Text = "Fee Pending" Then

                    Call fees()
                    Response.Redirect("Fee Detail.aspx?tmp1=" + txtStudentID.Text)
                End If
            End If

         

            If e.CommandName = "Print" Then
                '  Dim id As Integer = Convert.ToInt32(e.CommandArgument)
                Call fees()
                Response.Redirect("Student Fee Receipt.aspx?tmp1=" + txtStudentID.Text)
            End If

        Next

    End Sub


    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridView1.SelectedIndexChanged

    End Sub
End Class