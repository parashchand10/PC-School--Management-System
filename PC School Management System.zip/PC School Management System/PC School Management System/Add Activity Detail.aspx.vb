﻿Imports System.Data.OleDb

Public Class Add_Activity_Detail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call Activity()

        If Not IsPostBack Then

            BindGrid()
        End If
        grid.Columns(0).Visible = False

        Calendar1.Visible = False
        Calendar2.Visible = False
        Calendar3.Visible = False

        lblActivityID.Visible = False
        txtActivityID.Visible = False
        txtActivity.Visible = False
    End Sub

    'Bind Data with GridView Control
    Private Sub BindGrid()
        Dim sql = "SELECT [Activity_ID],[Activity_Name],[Activity_Registration_Start_Date],[Activity_Registration_End_Date],[Activity_Date] FROM [School Activity]"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        grid.DataSource = cmd.ExecuteReader()
        grid.DataBind()
        conn.Close()

    End Sub

    Private Sub Activity()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(10000, 50000)  ' Get random numbers 
        txtActivity.Text = intResult.ToString
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try

        If Trim(txtActivityEndDate.Text) > Trim(txtActivityStartDate.Text) And Trim(txtActivityDate.Text) > Trim(txtActivityEndDate.Text) Then
            Dim sql = "INSERT INTO [School Activity] ([Activity_ID],[Activity_Name],[Activity_Registration_Start_Date],[Activity_Registration_End_Date],[Activity_Date]) VALUES (@Activity_ID,@Activity_Name,@Activity_Registration_Start_Date,@Activity_Registration_End_Date,[Activity_Date])"
            cmd = New OleDbCommand(sql, conn)


            'ADD PARAMETERS
            cmd.Parameters.AddWithValue("@Activity_ID", txtActivity.Text)
            cmd.Parameters.AddWithValue("@Activity_Name", txtActivityName.Text)
            cmd.Parameters.AddWithValue("@Activity_Registration_Start_Date", txtActivityStartDate.Text)
            cmd.Parameters.AddWithValue("@Activity_Registration_End_Date", txtActivityEndDate.Text)
            cmd.Parameters.AddWithValue("@Activity_Date", txtActivityDate.Text)

            'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
            Try
                conn.Open()
                If cmd.ExecuteNonQuery() > 0 Then
                    Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Add Activity Detail.aspx"
                    Me.Page.Header.Controls.Add(meta)
                End If
                conn.Close()

            Catch ex As Exception
                MsgBox(ex.Message)
                conn.Close()
            End Try
        Else
            Response.Write("<script language=""javascript"">alert('Incorrect Date! Please Select Correct Date');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Add Activity Detail.aspx"
            Me.Page.Header.Controls.Add(meta)
        End If

        Catch ex As Exception

        End Try

    End Sub

    Dim sql As String

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Calendar2.Visible = True
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Calendar1.Visible = True
    End Sub

    Protected Sub Calendar2_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar2.SelectionChanged
        txtActivityEndDate.Text = Calendar2.SelectedDate.ToShortDateString()
        Calendar2.Visible = False
    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar1.SelectionChanged
        txtActivityStartDate.Text = Calendar1.SelectedDate.ToShortDateString()
        Calendar1.Visible = False
    End Sub

    Protected Sub ImageButton3_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton3.Click
        Calendar3.Visible = True
    End Sub

    Protected Sub Calendar3_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar3.SelectionChanged
        txtActivityDate.Text = Calendar3.SelectedDate.ToShortDateString()
        Calendar3.Visible = False
    End Sub

    Protected Sub grid_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles grid.SelectedIndexChanged
        Dim selectedRowIndex As Integer
        selectedRowIndex = grid.SelectedIndex
        Dim row As GridViewRow = grid.Rows(selectedRowIndex)

        txtActivityID.Text = row.Cells(0).Text
        txtActivityName.Text = row.Cells(1).Text
        txtActivityStartDate.Text = row.Cells(2).Text
        txtActivityEndDate.Text = row.Cells(3).Text
        txtActivityDate.Text = row.Cells(4).Text

    End Sub

    Private Sub grid_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grid.RowDeleting
     
        sql = "delete from [School Activity] where [Activity_ID]=" & Trim(txtActivityID.Text) & ""

        cmd = New OleDbCommand(sql, conn)


        'ADD PARAMETERS
        cmd.Parameters.AddWithValue("@Activity_ID", txtActivityID.Text)
        cmd.Parameters.AddWithValue("@Activity_Name", txtActivityName.Text)
        cmd.Parameters.AddWithValue("@Activity_Registration_Start_Date", txtActivityStartDate.Text)
        cmd.Parameters.AddWithValue("@Activity_Registration_End_Date", txtActivityEndDate.Text)
        cmd.Parameters.AddWithValue("@Activity_Date", txtActivityDate.Text)

        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Remove');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Add Activity Detail.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
            conn.Close()
        End Try

    End Sub

    Private Sub grid_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles grid.RowUpdating
        If Trim(txtActivityEndDate.Text) > Trim(txtActivityStartDate.Text) And Trim(txtActivityDate.Text) > Trim(txtActivityEndDate.Text) Then
            Dim sql = "update [School Activity] set Activity_Name='" & txtActivityName.Text & "',Activity_Registration_Start_Date='" & txtActivityStartDate.Text & "',Activity_Registration_End_Date='" & txtActivityEndDate.Text & "',Activity_Date='" & txtActivityDate.Text & "' where Activity_ID=" & txtActivityID.Text & ""
            cmd = New OleDbCommand(sql, conn)


            'ADD PARAMETERS

            cmd.Parameters.AddWithValue("@Activity_Name", txtActivityName.Text)
            cmd.Parameters.AddWithValue("@Activity_Registration_Start_Date", txtActivityStartDate.Text)
            cmd.Parameters.AddWithValue("@Activity_Registration_End_Date", txtActivityEndDate.Text)
            cmd.Parameters.AddWithValue("@Activity_Date", txtActivityDate.Text)


            'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
            Try
                conn.Open()
                If cmd.ExecuteNonQuery() > 0 Then

                    Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Add Activity Detail.aspx"
                    Me.Page.Header.Controls.Add(meta)
                End If
                conn.Close()

            Catch ex As Exception
                MsgBox(ex.Message)
                conn.Close()
            End Try
        Else

            Response.Write("<script language=""javascript"">alert('Incorrect Activity Date');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Add Activity Detail.aspx"
            Me.Page.Header.Controls.Add(meta)
        End If

    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class