﻿Imports System.Data.OleDb

Public Class Staff_Register
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call register()
        Call name()
        txtStaff.Visible = False

        If Not IsPostBack Then

            BindGrid()
        End If

        Label2.Visible = False
        txtRegisterID.Visible = False
        txtStaffID.Visible = False
        lblStaffID.Visible = False
        txtRegister.Visible = False

        Calendar2.Visible = False
    End Sub

    Private Sub register()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(20000, 90000)  ' Get random numbers 
        txtRegisterID.Text = intResult.ToString
    End Sub

    'Bind Data with GridView Control
    Private Sub BindGrid()
        Dim sql = "SELECT b.Register_ID,a.Staff_ID,a.Staff_Name,b.Register_Date,b.Attendance_Type FROM [Staff] a,[Register] b WHERE a.Staff_ID=b.Staff_ID"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        grid.DataSource = cmd.ExecuteReader()
        grid.DataBind()
        conn.Close()

    End Sub

    Private Sub name()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT Staff_Name FROM [Staff] WHERE Post='Teacher' OR Post='Non Teaching Staff'")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddStaffName.DataSource = cmd.ExecuteReader()
                ddStaffName.DataTextField = "Staff_Name"

                ddStaffName.DataBind()
                conn.Close()
            End Using
            ddStaffName.Items.Insert(0, New ListItem("--Select Staff Name--", "0"))
        End If
    End Sub

    Private Sub Insert(ByVal name As String, ByVal country As Date, ByVal country1 As String, ByVal country2 As Integer)

        Using cmd As OleDbCommand = New OleDbCommand("INSERT INTO [Register] VALUES (@Register_ID,@Register_Date,@Attendance_Type,@Staff_ID)", conn)
            cmd.CommandType = CommandType.Text

            cmd.Parameters.AddWithValue("@Register_ID", name)
            cmd.Parameters.AddWithValue("@Register_Date", country)
            cmd.Parameters.AddWithValue("@Attendance_Type", country1)
            cmd.Parameters.AddWithValue("@Staff_ID", country2)

            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
        End Using

    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try

            Using cmd As OleDbCommand = New OleDbCommand("SELECT Staff_ID,Register_Date FROM [Register] WHERE Staff_ID=@Staff_ID AND Register_Date=@Register_Date", conn)
                cmd.CommandType = CommandType.Text
                cmd.Parameters.AddWithValue("@Staff_ID", Me.txtStaffID.Text.Trim())
                cmd.Parameters.AddWithValue("@Register_Date", Me.txtRegisterDate.Text.Trim())

                conn.Open()
                Dim result As String = Convert.ToString(cmd.ExecuteScalar())
                conn.Close()
                If String.IsNullOrEmpty(result) Then
                    Insert(Me.txtRegisterID.Text.Trim(), Me.txtRegisterDate.Text.Trim(), Me.ddType.Text.Trim(), Me.txtStaffID.Text.Trim())

                    Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Homepage.aspx"
                    Me.Page.Header.Controls.Add(meta)

                Else
                    Response.Write("<script language=""javascript"">alert('Record Already Exists');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Staff Register.aspx"
                    Me.Page.Header.Controls.Add(meta)

                End If
            End Using

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Calendar1_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles Calendar1.DayRender
       
        If e.Day.Date.DayOfWeek = DayOfWeek.Saturday OrElse e.Day.Date.DayOfWeek = DayOfWeek.Sunday Then
            e.Cell.BackColor = System.Drawing.Color.Blue
            e.Cell.ForeColor = System.Drawing.Color.Black

        End If
    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar1.SelectionChanged
        txtRegisterDate.Text = Calendar1.SelectedDate

    End Sub

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub ddStaffName_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddStaffName.SelectedIndexChanged
        Dim query As String = "select * from Staff where Staff_Name = '" & ddStaffName.Text & "'"
        cmd = New OleDbCommand(query, conn)

        Try
            conn.Open()
            Dim r As OleDbDataReader = cmd.ExecuteReader

            While r.Read()
                Dim id As String = CStr(r("Staff_ID").ToString)
                Dim name As String = CStr(r("Staff_Name").ToString)

                txtStaffID.Text = id
                ddStaffName.Text = name

                txtStaffID.Text = id

            End While

        Catch es As Exception
            MsgBox(es.Message)
        End Try
    End Sub

    Protected Sub ImageButton1_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Calendar2.Visible = True
    End Sub

    Protected Sub Calendar2_SelectionChanged(sender As Object, e As EventArgs) Handles Calendar2.SelectionChanged
        txtDate.Text = Calendar2.SelectedDate.ToShortDateString()
        Calendar2.Visible = False
    End Sub

    Protected Sub cmdFilter_Click(sender As Object, e As EventArgs) Handles cmdFilter.Click
        conn.Open()
        Dim da As OleDbDataAdapter = New OleDbDataAdapter("SELECT b.Register_ID,a.Staff_ID,a.Staff_Name,b.Register_Date,b.Attendance_Type FROM [Staff] a,[Register] b WHERE a.Staff_ID=b.Staff_ID AND a.Staff_Name like '%" & txtStaffName.Text & "%' AND b.Register_Date like '%" & txtDate.Text & "%'", conn)
        Dim ds As DataSet = New DataSet()
        da.Fill(ds)
        grid.DataSource = ds
        grid.DataBind()

    End Sub

    Private Sub grid_RowUpdating(sender As Object, e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles grid.RowUpdating
        Dim sql1 = "update Register set Attendance_Type='" & ddType.Text & "' where Register_ID=" & txtRegister.Text & ""
        cmd = New OleDbCommand(sql1, conn)

        'ADD PARAMETERS

        cmd.Parameters.AddWithValue("@Attendance_Type", ddType.Text)


        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then

                Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Staff Register.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()

        Catch ex As Exception

            Response.Write("<script language=""javascript"">alert('Please Select Data');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Staff Register.aspx"
            Me.Page.Header.Controls.Add(meta)
            conn.Close()
        End Try

    End Sub

    Protected Sub grid_SelectedIndexChanged(sender As Object, e As EventArgs) Handles grid.SelectedIndexChanged
        ddStaffName.Visible = False
        txtStaff.Visible = True

        txtStaff.ReadOnly = True
        txtRegisterDate.ReadOnly = True

        Dim selectedRowIndex As Integer
        selectedRowIndex = grid.SelectedIndex
        Dim row As GridViewRow = grid.Rows(selectedRowIndex)

        txtRegister.Text = row.Cells(0).Text
        txtStaff.Text = row.Cells(2).Text
        txtRegisterDate.Text = row.Cells(3).Text
        ddType.Text = row.Cells(4).Text

    End Sub

End Class