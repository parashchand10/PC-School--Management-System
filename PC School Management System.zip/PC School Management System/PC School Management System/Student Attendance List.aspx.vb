﻿Imports System.Data.OleDb

Public Class Student_Attendance_List
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call day()
    End Sub


    Private Sub day()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Staff_Name] FROM [Staff]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddStudentName.DataSource = cmd.ExecuteReader()
                ddStudentName.DataTextField = "Staff_Name"

                ddStudentName.DataBind()
                conn.Close()
            End Using

            ddStudentName.Items.Insert(0, New ListItem("--Select Day--", ""))
        End If

    End Sub

    Protected Sub ddStaffName_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddStudentName.SelectedIndexChanged
        Dim query As String = "select c.Class_ID from [Subject] a,[Staff] b,[Class] c where a.Staff_ID=b.Staff_ID and a.Class_ID=c.Class_ID and b.Staff_Name='" & ddStudentName.SelectedValue & "'"
        cmd = New OleDbCommand(query, conn)

        Try
            conn.Open()
            Dim r As OleDbDataReader = cmd.ExecuteReader

            If (r.HasRows) Then
                If (r.Read()) Then
                    txtStaffName.Text = r("Class_ID").ToString()

                End If
            End If

        Catch es As Exception
            MsgBox(es.Message)
        End Try
    End Sub
End Class