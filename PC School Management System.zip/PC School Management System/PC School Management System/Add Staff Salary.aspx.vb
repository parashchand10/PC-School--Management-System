﻿Imports System.Data.OleDb

Public Class Add_Staff_Salary
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call salary()
        Call name()

        Calendar2.Visible = False

        txtSalaryID.Visible = False
        txtStaffID.Visible = False
        txtTotalGrossSalary.Visible = False
        txtTotalDA.Visible = False
        txtTotalHRA.Visible = False
        txtGross.Visible = False
        lblSalaryID.Visible = False

    End Sub

    Private Sub salary()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(50000, 80000)  ' Get random numbers 
        txtSalaryID.Text = intResult.ToString
    End Sub

    Private Sub name()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT Staff_Name FROM [Staff] WHERE Post='Teacher' OR Post='Non Teaching Staff'")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddStaffName.DataSource = cmd.ExecuteReader()
                ddStaffName.DataTextField = "Staff_Name"

                ddStaffName.DataBind()
                conn.Close()
            End Using

            ddStaffName.Items.Insert(0, New ListItem("--Select Staff Name--", "0"))
        End If
    End Sub

    Private Sub Insert(ByVal salaryid As Integer, ByVal sdate As Date, ByVal bpay As String, ByVal glevel As Integer, ByVal ggrade As Integer, ByVal hra As Integer, ByVal da As Integer, ByVal ta As Integer, ByVal gsalary As Integer, ByVal pf As Integer, ByVal asalary As Integer, ByVal nsalary As Integer, ByVal sid As Integer)

        Using cmd As OleDbCommand = New OleDbCommand("INSERT INTO [Staff Salary] VALUES (@Salary_ID,@Salary_Date,@Basic_Pay,@Grade_Level,@Grade_Pay,@HRA,@DA,@TA,@Gross_Salary,@PF,@Additional_Deduction,@Net_Salary,@Staff_ID)", conn)
            cmd.CommandType = CommandType.Text
            cmd.Parameters.AddWithValue("@Salary_ID", salaryid)
            cmd.Parameters.AddWithValue("@Salary_Date", sdate)
            cmd.Parameters.AddWithValue("@Basic_Pay", bpay)
            cmd.Parameters.AddWithValue("@Grade_Level", glevel)
            cmd.Parameters.AddWithValue("@Grade_Pay", ggrade)
            cmd.Parameters.AddWithValue("@HRA", hra)
            cmd.Parameters.AddWithValue("@DA", da)
            cmd.Parameters.AddWithValue("@TA", ta)
            cmd.Parameters.AddWithValue("@Gross_Salary", gsalary)
            cmd.Parameters.AddWithValue("@PF", pf)
            cmd.Parameters.AddWithValue("@Additional_Deduction", asalary)
            cmd.Parameters.AddWithValue("@Net_Salary", nsalary)
            cmd.Parameters.AddWithValue("@Staff_ID", sid)

            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()

        End Using

    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try

            Using cmd As OleDbCommand = New OleDbCommand("SELECT Staff_ID,Salary_Date FROM [Staff Salary] WHERE Staff_ID=@Staff_ID AND Salary_Date=@Salary_Date", conn)
                cmd.CommandType = CommandType.Text

                cmd.Parameters.AddWithValue("@Staff_ID", Me.txtStaffID.Text.Trim())
                cmd.Parameters.AddWithValue("@Salary_Date", Me.txtToDate.Text.Trim())

                conn.Open()
                Dim result As String = Convert.ToString(cmd.ExecuteScalar())
                conn.Close()
                If String.IsNullOrEmpty(result) Then

                    Insert(Me.txtSalaryID.Text.Trim(), Me.txtToDate.Text.Trim(), Me.txtBasicPay.Text.Trim(), Me.txtGradeLevel.Text.Trim(), Me.txtGradePay.Text.Trim(), Me.txtTotalHRA.Text.Trim(), Me.txtTotalDA.Text.Trim(), Me.txtTA.Text.Trim(), Me.txtGrossSalary.Text.Trim(), Me.txtPF.Text.Trim(), Me.txtAdditionalDeduction.Text.Trim(), Me.txtNetSalary.Text.Trim(), Me.txtStaffID.Text.Trim())
                    Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Add Staff Salary.aspx"
                    Me.Page.Header.Controls.Add(meta)


                Else
                    Response.Write("<script language=""javascript"">alert('Record Already Exits');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Add Staff Salary.aspx"
                    Me.Page.Header.Controls.Add(meta)

                End If
            End Using

        Catch ex As Exception

        End Try

    End Sub

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Dim sql1 As String

    Protected Sub ddStaffName_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddStaffName.SelectedIndexChanged

        Dim query As String = "select a.Staff_ID,a.Staff_Name,a.Staff_Designation,b.Grade_Level,b.Grade_Pay,b.Basic_Pay,b.HRA,b.DA,b.TA,b.PF,b.Additional_Deduction from [Staff] a,[Staff Grade] b where a.Staff_Designation=b.Staff_Designation and a.Staff_Name= '" & ddStaffName.SelectedValue & "'"
        cmd = New OleDbCommand(query, conn)


        conn.Open()
        Dim r As OleDbDataReader = cmd.ExecuteReader
        If (r.HasRows) Then
            While r.Read()
                txtStaffID.Text = r("Staff_ID").ToString()
                ddStaffName.Text = r("Staff_Name").ToString()
                txtDesignation.Text = r("Staff_Designation").ToString()
                txtGradeLevel.Text = r("Grade_Level").ToString()
                txtGradePay.Text = r("Grade_Pay").ToString()
                txtBasicPay.Text = r("Basic_Pay").ToString()
                txtHRA.Text = r("HRA").ToString()
                txtHRA.Text = Val(txtHRA.Text) / 100
                txtDA.Text = r("DA").ToString()
                txtDA.Text = Val(txtDA.Text) / 100
                txtTA.Text = r("TA").ToString()
                txtPF.Text = r("PF").ToString()
                txtAdditionalDeduction.Text = r("Additional_Deduction").ToString()

            End While
        End If

    End Sub


    Protected Sub cmdTotal_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdTotal.Click

        If Val(txtPresent.Text) = 0 Then
          Response.Redirect(Request.Url.AbsoluteUri)

        End If

        txtTotalHRA.Text = Val(txtBasicPay.Text) * Val(txtHRA.Text)
        txtTotalDA.Text = Val(txtBasicPay.Text) * Val(txtDA.Text)
        txtGross.Text = Val(txtBasicPay.Text) + Val(txtTotalHRA.Text) + Val(txtGradePay.Text) + Val(txtTotalDA.Text)
        txtGrossSalary.Text = Val(txtGross.Text) + Val(txtTA.Text)

        txtTotalGrossSalary.Text = Val(txtGrossSalary.Text) / Val(txtDate.Text) * Val(txtPresent.Text)

        txtNetSalary.Text = Val(txtTotalGrossSalary.Text) - Val(txtPF.Text) - Val(txtAdditionalDeduction.Text)

    End Sub

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Calendar2.Visible = True
    End Sub

    Private Sub Calendar2_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles Calendar2.DayRender

        If e.Day.Date.DayOfWeek = DayOfWeek.Sunday Then
            e.Cell.BackColor = System.Drawing.Color.Blue
            e.Cell.ForeColor = System.Drawing.Color.Black
            e.Cell.Font.Bold = True

        End If

        If e.Day.DayNumberText.CompareTo("1") = 1 Then
            e.Day.IsSelectable = False
        End If

    End Sub

    Protected Sub Calendar2_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar2.SelectionChanged
        txtFromDate.Text = Calendar2.SelectedDate.ToShortDateString()
        Calendar2.Visible = False

        Dim startOfNewYear As DateTime = txtFromDate.Text
        Dim startOfFirstQuarter As DateTime = startOfNewYear
        Dim startOfSecondQuarter As DateTime = startOfNewYear.AddMonths(0)
    
        Dim endOfFirstQuarter As DateTime = startOfSecondQuarter.AddMonths(1).AddDays(-1)

        txtFromDate.Text = startOfFirstQuarter
        txtToDate.Text = endOfFirstQuarter

        txtDate.Text = Val(txtToDate.Text) - Val(txtFromDate.Text) + 1

            Dim sql1 = "SELECT Count(Attendance_Type) as Attendance_Type FROM Register WHERE Attendance_Type='Present' AND Staff_ID=" & txtStaffID.Text & " AND Register_Date BETWEEN @FromDate And @ToDate"
            cmd = New OleDbCommand(sql1, conn)
            cmd.Parameters.AddWithValue("FromDate", OleDbType.Date).Value = txtFromDate.Text
            cmd.Parameters.AddWithValue("ToDate", OleDbType.Date).Value = txtToDate.Text

            Try
                conn.Open()
                Dim r As OleDbDataReader = cmd.ExecuteReader

                If (r.HasRows) Then
                    If (r.Read()) Then
                        txtPresent.Text = r("Attendance_Type").ToString()

                    Else
                        txtPresent.Text = "No rows found!"
                    End If
                End If

                r.Close()

            Catch ex As Exception
                Response.Write("<script language=""javascript"">alert('Please Select Staff Name');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Add Staff Salary.aspx"
                Me.Page.Header.Controls.Add(meta)
                conn.Close()
            End Try

    End Sub

    Protected Sub cmdRefresh_Click(sender As Object, e As EventArgs) Handles cmdRefresh.Click
      Response.Redirect(Request.Url.AbsoluteUri)
    End Sub

End Class