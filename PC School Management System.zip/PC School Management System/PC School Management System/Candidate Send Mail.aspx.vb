﻿Imports System.Data.OleDb
Imports System.Net.Mail

Public Class Candidate_Send_Mail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection() 'call connection from PC School file
        Call selectclass()
    End Sub

    Private Sub selectclass()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Candidate_Email_ID] FROM [Candidate] WHERE Candidate_Status='In progress'") 'fetching data from database candidate table, check status of candidate
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open() 'open the connection i.e from database fething the data
                ddCandidateEmailID.DataSource = cmd.ExecuteReader()
                ddCandidateEmailID.DataTextField = "Candidate_Email_ID" 'textbox id name

                ddCandidateEmailID.DataBind() 'bind the data source in the textbox
                conn.Close() 'close the connection
            End Using
            ddCandidateEmailID.Items.Insert(0, New ListItem("--Select Candidate Email ID--", ""))
        End If
    End Sub


    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try
            Dim Smtp_Server As New SmtpClient 'smtp_server is an alias 
            Dim e_mail As New MailMessage()   'e_mail is an alisa
            Smtp_Server.UseDefaultCredentials = False
            Smtp_Server.Credentials = New Net.NetworkCredential("parashchand01@gmail.com", "xuwrhrhuskjodrcx") 'gmail account authencation
            Smtp_Server.Port = 587 'smtp port for transfering mail
            Smtp_Server.EnableSsl = True
            Smtp_Server.Host = "smtp.gmail.com"

            e_mail = New MailMessage()
            e_mail.From = New MailAddress(txtFrom.Text) 'sender email id
            e_mail.To.Add(txtTo.Text) 'reciver email id
            e_mail.CC.Add(txtCC.Text) 'carbon copy
            e_mail.Subject = txtSubject.Text
            e_mail.IsBodyHtml = False
            e_mail.Body = txtMessage.Text
            Smtp_Server.Send(e_mail)

            Response.Write("<script language=""javascript"">alert('Mail Sent Successfully');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Homepage.aspx"
            Me.Page.Header.Controls.Add(meta)

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Protected Sub ddCandidateEmailID_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddCandidateEmailID.SelectedIndexChanged
        For i As Integer = 0 To ddCandidateEmailID.Items.Count - 1

            If ddCandidateEmailID.Items(i).Selected Then
                txtTo.Text += ddCandidateEmailID.Items(i).Text & ","
            End If
        Next

    End Sub

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class