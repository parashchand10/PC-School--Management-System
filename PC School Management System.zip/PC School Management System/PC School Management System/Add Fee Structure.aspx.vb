﻿Imports System.Data.OleDb

Public Class Add_Fee_Structure
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call Fee()

        Call classupdate()

        lblFeeID.Visible = False
        txtFeeID.Visible = False
        txtClassID.Visible = False
        txtFee.Visible = False

        txtTotalMonth.Text = 12

        Calendar1.Visible = False
        Calendar2.Visible = False

    End Sub

    Private Sub Fee()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(10000, 50000)  ' Get random numbers 
        txtFeeID.Text = intResult.ToString
    End Sub

    Private Sub classupdate()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddUpdateClass.DataSource = cmd.ExecuteReader()
                ddUpdateClass.DataTextField = "Class_Standard"

                ddUpdateClass.DataBind()
                conn.Close()
            End Using

            ddUpdateClass.Items.Insert(0, New ListItem("--Select Class--", "0"))
        End If
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try

            If Trim(txtEndDate.Text) > Trim(txtStartDate.Text) Then
                Dim sql = "INSERT INTO [Fee] ([Fee_ID],[Class_Name],[Admission_Fee],[Re_Admission_Fee],[Tution_Fee],[Computer_Fee],[Development_Fee],[Late_Fee],[Fee_Start_Date],[Fee_End_Date],[Quarterly_Period],[Quarterly_Fee],[Fee_Amount],[Total_Fee],[Total_Month_Period],[Class_ID]) VALUES (@Fee_ID,@Class_Name,@Admission_Fee,@Re_Admission_Fee,@Tution_Fee,@Computer_Fee,@Development_Fee,@Late_Fee,@Fee_Start_Date,@Fee_End_Date,@Quarterly_Period,@Quarterly_Fee,@Fee_Amount,@Total_Fee,@Total_Month_Period,[Class_ID])"
                cmd = New OleDbCommand(sql, conn)

                cmd.Parameters.AddWithValue("@Fee_ID", txtFeeID.Text)
                cmd.Parameters.AddWithValue("@Class_Name", ddUpdateClass.Text)
                cmd.Parameters.AddWithValue("@Admission_Fee", txtAdmissionFee.Text)
                cmd.Parameters.AddWithValue("@Re_Admission_Fee", txtReAdmissionFee.Text)
                cmd.Parameters.AddWithValue("@Tution_Fee", txtTutionFee.Text)
                cmd.Parameters.AddWithValue("@Computer_Fee", txtComputerFee.Text)
                cmd.Parameters.AddWithValue("@Development_Fee", txtDevelopmentFee.Text)
                cmd.Parameters.AddWithValue("@Late_Fee", txtLateFee.Text)
                cmd.Parameters.AddWithValue("@Fee_Start_Date", txtStartDate.Text)
                cmd.Parameters.AddWithValue("@Fee_End_Date", txtEndDate.Text)
                cmd.Parameters.AddWithValue("@Quarterly_Period", txtQuarterlyPeriod.Text)
                cmd.Parameters.AddWithValue("@Quarterly_Fee", txtQuarterlyFee.Text)
                cmd.Parameters.AddWithValue("@Fee_Amount", txtFeeAmount.Text)
                cmd.Parameters.AddWithValue("@Total_Fee", txtTotalFee.Text)
                cmd.Parameters.AddWithValue("@Total_Month_Period", txtTotalMonth.Text)
                cmd.Parameters.AddWithValue("@Class_ID", txtClassID.Text)
                conn.Open()
                If cmd.ExecuteNonQuery() > 0 Then
                    Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Add Fee Structure.aspx"
                    Me.Page.Header.Controls.Add(meta)
                End If
                conn.Close()

            Else

                Response.Write("<script language=""javascript"">alert('Incorrect Date! Please Select Correct Date');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Add Fee Structure.aspx"
                Me.Page.Header.Controls.Add(meta)
            End If

        Catch ex As Exception

        End Try

    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Calendar1.Visible = True
    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar1.SelectionChanged
        txtStartDate.Text = Calendar1.SelectedDate.ToShortDateString()
        Calendar1.Visible = False
    End Sub


    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Calendar2.Visible = True
    End Sub

    Protected Sub Calendar2_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar2.SelectionChanged
        txtEndDate.Text = Calendar2.SelectedDate.ToShortDateString()
        Calendar2.Visible = False
    End Sub

    Protected Sub cmdCalculate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCalculate.Click
        txtTotalFee.Text = (Val(txtTutionFee.Text) + Val(txtComputerFee.Text) + Val(txtDevelopmentFee.Text)) * Val(txtTotalMonth.Text)
        txtQuarterlyFee.Text = Val(txtTotalFee.Text) / Val(txtQuarterlyPeriod.Text)
        txtFeeAmount.Text = txtQuarterlyFee.Text
    End Sub

    Protected Sub ddUpdateClass_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddUpdateClass.SelectedIndexChanged
        Dim sql1 = "SELECT a.Fee_ID,a.Admission_Fee,a.Re_Admission_Fee,a.Tution_Fee,a.Computer_Fee,a.Development_Fee,a.Late_Fee,a.Fee_Start_Date,a.Fee_End_Date,a.Quarterly_Period,a.Quarterly_Fee,a.Fee_Amount,a.Total_Fee,a.Total_Month_Period FROM [Fee] a,[Class] b WHERE a.Class_ID=b.Class_ID AND b.Class_Standard='" & ddUpdateClass.SelectedValue & "'"
        cmd = New OleDbCommand(sql1, conn)

        conn.Open()
        Dim r As OleDbDataReader = cmd.ExecuteReader

        If (r.HasRows) Then
            If (r.Read()) Then
                txtFee.Text = r("Fee_ID")
                txtAdmissionFee.Text = r("Admission_Fee")
                txtReAdmissionFee.Text = r("Re_Admission_Fee")
                txtTutionFee.Text = r("Tution_Fee")
                txtComputerFee.Text = r("Computer_Fee")
                txtDevelopmentFee.Text = r("Development_Fee")
                txtLateFee.Text = r("Late_Fee")
                txtStartDate.Text = r("Fee_Start_Date").ToString
                txtEndDate.Text = r("Fee_End_Date").ToString
                txtQuarterlyPeriod.Text = r("Quarterly_Period")
                txtQuarterlyFee.Text = r("Quarterly_Fee")
                txtFeeAmount.Text = r("Fee_Amount")
                txtTotalFee.Text = r("Total_Fee")
                txtTotalMonth.Text = r("Total_Month_Period")

            Else
                Response.Redirect(Request.Url.AbsoluteUri)


            End If
        End If

        r.Close()
        conn.Close()

    End Sub

    Protected Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
        Dim sql = "update [Fee] set Admission_Fee=" & txtAdmissionFee.Text & ",Re_Admission_Fee=" & txtReAdmissionFee.Text & ",Tution_Fee=" & txtTutionFee.Text & ",Development_Fee=" & txtDevelopmentFee.Text & ",Late_Fee=" & txtLateFee.Text & ",Fee_Start_Date='" & txtStartDate.Text & "',Fee_End_Date='" & txtEndDate.Text & "',Quarterly_Period=" & txtQuarterlyPeriod.Text & ",Quarterly_Fee=" & txtQuarterlyFee.Text & ",Fee_Amount=" & txtFeeAmount.Text & ",Total_Fee=" & txtTotalFee.Text & ",Total_Month_Period=" & txtTotalMonth.Text & " where Fee_ID=" & txtFee.Text & ""
        cmd = New OleDbCommand(sql, conn)


        'ADD PARAMETERS

        cmd.Parameters.AddWithValue("@Fee_ID", txtFee.Text)

        cmd.Parameters.AddWithValue("@Admission_Fee", txtAdmissionFee.Text)
        cmd.Parameters.AddWithValue("@Re_Admission_Fee", txtReAdmissionFee.Text)
        cmd.Parameters.AddWithValue("@Tution_Fee", txtTutionFee.Text)
        cmd.Parameters.AddWithValue("@Computer_Fee", txtComputerFee.Text)
        cmd.Parameters.AddWithValue("@Development_Fee", txtDevelopmentFee.Text)
        cmd.Parameters.AddWithValue("@Late_Fee", txtLateFee.Text)
        cmd.Parameters.AddWithValue("@Fee_Start_Date", txtStartDate.Text)
        cmd.Parameters.AddWithValue("@Fee_End_Date", txtEndDate.Text)
        cmd.Parameters.AddWithValue("@Quarterly_Period", txtQuarterlyPeriod.Text)
        cmd.Parameters.AddWithValue("@Quarterly_Fee", txtQuarterlyFee.Text)
        cmd.Parameters.AddWithValue("@Fee_Amount", txtFeeAmount.Text)
        cmd.Parameters.AddWithValue("@Total_Fee", txtTotalFee.Text)
        cmd.Parameters.AddWithValue("@Total_Month_Period", txtTotalMonth.Text)

        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Add Fee Structure.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
            conn.Close()
        End Try

    End Sub

    
    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class