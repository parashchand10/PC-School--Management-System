﻿Imports System.Data.OleDb

Public Class Allocation_Class
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        'Call allocation()
        Call classstd()
        txtClassSTD.Text = ddAdmissionClass.Text

        If Not IsPostBack Then
            BindGrid()
        End If

        txtClass.Visible = False
        grid.Columns(0).Visible = False
        txtClassID.Visible = False
        txtStaffID.Visible = False
        txtSubjectID.Visible = False
        lblSubject.Visible = False
        lblClass.Visible = False
        lblStaffID.Visible = False
        txtClassSTD.Visible = False

    End Sub

    

    Private Sub BindGrid()
        Dim sql = "SELECT a.Subject_ID,a.Subject_Name,a.Class_ID,b.Class_Standard,a.Staff_ID,c.Staff_Class_Standard,c.Staff_Name FROM [Subject] a,[Class] b,[Staff] c WHERE a.Class_ID=b.Class_ID AND a.Staff_ID=c.Staff_ID"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        grid.DataSource = cmd.ExecuteReader()
        grid.DataBind()
        conn.Close()

    End Sub

    Private Sub classstd()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddAdmissionClass.DataSource = cmd.ExecuteReader()
                ddAdmissionClass.DataTextField = "Class_Standard"

                ddAdmissionClass.DataBind()
                conn.Close()
            End Using

            ddAdmissionClass.Items.Insert(0, New ListItem("--Select Class--", "0"))
        End If
    End Sub

    Private Sub allocation()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Staff_Name] FROM [Staff] WHERE Post='Teacher'")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddDesignation.DataSource = cmd.ExecuteReader()
                ddDesignation.DataTextField = "Staff_Name"

                ddDesignation.DataBind()
                conn.Close()
            End Using

            ddDesignation.Items.Insert(0, New ListItem("--Select Staff Name--", "0"))
        End If


    End Sub

    Protected Sub ddDesignation_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddDesignation.SelectedIndexChanged
        Dim sql1 = "SELECT Staff_ID,Staff_Designation,Staff_Class_Standard FROM [Staff] WHERE Staff_Name='" & ddDesignation.Text & "'"
        cmd = New OleDbCommand(sql1, conn)

        conn.Open()
        Dim r As OleDbDataReader = cmd.ExecuteReader

        If (r.HasRows) Then
            If (r.Read()) Then

                txtStaffID.Text = r("Staff_ID").ToString
                txtStaffDesignation.Text = r("Staff_Designation").ToString
                txtClass.Text = r("Staff_Class_Standard").ToString
            Else

                MsgBox("No rows found!")

            End If
        End If

        r.Close()
        conn.Close()
    End Sub

    Private Sub Insert(ByVal classid As String, ByVal staffid As String)

        Using cmd As OleDbCommand = New OleDbCommand("update Subject set Staff_ID=" & txtStaffID.Text & " where Subject_ID=" & txtSubjectID.Text & "", conn)

            cmd.CommandType = CommandType.Text


            cmd.Parameters.AddWithValue("@Staff_ID", staffid)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
        End Using

    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Using cmd As OleDbCommand = New OleDbCommand("SELECT a.Subject_ID,a.Staff_ID,c.Class_ID FROM [Subject] a,[Staff] b,[Class] c WHERE a.Class_ID=c.Class_ID and a.Staff_ID=b.Staff_ID", conn)
            cmd.CommandType = CommandType.Text

            cmd.Parameters.AddWithValue("@Subject_ID", Me.txtSubjectID.Text.Trim())
            cmd.Parameters.AddWithValue("@Staff_ID", Me.txtStaffID.Text.Trim())
            cmd.Parameters.AddWithValue("@Class_ID", Me.txtClassID.Text.Trim())

            conn.Open()

            Dim result As String = Convert.ToString(cmd.ExecuteScalar())
            conn.Close()
            If String.IsNullOrEmpty(result) Then
                Insert(Me.txtStaffID.Text.Trim(), Me.txtClassID.Text.Trim())

                Response.Write("<script language=""javascript"">alert('Assign Class Successfully');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Allocation Class.aspx"
                Me.Page.Header.Controls.Add(meta)
            Else

                Response.Write("<script language=""javascript"">alert('Record Already Exists');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Allocation Class.aspx"
                Me.Page.Header.Controls.Add(meta)
            End If
        End Using


        Dim sql = "update Subject set Staff_ID=" & txtStaffID.Text & " where Subject_ID=" & txtSubjectID.Text & ""
        cmd = New OleDbCommand(sql, conn)


        'ADD PARAMETERSS

        cmd.Parameters.AddWithValue("@Staff_ID", txtStaffID.Text)
        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION

        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then

            End If
            conn.Close()

        Catch ex As Exception

            conn.Close()
        End Try

    End Sub

    Private Sub grid_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles grid.RowUpdating
        Dim sql1 = "update Subject set Subject_Name='" & ddSubject.Text & "',Class_ID=" & txtClassID.Text & ",Staff_ID=" & txtStaffID.Text & " where Subject_ID=" & txtSubjectID.Text & ""
        cmd = New OleDbCommand(sql1, conn)

        'ADD PARAMETERS

        cmd.Parameters.AddWithValue("@Subject_ID", txtSubjectID.Text)
        cmd.Parameters.AddWithValue("@Subject_Name", ddSubject.Text)
        cmd.Parameters.AddWithValue("@Class_ID", txtClassID.Text)
        cmd.Parameters.AddWithValue("@Staff_ID", txtStaffID.Text)

        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then

                Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Allocation Class.aspx"
                Me.Page.Header.Controls.Add(meta)
            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
            conn.Close()
        End Try

    End Sub

    Protected Sub grid_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles grid.SelectedIndexChanged
        Try

            Dim selectedRowIndex As Integer
            selectedRowIndex = grid.SelectedIndex
            Dim row As GridViewRow = grid.Rows(selectedRowIndex)

            txtSubjectID.Text = row.Cells(0).Text
            ddSubject.Text = row.Cells(1).Text
            txtClassID.Text = row.Cells(2).Text
            txtStaffID.Text = row.Cells(4).Text
        Catch ex As Exception
            Response.Write("<script language=""javascript"">alert('Select Correct Class');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Allocation Class.aspx"
            Me.Page.Header.Controls.Add(meta)
        End Try

    End Sub


    Protected Sub cmdStd_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdStd.Click
        Dim sql1 = "update Staff set Staff_Class_Standard='" & txtClassSTD.Text & "' where Staff_ID=" & txtStaffID.Text & ""
        cmd = New OleDbCommand(sql1, conn)

        'ADD PARAMETERS

        cmd.Parameters.AddWithValue("@Staff_Class_Standard", txtClassSTD.Text)

        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Allocation Class.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()

        Catch ex As Exception

            conn.Close()
        End Try

    End Sub


    Protected Sub ddAdmissionClass_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddAdmissionClass.SelectedIndexChanged

        If ddAdmissionClass.SelectedValue <> "" Then

            Using cmd As New OleDbCommand("select a.Subject_Name from Subject a,Class b where a.Class_ID=b.Class_ID and b.Class_Standard='" & ddAdmissionClass.SelectedValue & "'")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddSubject.DataSource = cmd.ExecuteReader()
                ddSubject.DataTextField = "Subject_Name"

                ddSubject.DataBind()
                conn.Close()
            End Using

            ddSubject.Items.Insert(0, New ListItem("--Select Subject--", "0"))
        End If

        If ddAdmissionClass.SelectedValue <> "" Then

            Using cmd As New OleDbCommand("select c.Staff_Name from Subject a,Class b,Staff c where c.Staff_ID=a.Staff_ID and b.Class_ID=a.Class_ID and c.Post='Teacher' and b.Class_Standard='" & ddAdmissionClass.SelectedValue & "'")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()

                ddDesignation.DataSource = cmd.ExecuteReader()
                ddDesignation.DataTextField = "Staff_Name"

                ddDesignation.DataBind()
                conn.Close()

            End Using

            ddDesignation.Items.Insert(0, New ListItem("--Select Staff Name--", "0"))
        End If

        Dim sql1 = "select b.Class_ID from Subject a,Class b where a.Class_ID=b.Class_ID and b.Class_Standard='" & ddAdmissionClass.SelectedValue & "'"
        cmd = New OleDbCommand(sql1, conn)

        conn.Open()
        Dim r As OleDbDataReader = cmd.ExecuteReader

        If (r.HasRows) Then
            If (r.Read()) Then

                txtClassID.Text = r("Class_ID").ToString

            Else

                MsgBox("No rows found!")

            End If
        End If

        r.Close()
        conn.Close()

    End Sub

    Protected Sub ddSubject_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddSubject.SelectedIndexChanged

        Dim sql1 = "select a.Subject_ID from Subject a,Class b where a.Class_ID=b.Class_ID and a.Subject_Name='" & ddSubject.SelectedValue & "'"
        cmd = New OleDbCommand(sql1, conn)

        conn.Open()
        Dim r As OleDbDataReader = cmd.ExecuteReader

        If (r.HasRows) Then
            If (r.Read()) Then

                txtSubjectID.Text = r("Subject_ID").ToString

            Else

                MsgBox("No rows found!")

            End If
        End If

        r.Close()
        conn.Close()
    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class