﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Web

Public Class Student_Attendance_Report1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        txtStudentID.Text = Student.fees
        Calendar1.Visible = False
        Calendar2.Visible = False

    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try

            If txtFrom.Text >= txtTo.Text Then
                MsgBox("Date Not match")
            Else
                Dim reportdocument As New ReportDocument()
                reportdocument.Load(Server.MapPath("Student Attendance Report.rpt"))

                reportdocument.SetParameterValue("@ID", txtStudentID.Text)
                reportdocument.SetParameterValue("@FromDate", txtFrom.Text)
                reportdocument.SetParameterValue("@ToDate", txtTo.Text)
                CrystalReportViewer1.ReportSource = reportdocument
            End If
        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ImageButton1_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Calendar1.Visible = True
    End Sub

    Protected Sub ImageButton2_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Calendar2.Visible = True
    End Sub

    Protected Sub Calendar1_SelectionChanged(sender As Object, e As EventArgs) Handles Calendar1.SelectionChanged
        txtFrom.Text = Calendar1.SelectedDate.ToShortDateString()
        Calendar1.Visible = False
    End Sub

    Protected Sub Calendar2_SelectionChanged(sender As Object, e As EventArgs) Handles Calendar2.SelectionChanged
        txtTo.Text = Calendar2.SelectedDate.ToShortDateString()
        Calendar2.Visible = False
    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class