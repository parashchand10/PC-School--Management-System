﻿Imports System.Data.OleDb

Public Class Activity_Registration_Form
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call detail()
        Call ActivityForm()

        Calendar1.Visible = False
        If Not IsPostBack Then

            BindGrid()
        End If

        txtActivityRegistrationDate.Text = Date.Today
        txtActivityStartDate.Visible = False

        txtClassID.Visible = False
        txtStudentID.Visible = False
        txtActivityEndDate.Visible = False

        lblActivityID.Visible = False
        lblActivity.Visible = False
        lblStudent.Visible = False
        txtActivityID.Visible = False
        txtActivityFormID.Visible = False
        lblClassID.Visible = False
      
    End Sub

    Private Sub ActivityForm()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(10000, 50000)  ' Get random numbers 
        txtActivityFormID.Text = intResult.ToString
    End Sub

    'Bind Data with GridView Control
    Private Sub BindGrid()
        Dim sql = "SELECT Activity_ID,Activity_Name,Activity_Registration_Start_Date,Activity_Registration_End_Date,Activity_Date FROM [School Activity]"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        grid.DataSource = cmd.ExecuteReader()
        grid.DataBind()
        conn.Close()

    End Sub

    Private Sub detail()
        If Not Me.IsPostBack Then
            If Request.QueryString("tmp") IsNot Nothing AndAlso Request.QueryString("tmp") <> String.Empty Then
                txtStudentID.Text = Request.QueryString("tmp").ToString()


                Dim sql1 = "SELECT a.Student_ID,a.Student_Name,b.Class_ID FROM [Student] a,[Class] b WHERE b.Class_ID=a.Class_ID AND a.Student_ID=" & txtStudentID.Text & ""
                cmd = New OleDbCommand(sql1, conn)

                conn.Open()
                Dim r1 As OleDbDataReader = cmd.ExecuteReader

                If (r1.HasRows) Then
                    If (r1.Read()) Then
                        txtStudentID.Text = r1("Student_ID")
                        txtStudentName.Text = r1("Student_Name")
                        txtClassID.Text = r1("Class_ID")

                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r1.Close()
                conn.Close()
            End If
        End If

    End Sub

   

    Private Sub Insert(ByVal id As Integer, ByVal regdate As String, ByVal classid As Integer, ByVal studentid As String, ByVal activityid As Integer)

        Using cmd As OleDbCommand = New OleDbCommand("INSERT INTO [Activity Form]  VALUES (@Activity_Form_ID,@Activity_Registration_Date,@Class_ID,@Student_ID,@Activity_ID)", conn)
            cmd.CommandType = CommandType.Text


            cmd.Parameters.AddWithValue("@Activity_Form_ID", id)
            cmd.Parameters.AddWithValue("@Activity_Registration_Date", regdate)
            cmd.Parameters.AddWithValue("@Class_ID", classid)
            cmd.Parameters.AddWithValue("@Student_ID", studentid)
            cmd.Parameters.AddWithValue("@Activity_ID", activityid)

            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
        End Using
        
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click

        Try
            If txtActivityRegistrationDate.Text >= txtActivityEndDate.Text Or txtActivityRegistrationDate.Text <= txtActivityStartDate.Text Then
                Response.Write("<script language=""javascript"">alert('From Will Not Open ! Date will be expiry');</script>")
            Else
                Using cmd As OleDbCommand = New OleDbCommand("SELECT c.Student_ID,b.Activity_ID FROM [Activity Form] a,[School Activity] b,[Student] c WHERE c.Student_ID=c.@Student_ID AND b.Activity_ID=a.@Activity_ID", conn)
                    cmd.CommandType = CommandType.Text

                    cmd.Parameters.AddWithValue("@Student_ID", Me.txtStudentID.Text.Trim())
                    cmd.Parameters.AddWithValue("@Activity_ID", Me.txtActivityID.Text.Trim())

                    conn.Open()
                    Dim result As String = Convert.ToString(cmd.ExecuteScalar())
                    conn.Close()

                    If String.IsNullOrEmpty(result) Then
                        Insert(Me.txtActivityFormID.Text.Trim(), Me.txtActivityRegistrationDate.Text.Trim(), Me.txtClassID.Text.Trim(), Me.txtStudentID.Text.Trim(), Me.txtActivityID.Text.Trim())
                        Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                        Dim meta As New HtmlMeta()
                        meta.HttpEquiv = "Refresh"
                        meta.Content = "0;url=Homepage.aspx"
                        Me.Page.Header.Controls.Add(meta)

                    Else
                        Response.Write("<script language=""javascript"">alert('Record Already Exists');</script>")
                        Dim meta As New HtmlMeta()
                        meta.HttpEquiv = "Refresh"
                        meta.Content = "0;url=Homepage.aspx"
                        Me.Page.Header.Controls.Add(meta)

                    End If
                End Using
            End If
        Catch ex As Exception

        End Try

    End Sub


    Protected Sub grid_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles grid.SelectedIndexChanged
        Dim selectedRowIndex As Integer
        selectedRowIndex = grid.SelectedIndex
        Dim row As GridViewRow = grid.Rows(selectedRowIndex)

        txtActivityID.Text = row.Cells(0).Text
        txtActivityStartDate.Text = row.Cells(2).Text
        txtActivityEndDate.Text = row.Cells(3).Text

    End Sub

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class