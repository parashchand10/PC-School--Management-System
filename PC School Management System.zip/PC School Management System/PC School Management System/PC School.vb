﻿Imports System.Data
Imports System.Data.OleDb

Module PC_School
    Public conn As New OleDbConnection
    Public cmd As OleDbCommand

    Public Sub connection()

        Dim constring1 As String = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=E:\PC School Management System\school.mdb")
        conn = New OleDb.OleDbConnection(constring1)

    End Sub
End Module
