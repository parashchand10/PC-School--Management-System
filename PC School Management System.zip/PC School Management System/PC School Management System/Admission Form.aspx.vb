﻿Imports System.Data.OleDb
Imports System.IO

Public Class Admission_Form
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call classst()

        txtClassName.Visible = False
        txtAdmissionID.Visible = False
        lblAdmission.Visible = False
        Calendar1.Visible = False


        txtAdmissionDate.Text = Calendar1.TodaysDate.ToShortDateString()
        txtAdmissionYear.Text = Calendar1.TodaysDate.Year

        'Call stud
        txtAdmissionAmount.Text = Admission_Detail.text1
        txtFeeType.Text = Admission_Detail.txt

        Call admission()

    End Sub

    Private Sub admission()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(10000, 50000)  ' Get random numbers 
        txtAdmissionID.Text = intResult.ToString
    End Sub


    Private Sub classst()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddAdmissionClass.DataSource = cmd.ExecuteReader()
                ddAdmissionClass.DataTextField = "Class_Standard"

                ddAdmissionClass.DataBind()
                conn.Close()
            End Using

            ddAdmissionClass.Items.Insert(0, New ListItem("--Select Class--", "0"))
        End If
    End Sub

  
    Dim status As String = "UnAdmitted"

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click

            Dim filename As String = Path.GetFileName(PhotoUpload.PostedFile.FileName)
            Dim contentType As String = PhotoUpload.PostedFile.ContentType

            Using fs As Stream = PhotoUpload.PostedFile.InputStream

                Using br As BinaryReader = New BinaryReader(fs)

                    Dim bytes As Byte() = br.ReadBytes(CType(fs.Length, Int32))

                Dim sql = "INSERT INTO [Admission] ([Admission_ID],[Email_ID],[Password],[Admission_Year],[Admission_Date],[Admission_Class],[Previous_Class_Name],[Previous_Class_Result],[Previous_School_Name],[Previous_School_Address],[Full_Name],[Date_of_Birth],[Address],[Gender],[Mobile_Number],[Caste_Category],[Nationality],[Father_Name],[Mother_Name],[Father_Occupation],[Mother_Occupation],[Admission_Status],[Photo],[Data],[Contenttype],[Class_ID]) VALUES (@Admission_ID, @Email_ID,@Password,@Admission_Year,@Admission_Date,@Admission_Class,@Previous_Class_Name,@Previous_Class_Result,@Previous_School_Name,@Previous_School_Address,@Full_Name,@Date_of_Birth,@Address,@Gender,@Mobile_Number,@Caste_Category,@Nationality,@Father_Name,@Mother_Name,@Father_Occupation,@Mother_Occupation,@Admission_Status,@Photo,@Data,@Contenttype,@Class_ID)"
                    cmd = New OleDbCommand(sql, conn)


                    'ADD PARAMETERS
                cmd.Parameters.AddWithValue("@Admission_ID", txtAdmissionID.Text)
                cmd.Parameters.AddWithValue("@Email_ID", txtEmailID.Text)
                cmd.Parameters.AddWithValue("@Password", txtPassword.Text)
                cmd.Parameters.AddWithValue("@Admission_Year", txtAdmissionYear.Text)
                cmd.Parameters.AddWithValue("@Admission_Date", txtAdmissionDate.Text)
                cmd.Parameters.AddWithValue("@Admission_Class", ddAdmissionClass.Text)
                cmd.Parameters.AddWithValue("@Previous_Class_Name", txtPreviousName.Text)
                cmd.Parameters.AddWithValue("@Previous_Class_Result", ddPreviousResult.Text)
                cmd.Parameters.AddWithValue("@Previous_School_Name", txtPreviousSchool.Text)
                cmd.Parameters.AddWithValue("@Previous_School_Address", txtPreviousAddress.Text)
                cmd.Parameters.AddWithValue("@Full_Name", txtFullName.Text)
                cmd.Parameters.AddWithValue("@Date_of_Birth", txtDateofBirth.Text)
                cmd.Parameters.AddWithValue("@Address", txtAddress.Text)
                cmd.Parameters.AddWithValue("@Gender", ddGender.Text)
                cmd.Parameters.AddWithValue("@Mobile_Number", txtMobileNumber.Text)
                cmd.Parameters.AddWithValue("@Caste_Category", ddCaste.Text)
                cmd.Parameters.AddWithValue("@Nationality", txtNationality.Text)
                cmd.Parameters.AddWithValue("@Father_Name", txtFatherName.Text)
                cmd.Parameters.AddWithValue("@Mother_Name", txtMotherName.Text)
                cmd.Parameters.AddWithValue("@Father_Occupation", txtFatherOccupation.Text)
                cmd.Parameters.AddWithValue("@Mother_Occupation", txtMotherOccupation.Text)
                cmd.Parameters.AddWithValue("@Admission_Status", status)


                cmd.Parameters.Add("@Photo", OleDbType.Char).Value = filename
                cmd.Parameters.Add("@Data", OleDbType.VarBinary).Value = bytes
                cmd.Parameters.Add("@Contenttype", OleDbType.Char).Value = contentType

                cmd.Parameters.AddWithValue("@Class_ID", txtClassName.Text)
                    'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
                   
                    conn.Open()
                    If cmd.ExecuteNonQuery() > 0 Then
                    MsgBox("Successfully Added", vbInformation)
                        Call c()
                        Response.Redirect("Fee Payment.aspx?tmp2=" + txtAdmissionID.Text)


                    End If
                    conn.Close()
                End Using
            End Using

        Response.Redirect(Request.Url.AbsoluteUri)
    End Sub

    Public Shared a As String
    Public Shared b As String

    Public Sub c()
        a = txtFeeType.Text
        b = txtAdmissionAmount.Text
    End Sub

    Protected Sub ddAdmissionClass_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddAdmissionClass.SelectedIndexChanged
        If ddAdmissionClass.SelectedValue = "Playgroup" Then
            txtPreviousName.Visible = False
            txtPreviousAddress.Visible = False
            txtPreviousSchool.Visible = False
            ddPreviousResult.Visible = False
            Label30.Visible = False
            Label31.Visible = False
            Label32.Visible = False
            Label33.Visible = False

        ElseIf ddAdmissionClass.SelectedValue = "Nursery" Then
            txtPreviousName.Text = "Playgroup"
            txtPreviousName.Visible = True
            txtPreviousAddress.Visible = True
            txtPreviousSchool.Visible = True
            ddPreviousResult.Visible = True
            Label30.Visible = True
            Label31.Visible = True
            Label32.Visible = True
            Label33.Visible = True

        ElseIf ddAdmissionClass.SelectedValue = "Junior KG" Then
            txtPreviousName.Text = "Nursery"
            txtPreviousName.Visible = True
            txtPreviousAddress.Visible = True
            txtPreviousSchool.Visible = True
            ddPreviousResult.Visible = True
            Label30.Visible = True
            Label31.Visible = True
            Label32.Visible = True
            Label33.Visible = True

        ElseIf ddAdmissionClass.SelectedValue = "Senior KG" Then
            txtPreviousName.Text = "Junior KG"
            txtPreviousName.Visible = True
            txtPreviousAddress.Visible = True
            txtPreviousSchool.Visible = True
            ddPreviousResult.Visible = True
            Label30.Visible = True
            Label31.Visible = True
            Label32.Visible = True
            Label33.Visible = True

        Else
            MsgBox("Enter correct STD")
        End If


        Dim query As String = "select Class_ID from [Class] where Class_Standard='" & ddAdmissionClass.SelectedValue & "'"
        cmd = New OleDbCommand(query, conn)

        Try
            conn.Open()
            Dim r As OleDbDataReader = cmd.ExecuteReader

            If (r.HasRows) Then
                If (r.Read()) Then
                    txtClassName.Text = r("Class_ID").ToString()

                End If
            End If

        Catch es As Exception
            MsgBox(es.Message)
        End Try
    End Sub

   

    Protected Sub CheckBox1_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            Dim pass As String = txtPassword.Text
            txtPassword.TextMode = TextBoxMode.Password
            txtPassword.Attributes.Add("value", pass)
        End If

        If CheckBox1.Checked Then
            txtPassword.TextMode = TextBoxMode.SingleLine
        End If
    End Sub

    Protected Sub cmdVerify_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdVerify.Click
        If PhotoUpload.HasFile Then
            Dim FileType As String = Path.GetExtension(PhotoUpload.PostedFile.FileName).ToLower().Trim()

            If FileType <> ".jpeg" Then
                MsgBox("Image is not correct. Only .jpeg file formats are allowed.", vbInformation)
            Else
                MsgBox("Image is correct", vbInformation)
                Exit Sub
            End If
        End If
    End Sub

  
    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class