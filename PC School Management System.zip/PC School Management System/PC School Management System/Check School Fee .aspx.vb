﻿Imports System.Data.OleDb

Public Class Check_School_Fee
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call detail()

        lblAdmissionID.Visible = False
        lblClassID.Visible = False
        txtAdmissionID.Visible = False
        txtClassID.Visible = False
        txtFeeID.Visible = False
    End Sub

    Private Sub detail()
        If Not Me.IsPostBack Then
            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then
                txtStudentID.Text = Request.QueryString("tmp1").ToString()
                Image1.ImageUrl = "Student.ashx?ID=" + txtStudentID.Text
                Dim sql = "SELECT c.Fee_ID,a.Student_ID,a.Student_Email_ID,a.Student_Password,a.Student_Name,a.Student_Address,a.Student_Caste,a.Student_Gender,a.Student_Date_of_Birth,a.Student_Mobile_Number,a.Student_Class_Standard,a.Student_Father_Name,a.Student_Mother_Name,a.Photo,a.Admission_ID,a.Class_ID,b.Fee_Status FROM [Student] a,[StudentClass] b,[Fee] c,[Class] d WHERE b.Student_ID=a.Student_ID AND b.Fee_ID=c.Fee_ID AND b.Class_ID=d.Class_ID AND a.Student_ID=" & txtStudentID.Text & ""
                cmd = New OleDbCommand(sql, conn)

                conn.Open()
                Dim r As OleDbDataReader = cmd.ExecuteReader

                If (r.HasRows) Then
                    If (r.Read()) Then
                        txtStudentID.Text = r("Student_ID")
                        txtPhoto.Text = r("Photo").ToString
                        txtAdmissionID.Text = r("Admission_ID")
                        txtClassID.Text = r("Class_ID")
                        txtFeeStatus.Text = r("Fee_Status")
                        txtFeeID.Text = r("Fee_ID")

                        r.Close()
                        conn.Close()
                    End If
                End If
            End If
        End If

    End Sub

    Protected Sub cmdPayment_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdPayment.Click
        Response.Redirect("Fee Detail.aspx?tmp1=" + txtStudentID.Text)
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    
End Class