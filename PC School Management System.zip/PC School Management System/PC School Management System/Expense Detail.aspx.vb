﻿Imports System.Data.OleDb

Public Class Expense_Detail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()

        If Not IsPostBack Then

            BindGrid()
        End If
    End Sub

    Private Sub BindGrid()
        Dim sql = "SELECT [Expense_ID],[Expense_Name],[Vendor_Name],[Expense_Date],[Expense_Transaction_Type],[Expense_Amount] FROM [Expense]"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        grid.DataSource = cmd.ExecuteReader()
        grid.DataBind()
        conn.Close()

    End Sub

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click

        Response.Redirect("Homepage.aspx")
    End Sub

End Class