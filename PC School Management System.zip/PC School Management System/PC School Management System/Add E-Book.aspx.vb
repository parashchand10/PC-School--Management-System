﻿Imports System.IO
Imports System.Data.OleDb

Public Class Add_E_Book
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call Book()

        lblBookID.Visible = False
        txtBookID.Visible = False
    End Sub

    Private Sub Book()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(10000, 50000)  ' Get random numbers 
        txtBookID.Text = intResult.ToString
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click


        Dim filename As String = Path.GetFileName(BookUpload.PostedFile.FileName)
        Dim contentType As String = BookUpload.PostedFile.ContentType

        Using fs As Stream = BookUpload.PostedFile.InputStream

            Using br As BinaryReader = New BinaryReader(fs)

                Dim bytes As Byte() = br.ReadBytes(CType(fs.Length, Int32))

                Dim sql = "INSERT INTO [E_Book] ([E_Book_ID],[E_Book_Title],[E_Book_Category],[ContentType],[Data]) VALUES (@E_Book_ID,@E_Book_Title,@E_Book_Category,@ContentType,@Data)"

                cmd = New OleDbCommand(sql, conn)
                cmd.Parameters.AddWithValue("@E_Book_ID", txtBookID.Text)
                cmd.Parameters.Add("@E_Book_Title", OleDbType.Char).Value = filename
                cmd.Parameters.AddWithValue("@E_Book_Category", txtBookCategory.Text)
                cmd.Parameters.Add("@ContentType", OleDbType.Char).Value = contentType
                cmd.Parameters.Add("@Data", OleDbType.VarBinary).Value = bytes

                Try
                    conn.Open()
                    If cmd.ExecuteNonQuery() > 0 Then
                        Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                        Dim meta As New HtmlMeta()
                        meta.HttpEquiv = "Refresh"
                        meta.Content = "0;url=Add E-Book.aspx"
                        Me.Page.Header.Controls.Add(meta)

                    End If
                    conn.Close()

                Catch ex As Exception

                    conn.Close()
                End Try
            End Using
        End Using

    End Sub

    Protected Sub Button2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button2.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class