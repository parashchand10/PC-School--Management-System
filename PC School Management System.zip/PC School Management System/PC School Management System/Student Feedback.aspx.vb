﻿Imports System.Data.OleDb

Public Class Student_Feedback
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call selectclass1()

        If Not IsPostBack Then

            BindGrid1()
        End If
        GridView1.Visible = False
        GridView1.Columns(1).Visible = False
    End Sub

    Private Sub BindGrid1()
        Dim sql = "SELECT Feedback_ID,Q1,Q2,Q3,Q4,Q5,Class_Standard FROM [Student Feedback]"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        GridView1.DataSource = cmd.ExecuteReader()
        GridView1.DataBind()
        conn.Close()

    End Sub

    Private Sub selectclass1()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddClass.DataSource = cmd.ExecuteReader()
                ddClass.DataTextField = "Class_Standard"

                ddClass.DataBind()
                conn.Close()
            End Using
            ddClass.Items.Insert(0, New ListItem("--Select Class--", "0"))
        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
        Response.Redirect("Homepage.aspx")
    End Sub


   

    Protected Sub ddClass_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddClass.SelectedIndexChanged
        If ddClass.SelectedValue <> "" Then

            Using cmd As New OleDbCommand("select c.Staff_Name from Subject a,Class b,Staff c where c.Staff_ID=a.Staff_ID and b.Class_ID=a.Class_ID and c.Post='Teacher' and b.Class_Standard='" & ddClass.SelectedValue & "'")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()

                ddStaff.DataSource = cmd.ExecuteReader()
                ddStaff.DataTextField = "Staff_Name"

                ddStaff.DataBind()
                conn.Close()

            End Using

            ddStaff.Items.Insert(0, New ListItem("--Select Class--", "0"))
        End If

    End Sub

    Protected Sub ddStaff_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddStaff.SelectedIndexChanged
       
        Dim dt As New DataTable()

        conn.Open()
        If ddStaff.SelectedValue <> "" Then
            Dim cmd As New OleDb.OleDbCommand("SELECT a.Feedback_ID,a.Q1,a.Q2,a.Q3,a.Q4,a.Q5,a.Class_Standard FROM [Student Feedback] a,[Staff] b,[Class] c WHERE b.Staff_ID=a.Staff_ID AND c.Class_ID=a.Class_ID AND b.Staff_Name=@Class", conn)
            cmd.Parameters.AddWithValue("@Class", ddStaff.SelectedValue)
            Dim da As New OleDb.OleDbDataAdapter(cmd)
            da.Fill(dt)

        End If

        conn.Close()
        GridView1.DataSource = dt
        GridView1.DataBind()
        GridView1.Visible = True
    End Sub

End Class