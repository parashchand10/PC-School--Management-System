﻿Imports System.Data.OleDb

Public Class Staff_Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call type()

        lblStaffID.Visible = False
        txtStaffID.Visible = False
    End Sub

    Private Sub type()
        Dim sql1 = "SELECT Staff_ID FROM Staff WHERE Staff_Email_ID='" & txtEmailID.Text & "' AND Staff_Password='" & txtPassword.Text & "'"
        cmd = New OleDbCommand(sql1, conn)

        conn.Open()
        Dim r As OleDbDataReader = cmd.ExecuteReader

        If (r.HasRows) Then
            If (r.Read()) Then
                txtStaffID.Text = r("Staff_ID").ToString()
            Else
                txtStaffID.Text = "No rows found!"
            End If
        End If

        r.Close()
        conn.Close()

    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles LinkButton1.Click
        Response.Redirect("Forgot Password.aspx")
    End Sub

    Protected Sub cmdLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdLogin.Click
        If ddStaffList.SelectedValue = "Director" Then

            Try
                Dim cmd As New OleDbCommand("select * from Staff where Staff_ID=@Staff_ID and Staff_Email_ID =@Staff_Email_ID and Staff_Password=@Staff_Password", conn)
                cmd.Parameters.AddWithValue("@Staff_ID", txtStaffID.Text)
                cmd.Parameters.AddWithValue("@Staff_Email_ID", txtEmailID.Text)
                cmd.Parameters.AddWithValue("@Staff_Password", txtPassword.Text)
                Dim da As New OleDbDataAdapter(cmd)
                Dim dt As New DataTable()
                da.Fill(dt)
                If dt.Rows.Count > 0 Then

                    Response.Write("<script language=""javascript"">alert('Login Successfully');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Director.aspx?tmp1=" + txtStaffID.Text
                    Me.Page.Header.Controls.Add(meta)
                Else
                    Response.Write("<script language=""javascript"">alert('Invalid Login');</script>")
                End If

            Catch ex As Exception

            End Try
            conn.Close()

        End If

        If ddStaffList.SelectedValue = "Principal" Then


            Try
                Dim cmd As New OleDbCommand("select * from Staff where Staff_ID=@Staff_ID and Staff_Email_ID =@Staff_Email_ID and Staff_Password=@Staff_Password", conn)
                cmd.Parameters.AddWithValue("@Staff_ID", txtStaffID.Text)
                cmd.Parameters.AddWithValue("@Staff_Email_ID", txtEmailID.Text)
                cmd.Parameters.AddWithValue("@Staff_Password", txtPassword.Text)
                Dim da As New OleDbDataAdapter(cmd)
                Dim dt As New DataTable()
                da.Fill(dt)
                If dt.Rows.Count > 0 Then

                    Response.Write("<script language=""javascript"">alert('Login Successfully');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Principal.aspx?tmp1=" + txtStaffID.Text
                    Me.Page.Header.Controls.Add(meta)
                Else
                    Response.Write("<script language=""javascript"">alert('Invalid Login');</script>")
                End If

            Catch ex As Exception

            End Try
            conn.Close()

        End If


        If ddStaffList.SelectedValue = "Teacher" Then

            Try
                Dim cmd As New OleDbCommand("select * from Staff where Staff_ID=@Staff_ID and Staff_Email_ID =@Staff_Email_ID and Staff_Password=@Staff_Password", conn)
                cmd.Parameters.AddWithValue("@Staff_ID", txtStaffID.Text)
                cmd.Parameters.AddWithValue("@Staff_Email_ID", txtEmailID.Text)
                cmd.Parameters.AddWithValue("@Staff_Password", txtPassword.Text)
                Dim da As New OleDbDataAdapter(cmd)
                Dim dt As New DataTable()
                da.Fill(dt)
                If dt.Rows.Count > 0 Then

                    Response.Write("<script language=""javascript"">alert('Login Successfully');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Teacher.aspx?tmp1=" + txtStaffID.Text
                    Me.Page.Header.Controls.Add(meta)
                Else
                    Response.Write("<script language=""javascript"">alert('Invalid Login');</script>")
                End If

            Catch ex As Exception

            End Try
            conn.Close()

        End If

        If ddStaffList.SelectedValue = "Non Teaching Staff" Then


            Try
                Dim cmd As New OleDbCommand("select * from Staff where Staff_ID=@Staff_ID and Staff_Email_ID =@Staff_Email_ID and Staff_Password=@Staff_Password", conn)
                cmd.Parameters.AddWithValue("@Staff_ID", txtStaffID.Text)
                cmd.Parameters.AddWithValue("@Staff_Email_ID", txtEmailID.Text)
                cmd.Parameters.AddWithValue("@Staff_Password", txtPassword.Text)
                Dim da As New OleDbDataAdapter(cmd)
                Dim dt As New DataTable()
                da.Fill(dt)
                If dt.Rows.Count > 0 Then

                    Response.Write("<script language=""javascript"">alert('Login Successfully');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Non Teaching Staff.aspx?tmp1=" + txtStaffID.Text
                    Me.Page.Header.Controls.Add(meta)
                Else
                    Response.Write("<script language=""javascript"">alert('Invalid Login');</script>")
                End If

            Catch ex As Exception

            End Try
            conn.Close()
        End If

    End Sub

    Protected Sub CheckBox1_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            Dim pass As String = txtPassword.Text
            txtPassword.TextMode = TextBoxMode.Password
            txtPassword.Attributes.Add("value", pass)
        End If

        If CheckBox1.Checked Then
            txtPassword.TextMode = TextBoxMode.SingleLine
        End If
    End Sub


    Protected Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class