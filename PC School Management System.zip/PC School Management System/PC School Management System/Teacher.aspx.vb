﻿Imports System.Data.OleDb

Public Class Teacher1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call Teacher()

        Dim pass As String = txtStaffPassword.Text
        txtStaffPassword.TextMode = TextBoxMode.Password
        txtStaffPassword.Attributes.Add("value", pass)

        txtClassID.Visible = False
        txtClassStd.Visible = False
        txtStaffID.Visible = False
        lblStaffID.Visible = False

    End Sub

    Private Sub Teacher()

        If Not Me.IsPostBack Then
            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then
                txtStaffID.Text = Request.QueryString("tmp1").ToString()

                Image1.ImageUrl = "Staff Detail.ashx?ID=" + txtStaffID.Text
                Dim sql = "select a.Staff_ID,a.Post,a.Staff_Email_ID,a.Staff_Password,a.Staff_Name,a.Staff_Designation,a.Teacher_Type,a.Staff_Date_of_Joining,a.Year_of_Exprience,a.Qualification,a.Staff_Mobile_Number,a.Staff_Photo,c.Class_ID,a.Staff_Class_Standard from [Staff] a,[Subject] b,[Class] c where b.Class_ID=c.Class_ID and b.Staff_ID=a.Staff_ID and a.Staff_ID=" & txtStaffID.Text & ""
                cmd = New OleDbCommand(sql, conn)

                conn.Open()
                Dim r As OleDbDataReader = cmd.ExecuteReader

                If (r.HasRows) Then
                    If (r.Read()) Then

                        txtStaffID.Text = r("Staff_ID").ToString
                        txtPost.Text = r("Post").ToString
                        txtStaffEmailID.Text = r("Staff_Email_ID").ToString
                        txtStaffPassword.Text = r("Staff_Password").ToString
                        txtStaffName.Text = r("Staff_Name").ToString

                        txtStaffDesignation.Text = r("Staff_Designation").ToString
                        txtTeacherType.Text = r("Teacher_Type").ToString
                        txtDOJ.Text = r("Staff_Date_of_Joining").ToString
                        txtYOP.Text = r("Year_of_Exprience")
                        txtQualification.Text = r("Qualification").ToString
                        txtStaffMobileNumber.Text = r("Staff_Mobile_Number").ToString
                        txtStaffPhoto.Text = r("Staff_Photo").ToString
                        txtClassID.Text = r("Class_ID").ToString
                        txtClassStd.Text = r("Staff_Class_Standard").ToString
                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r.Close()
                conn.Close()
            End If
        End If


    End Sub

    
    Protected Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

        Dim sql = "update [Staff] set Staff_Email_ID='" & txtStaffEmailID.Text & "',Staff_Password='" & txtStaffPassword.Text & "',Staff_Name='" & txtStaffName.Text & "',Staff_Mobile_Number='" & txtStaffMobileNumber.Text & "' where Staff_ID=" & txtStaffID.Text & ""
        cmd = New OleDbCommand(sql, conn)


        'ADD PARAMETERS
        cmd.Parameters.AddWithValue("@Staff_Email_ID", txtStaffEmailID.Text)
        cmd.Parameters.AddWithValue("@Staff_Password", txtStaffPassword.Text)
        cmd.Parameters.AddWithValue("@Staff_Name", txtStaffName.Text)
        cmd.Parameters.AddWithValue("@Staff_Mobile_Number", txtStaffMobileNumber.Text)



        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")

            End If
            conn.Close()

        Catch ex As Exception

            conn.Close()
        End Try

    End Sub


    Public Shared salary As Integer

    Protected Sub DropDownList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DropDownList1.SelectedIndexChanged
        If DropDownList1.SelectedValue = "Salary Slip" Then
            salary = txtStaffID.Text
            Response.Redirect("Generate Slip.aspx")
        End If

        If DropDownList1.SelectedValue = "Attendance" Then
            Response.Redirect("Student Attendance.aspx?tmp1=" + txtClassStd.Text)
        End If

        If DropDownList1.SelectedValue = "Fee Report" Then
            Response.Redirect("Fee Pending.aspx?tmp1=" + txtClassStd.Text)
        End If

        If DropDownList1.SelectedValue = "Workload Calculate" Then
            salary = txtStaffID.Text
            Response.Redirect("Workload Calculate.aspx")
        End If
    End Sub

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            Dim pass As String = txtStaffPassword.Text
            txtStaffPassword.TextMode = TextBoxMode.Password
            txtStaffPassword.Attributes.Add("value", pass)
        End If

        If CheckBox1.Checked Then
            txtStaffPassword.TextMode = TextBoxMode.SingleLine
        End If
    End Sub

   
End Class