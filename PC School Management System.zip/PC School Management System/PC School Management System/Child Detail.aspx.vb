﻿Imports System.Data.OleDb

Public Class Child_Detail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call detail()


        Dim pass As String = txtPassword.Text
        txtPassword.TextMode = TextBoxMode.Password
        txtPassword.Attributes.Add("value", pass)


    End Sub

    Private Sub detail()
        If Not Me.IsPostBack Then
            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then
                txtAdmissionID.Text = Request.QueryString("tmp1").ToString()
                Image1.ImageUrl = "Child.ashx?ID=" + txtAdmissionID.Text


                Dim sql1 = "SELECT Admission_ID,Admission_Year,Admission_Date,Email_ID,Password,Full_Name,Address,Caste_Category,Gender,Date_of_Birth,Mobile_Number,Father_Name,Mother_Name,Photo,Admission_Status FROM [Admission] WHERE Admission_ID=" & txtAdmissionID.Text & ""
                cmd = New OleDbCommand(sql1, conn)

                conn.Open()
                Dim r1 As OleDbDataReader = cmd.ExecuteReader

                If (r1.HasRows) Then
                    If (r1.Read()) Then

                        txtAdmissionID.Text = r1("Admission_ID")
                        txtAdmissionYear.Text = r1("Admission_Year").ToString
                        txtAdmissionDate.Text = r1("Admission_Date").ToString
                        txtEmailID.Text = r1("Email_ID").ToString
                        txtPassword.Text = r1("Password").ToString
                        txtStudentName.Text = r1("Full_Name").ToString
                        txtAddress.Text = r1("Address").ToString
                        txtCaste.Text = r1("Caste_Category").ToString
                        txtGender.Text = r1("Gender").ToString
                        txtDateofBirth.Text = r1("Date_of_Birth").ToString
                        txtStudentMobileNumber.Text = r1("Mobile_Number").ToString

                        txtFatherName.Text = r1("Father_Name").ToString
                        txtMotherName.Text = r1("Mother_Name").ToString
                        txtPhoto.Text = r1("Photo").ToString
                        txtAdmissionStatus.Text = r1("Admission_Status").ToString

                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r1.Close()
                conn.Close()
            End If
        End If

    End Sub
    

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")

    End Sub

    Protected Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            Dim pass As String = txtPassword.Text
            txtPassword.TextMode = TextBoxMode.Password
            txtPassword.Attributes.Add("value", pass)
        End If

        If CheckBox1.Checked Then
            txtPassword.TextMode = TextBoxMode.SingleLine
        End If
    End Sub

End Class