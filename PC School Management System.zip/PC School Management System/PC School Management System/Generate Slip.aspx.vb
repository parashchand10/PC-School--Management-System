﻿
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Web

Public Class Generate_Slip
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load


        txtStaffID.Text = Teacher1.salary
        txtMonth.Visible = False
        txtStartDate.Visible = False

    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try

            Dim reportdocument As New ReportDocument()
            reportdocument.Load(Server.MapPath("StaffSalary.rpt"))

            reportdocument.SetParameterValue("@ID", txtStaffID.Text)
            reportdocument.SetParameterValue("@Ending_Date", txtEndDate.Text)
            CrystalReportViewer1.ReportSource = reportdocument

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Calendar1_DayRender(sender As Object, e As System.Web.UI.WebControls.DayRenderEventArgs) Handles Calendar1.DayRender
        If e.Day.DayNumberText.CompareTo("1") = 1 Then
            e.Day.IsSelectable = False
        End If

    End Sub

    Protected Sub Calendar1_SelectionChanged(sender As Object, e As EventArgs) Handles Calendar1.SelectionChanged
        txtMonth.Text = Calendar1.SelectedDate.ToShortDateString()
        Calendar1.Visible = False


        Dim startOfNewYear As DateTime = txtMonth.Text
        Dim startOfFirstQuarter As DateTime = startOfNewYear
        Dim startOfSecondQuarter As DateTime = startOfNewYear.AddMonths(0)

        Dim endOfFirstQuarter As DateTime = startOfSecondQuarter.AddMonths(1).AddDays(-1)

        txtStartDate.Text = startOfFirstQuarter
        txtEndDate.Text = endOfFirstQuarter


    End Sub

    Protected Sub ImageButton1_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Calendar1.Visible = True
    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class