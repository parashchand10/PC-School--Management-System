﻿
Imports System.Data.OleDb
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Web

Public Class Timetable
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call selectclass()

    End Sub
   
    Private Sub selectclass()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddClassStandard.DataSource = cmd.ExecuteReader()
                ddClassStandard.DataTextField = "Class_Standard"

                ddClassStandard.DataBind()
                conn.Close()
            End Using
            ddClassStandard.Items.Insert(0, New ListItem("--Select Class--", ""))
        End If

    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub cmdSubmit_Click(sender As Object, e As EventArgs) Handles cmdSubmit.Click
        Try

            Dim reportdocument As New ReportDocument()
            reportdocument.Load(Server.MapPath("Subject Timetable.rpt"))

            reportdocument.SetParameterValue("@ClassName", ddClassStandard.Text)
            CrystalReportViewer1.ReportSource = reportdocument

        Catch ex As Exception

        End Try
    End Sub

End Class