﻿Imports System.Data.OleDb

Public Class Admission_Detail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()

        Calendar1.Visible = False

        txtDate.Text = Calendar1.TodaysDate

        txtDate.Visible = False
        Label2.Visible = False

        txtAdmissionDetailID.Visible = False

        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Admission_Type] FROM [Admission Detail]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddAdmissionType.DataSource = cmd.ExecuteReader()
                ddAdmissionType.DataTextField = "Admission_Type"

                ddAdmissionType.DataBind()
                conn.Close()
            End Using

            ddAdmissionType.Items.Insert(0, New ListItem("--Select Admission Type--", "0"))

        End If
    End Sub




    Protected Sub ddAdmissionType_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddAdmissionType.SelectedIndexChanged
        Dim query As String = "select * from [Admission Detail] where Admission_Type = '" & ddAdmissionType.SelectedValue & "' "
        cmd = New OleDbCommand(query, conn)


        Try
            conn.Open()
            Dim r As OleDbDataReader = cmd.ExecuteReader

            While r.Read()
                Dim sID As String = CStr(r("Admission_Detail_ID").ToString)
                Dim sname As String = CStr(r("Admission_Type").ToString)
                Dim astart As String = CStr(r("Admission_Start_Date").ToString)
                Dim aend As String = CStr(r("Admission_End_Date").ToString)
                Dim aamount As String = CStr(r("Admission_Amount").ToString)

                txtAdmissionDetailID.Text = sID
                ddAdmissionType.Text = sname
                txtAdmissionStartDate.Text = astart
                txtAdmissionEndDate.Text = aend
                txtAdmissionAmount.Text = aamount

            End While

        Catch es As Exception
            MsgBox(es.Message)
        End Try
    End Sub

    Public Shared text1 As String
    Public Shared txt As String

    Protected Sub cmdAdmission_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdAdmission.Click

        If Trim(txtDate.Text) < Trim(txtAdmissionEndDate.Text) Then
            text1 = txtAdmissionAmount.Text
            txt = ddAdmissionType.SelectedValue
            Response.Redirect("Admission Form.aspx")

        Else

            Response.Write("<script language=""javascript"">alert('From Will Not Open Date will be expiry');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Admission Detail.aspx"
            Me.Page.Header.Controls.Add(meta)
        End If
    End Sub

End Class