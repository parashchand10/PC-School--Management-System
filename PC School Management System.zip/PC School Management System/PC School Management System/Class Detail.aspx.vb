﻿Imports System.Data.OleDb

Public Class Class_Detail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call student()
        Call newid()

        If Not IsPostBack Then
            
            BindGrid()
        End If

        grid.Columns(0).Visible = False
        lblClass.Visible = False
        txtClassID.Visible = False
        txtClass.Visible = False
        txtClassYear.Text = Date.Today.Year
    End Sub

    Private Sub student()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(50000, 90000)  ' Get random numbers 
        txtClassID.Text = intResult.ToString
    End Sub

    Private Sub newid()

        If Not IsPostBack Then
            Dim sql = "SELECT MAX(Class_ID) + 1 as Class_ID FROM Class"
            cmd = New OleDbCommand(sql, conn)

            conn.Open()
            Dim r As OleDbDataReader = cmd.ExecuteReader

            If (r.HasRows) Then
                If (r.Read()) Then

                    txtClassID.Text = r("Class_ID").ToString()

                Else

                    MsgBox("No rows found!")
                End If
            End If

            r.Close()
            conn.Close()
        End If

    End Sub

    Private Sub BindGrid()
        Dim sql = "SELECT [Class_ID],[Class_Year],[Class_Standard],[Student_Intake] FROM [Class]"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        grid.DataSource = cmd.ExecuteReader()
        grid.DataBind()
        conn.Close()

    End Sub

    Private Sub Insert(ByVal name As Integer, ByVal country As Integer, ByVal country1 As String, ByVal country2 As Integer)

        Using cmd As OleDbCommand = New OleDbCommand("INSERT INTO [Class] VALUES (@Class_ID,@Class_Year,@Class_Standard,@Student_Intake)", conn)
            cmd.CommandType = CommandType.Text

            cmd.Parameters.AddWithValue("@Class_ID", name)
            cmd.Parameters.AddWithValue("@Class_Year", country)
            cmd.Parameters.AddWithValue("@Class_Standard", country1)
            cmd.Parameters.AddWithValue("@Student_Intake", country2)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
        End Using

    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click

        Using cmd As OleDbCommand = New OleDbCommand("SELECT Class_Standard FROM [Class] WHERE Class_Standard=@Class_Standard", conn)
            cmd.CommandType = CommandType.Text

            cmd.Parameters.AddWithValue("@Class_Standard", Me.txtClassSTD.Text.Trim())

            conn.Open()
            Dim result As String = Convert.ToString(cmd.ExecuteScalar())
            conn.Close()
            If String.IsNullOrEmpty(result) Then
                Insert(Me.txtClassID.Text.Trim(), Me.txtClassYear.Text.Trim(), Me.txtClassSTD.Text.Trim(), Me.txtStudentIntake.Text.Trim())
                Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Class Detail.aspx"
                Me.Page.Header.Controls.Add(meta)

                txtClassSTD.Text = ""
                txtClassYear.Text = ""
                txtStudentIntake.Text = ""
            Else
                Response.Write("<script language=""javascript"">alert('Record Already Exits');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Class Detail.aspx"
                Me.Page.Header.Controls.Add(meta)

                txtClassSTD.Text = ""
                txtClassYear.Text = ""
                txtStudentIntake.Text = ""
            End If
        End Using


    End Sub

    Private Sub grid_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grid.RowDeleting
    
        Dim sql1 = "delete from [Class] where Class_ID=" & Trim(txtClass.Text) & ""
        cmd = New OleDbCommand(sql1, conn)


        'ADD PARAMETERS
        cmd.Parameters.AddWithValue("@Class_ID", txtClass.Text)
        cmd.Parameters.AddWithValue("@Class_Year", txtClassYear.Text)
        cmd.Parameters.AddWithValue("@Class_Standard", txtClassSTD.Text)
        cmd.Parameters.AddWithValue("@Student_Intake", txtStudentIntake.Text)


        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Removed');</script>")
            End If
            conn.Close()

        Catch ex As Exception

            conn.Close()
        End Try
        grid.DataBind()
        Dim meta As New HtmlMeta()
        meta.HttpEquiv = "Refresh"
        meta.Content = "0;url=Class Detail.aspx"
        Me.Page.Header.Controls.Add(meta)

    End Sub

    Private Sub grid_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles grid.RowUpdating
        Dim sql1 = "update Class set Class_Standard='" & txtClassSTD.Text & "',Class_Year='" & txtClassYear.Text & "',Student_Intake=" & txtStudentIntake.Text & " where Class_ID=" & txtClass.Text & ""
        cmd = New OleDbCommand(sql1, conn)

        'ADD PARAMETERS

        cmd.Parameters.AddWithValue("@Class_Year", txtClassYear.Text)
        cmd.Parameters.AddWithValue("@Class_Standard", txtClassSTD.Text)
        cmd.Parameters.AddWithValue("@Student_Intake", txtStudentIntake.Text)

        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then

                Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Class Detail.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()

        Catch ex As Exception
            Response.Write("<script language=""javascript"">alert('Please Select Data');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Class Detail.aspx"
            Me.Page.Header.Controls.Add(meta)
            conn.Close()
        End Try
        grid.DataBind()

    End Sub

    Protected Sub grid_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles grid.SelectedIndexChanged
        Dim selectedRowIndex As Integer
        selectedRowIndex = grid.SelectedIndex
        Dim row As GridViewRow = grid.Rows(selectedRowIndex)

        txtClass.Text = row.Cells(0).Text
        txtClassYear.Text = row.Cells(1).Text
        txtClassSTD.Text = row.Cells(2).Text
        txtStudentIntake.Text = row.Cells(3).Text


    End Sub
   
    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub
End Class