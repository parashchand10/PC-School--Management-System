﻿Imports System.Data.OleDb

Public Class Candidate_Detail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call detail()

        lblCandidate.Visible = False
        txtCandidateID.Visible = False

        Dim pass As String = txtCandidatePassword.Text
        txtCandidatePassword.TextMode = TextBoxMode.Password
        txtCandidatePassword.Attributes.Add("value", pass)

    End Sub

    Private Sub detail()
        If Not Me.IsPostBack Then
            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then
                txtCandidateID.Text = Request.QueryString("tmp1").ToString()
                Image1.ImageUrl = "Candidate.ashx?ID=" + txtCandidateID.Text
                Dim sql = "SELECT * FROM [Candidate] where Candidate_ID=" & txtCandidateID.Text & ""
                cmd = New OleDbCommand(sql, conn)

                conn.Open()
                Dim r As OleDbDataReader = cmd.ExecuteReader

                If (r.HasRows) Then
                    If (r.Read()) Then

                            txtCandidateEmailID.Text = r("Candidate_Email_ID").ToString
                        txtCandidatePassword.Text = r("Candidate_Password").ToString
                        txtCandidateFullName.Text = r("Candidate_Name").ToString
                        txtCandidateYearofExp.Text = r("Candidate_YOP").ToString
                        txtCandidateQualification.Text = r("Canadidate_Qualification").ToString
                        txtCandidateMobileNumber.Text = r("Candidate_Mobile_Number").ToString
                        txtCandidatePhoto.Text = r("Candidate_Photo").ToString
                        txtCandidateStatus.Text = r("Candidate_Status").ToString

                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r.Close()
                conn.Close()
            End If
        End If
    End Sub

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            Dim pass As String = txtCandidatePassword.Text
            txtCandidatePassword.TextMode = TextBoxMode.Password
            txtCandidatePassword.Attributes.Add("value", pass)
        End If

        If CheckBox1.Checked Then
            txtCandidatePassword.TextMode = TextBoxMode.SingleLine
        End If
    End Sub

End Class