﻿Imports System.Data.OleDb

Public Class School_Feedback
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        selectclass()

        If Not IsPostBack Then

            BindGrid1()
        End If

        GridView1.Visible = False
    End Sub

    Private Sub selectclass()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddClass.DataSource = cmd.ExecuteReader()
                ddClass.DataTextField = "Class_Standard"

                ddClass.DataBind()
                conn.Close()
            End Using
            ddClass.Items.Insert(0, New ListItem("--Select Class--", "0"))
        End If
    End Sub

    Private Sub BindGrid1()
        Dim sql = "SELECT School_Feedback_ID,Q1,Q2,Q3,Suggestion FROM [School Feedback]"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        GridView1.DataSource = cmd.ExecuteReader()
        GridView1.DataBind()
        conn.Close()

    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
        Response.Redirect("Homepage.aspx")
    End Sub

   

    Protected Sub ddClass_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddClass.SelectedIndexChanged
        Dim dt As New DataTable()

        conn.Open()
        If ddClass.SelectedValue <> "" Then
            Dim cmd As New OleDb.OleDbCommand("SELECT a.School_Feedback_ID,a.Q1,a.Q2,a.Q3,a.Suggestion FROM [School Feedback] a,[Class] c WHERE c.Class_ID=a.Class_ID AND c.Class_Standard=@Class", conn)
            cmd.Parameters.AddWithValue("@Class", ddClass.SelectedValue)
            Dim da As New OleDb.OleDbDataAdapter(cmd)
            da.Fill(dt)
        End If
        conn.Close()
        GridView1.DataSource = dt
        GridView1.DataBind()
        GridView1.Visible = True
    End Sub


End Class