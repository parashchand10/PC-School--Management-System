﻿Imports System.Data.OleDb

Public Class Vacancy
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call vacancy()

        txtDate.Visible = False

        Calendar1.Visible = False
        txtDate.Text = Calendar1.TodaysDate

        lblVacancyID.Visible = False
        txtVacancyID.Visible = False
    End Sub

    Private Sub vacancy()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Vacancy_Designation] FROM [Vacancy]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddDesignation.DataSource = cmd.ExecuteReader()
                ddDesignation.DataTextField = "Vacancy_Designation"

                ddDesignation.DataBind()
                conn.Close()
            End Using

            ddDesignation.Items.Insert(0, New ListItem("--Select--", "0"))
        End If
    End Sub

    Protected Sub ddDesignation_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddDesignation.SelectedIndexChanged
        Dim query As String = "select * from [Vacancy] where Vacancy_Designation = '" & ddDesignation.SelectedValue & "' "
        cmd = New OleDbCommand(query, conn)

        Try
            conn.Open()
            Dim r As OleDbDataReader = cmd.ExecuteReader

            While r.Read()
                Dim sID As String = CStr(r("Vacancy_ID").ToString)
                Dim astart As String = CStr(r("Vacancy_Start_Date").ToString)
                Dim aend As String = CStr(r("Vacancy_End_Date").ToString)


                txtVacancyID.Text = sID
                txtVacancyStartDate.Text = astart
                txtVacancyEndDate.Text = aend
            End While

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Shared number As Integer
    Protected Sub cmdCandidate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCandidate.Click
        If Trim(txtDate.Text) < Trim(txtVacancyEndDate.Text) Then
            number = txtVacancyID.Text
            Response.Redirect("Add Candidate.aspx")
        Else
            Response.Write("<script language=""javascript"">alert('From Will Not Open Date will be expiry');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Vacancy.aspx"
            Me.Page.Header.Controls.Add(meta)
        End If

    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class