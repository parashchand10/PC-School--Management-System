﻿Imports System.Data.OleDb

Public Class Activity_Student_List
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call classstd()

        gvDetails.Visible = False
        gvDetails.Columns(0).Visible = False
        gvDetails.Columns(2).Visible = False
        gvDetails.Columns(4).Visible = False
        gvDetails.Columns(6).Visible = False

        If Not IsPostBack Then
            BindGridview()
        End If
    End Sub

    Private Sub classstd()

        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddlLocation.DataSource = cmd.ExecuteReader()
                ddlLocation.DataTextField = "Class_Standard"

                ddlLocation.DataBind()
                conn.Close()
            End Using

            ddlLocation.Items.Insert(0, New ListItem("--Select Class Standard--", ""))
        End If
    End Sub

    'Bind Data with GridView Control
    Protected Sub BindGridview()
        Dim sql = "SELECT a.Activity_Form_ID,a.Activity_Registration_Date,b.Class_ID,b.Class_Standard,c.Student_ID,c.Student_Name,d.Activity_ID,d.Activity_Name from [Activity Form] a,[Class] b,[Student] c,[School Activity] d where b.Class_ID=a.Class_ID and c.Student_ID=a.Student_ID and d.Activity_ID=a.Activity_ID"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        gvDetails.DataSource = cmd.ExecuteReader()
        gvDetails.DataBind()
        conn.Close()

    End Sub
    
    Protected Sub ddlLocation_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddlLocation.SelectedIndexChanged
        Dim dt As New DataTable()

        conn.Open()
        If ddlLocation.SelectedValue <> "" Then
            Dim cmd As New OleDb.OleDbCommand("select a.Activity_Form_ID,a.Activity_Registration_Date,b.Class_ID,b.Class_Standard,c.Student_ID,c.Student_Name,d.Activity_ID,d.Activity_Name from [Activity Form] a,[Class] b,[Student] c,[School Activity] d where b.Class_ID=a.Class_ID and c.Student_ID=a.Student_ID and d.Activity_ID=a.Activity_ID and b.Class_Standard=@Class", conn)
            cmd.Parameters.AddWithValue("@Class", ddlLocation.SelectedValue)
            Dim da As New OleDb.OleDbDataAdapter(cmd)
            da.Fill(dt)
        Else
            Dim cmd As New OleDb.OleDbCommand("select a.Activity_Form_ID,a.Activity_Registration_Date,b.Class_ID,b.Class_Standard,c.Student_ID,c.Student_Name,d.Activity_ID,d.Activity_Name from [Activity Form] a,[Class] b,[Student] c,[School Activity] d where b.Class_ID=a.Class_ID and c.Student_ID=a.Student_ID and d.Activity_ID=a.Activity_ID", conn)
            Dim da As New OleDb.OleDbDataAdapter(cmd)
            da.Fill(dt)
        End If
        conn.Close()
        gvDetails.DataSource = dt
        gvDetails.DataBind()

        gvDetails.Visible = True
    End Sub

   
End Class