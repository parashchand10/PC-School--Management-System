﻿Imports System.Data.OleDb

Public Class Subject
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call subject()
        Call selectclass()
        lblSubject.Visible = False
        txtSubject.Visible = False
        txtSubjectID.Visible = False
        lblClass.Visible = False
        txtClassID.Visible = False

        If Not IsPostBack Then
            BindGrid()
        End If

        grid.Columns(0).Visible = False
        grid.Columns(2).Visible = False

    End Sub

    Private Sub subject()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(50000, 80000)  ' Get random numbers 
        txtSubjectID.Text = intResult.ToString
    End Sub

    Private Sub BindGrid()
        Dim sql = "SELECT a.Subject_ID,a.Subject_Name,b.Class_ID,b.Class_Standard FROM [Subject] a,[Class] b WHERE a.Class_ID=b.Class_ID"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        grid.DataSource = cmd.ExecuteReader()
        grid.DataBind()
        conn.Close()

    End Sub

    Private Sub selectclass()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddClass.DataSource = cmd.ExecuteReader()
                ddClass.DataTextField = "Class_Standard"

                ddClass.DataBind()
                conn.Close()
            End Using
            ddClass.Items.Insert(0, New ListItem("--Select Class--", ""))
        End If
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Dim sql = "INSERT INTO [Subject] ([Subject_ID],[Subject_Name],[Class_ID]) VALUES (@Subject_ID,@Subject_Name,@Class_ID)"
        cmd = New OleDbCommand(sql, conn)

        'ADD PARAMETERSS
        cmd.Parameters.AddWithValue("@Subject_ID", txtSubjectID.Text)
        cmd.Parameters.AddWithValue("@Subject_Name", txtSubjectName.Text)
        cmd.Parameters.AddWithValue("@Class_ID", txtClassID.Text)

        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Subject.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
            conn.Close()
        End Try

    End Sub

    Protected Sub ddClass_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddClass.SelectedIndexChanged
        Dim sql1 = "SELECT Class_ID FROM [Class] WHERE Class_Standard='" & ddClass.Text & "'"
        cmd = New OleDbCommand(sql1, conn)

        conn.Open()
        Dim r As OleDbDataReader = cmd.ExecuteReader

        If (r.HasRows) Then
            If (r.Read()) Then

                txtClassID.Text = r("Class_ID").ToString

            Else

                MsgBox("No rows found!")

            End If
        End If

        r.Close()
        conn.Close()
    End Sub

    Protected Sub grid_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles grid.SelectedIndexChanged

        Dim selectedRowIndex As Integer
        selectedRowIndex = grid.SelectedIndex
        Dim row As GridViewRow = grid.Rows(selectedRowIndex)

        txtSubject.Text = row.Cells(0).Text
        txtSubjectName.Text = row.Cells(1).Text
        txtClassID.Text = row.Cells(2).Text
        ddClass.Text = row.Cells(3).Text

    End Sub

    Private Sub grid_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grid.RowDeleting
        Dim sql1 = "delete from Subject where Subject_ID=" & txtSubject.Text & ""
        cmd = New OleDbCommand(sql1, conn)


        'ADD PARAMETERS
        cmd.Parameters.AddWithValue("@Subject_Name", txtSubjectName.Text)
        cmd.Parameters.AddWithValue("@Class_ID", txtClassID.Text)


        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Removed');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Subject.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
            conn.Close()
        End Try

    End Sub

    Private Sub grid_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles grid.RowUpdating
        Dim sql1 = "update Subject set Subject_Name='" & txtSubjectName.Text & "',Class_ID=" & txtClassID.Text & " where Subject_ID=" & txtSubject.Text & ""
        cmd = New OleDbCommand(sql1, conn)

        'ADD PARAMETERS

        cmd.Parameters.AddWithValue("@Subject_Name", txtSubjectName.Text)
        cmd.Parameters.AddWithValue("@Class_ID", txtClassID.Text)

        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Subject.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
            conn.Close()
        End Try

    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class