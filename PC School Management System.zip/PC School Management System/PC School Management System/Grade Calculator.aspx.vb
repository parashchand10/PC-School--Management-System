﻿Public Class Grade_Calculator
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        txtTotal.Visible = False
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        If txtSubject1.Text > ddTotalMarks.Text Then
            Response.Write("<script language=""javascript"">alert('Marks is than ! Calculate mark');</script>")
        Else
            txtTotal.Text = Val(txtSubject1.Text) / Val(ddTotalMarks.Text) * Val(txtWeightage.Text)

            If txtTotal.Text <= "10" Then
                txtGrade.Text = "A1"
            ElseIf txtTotal.Text >= "9" Then
                txtGrade.Text = "A1"
            ElseIf txtTotal.Text >= "8" And txtTotal.Text <= "9.1" Then
                txtGrade.Text = "A2"
            ElseIf txtTotal.Text >= "7" And txtTotal.Text <= "8.1" Then
                txtGrade.Text = "B1"
            ElseIf txtTotal.Text >= "6" And txtTotal.Text <= "7.1" Then
                txtGrade.Text = "B2"
            ElseIf txtTotal.Text >= "5" And txtTotal.Text <= "6.1" Then
                txtGrade.Text = "C1"
            ElseIf txtTotal.Text >= "4" And txtTotal.Text <= "5.1" Then
                txtGrade.Text = "C2"
            ElseIf txtTotal.Text >= "3" And txtTotal.Text <= "4.1" Then
                txtGrade.Text = "D1"
            Else
                txtGrade.Text = "F"
            End If

        End If

    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdRefresh.Click
        Response.Redirect(Request.Url.AbsoluteUri)
    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub DropDownList1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddTotalMarks.SelectedIndexChanged
        If ddTotalMarks.Text = 40 Then
            txtWeightage.Text = 10
        End If
    End Sub

End Class