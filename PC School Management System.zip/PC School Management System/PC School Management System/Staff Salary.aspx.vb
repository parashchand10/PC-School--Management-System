﻿Imports System.Data.OleDb

Public Class Staff_Salary
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call detail()

        lblSalaryiD.Visible = False
        txtSalaryID.Visible = False
        txtStaffID.Visible = False
    End Sub

    Private Sub detail()
        If Not Me.IsPostBack Then
            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then
                txtStaffID.Text = Request.QueryString("tmp1").ToString()

                Dim sql1 = "SELECT b.Salary_ID,b.Basic_Pay,b.Grade_Level,b.Grade_Pay,b.HRA,b.DA,b.TA,b.Gross_Salary,b.PF,b.Additional_Deduction,b.Net_Salary,a.Staff_ID  FROM [Staff] a,[Staff Salary] b WHERE a.Staff_ID=b.Staff_ID AND a.Staff_ID=" & txtStaffID.Text & ""
                cmd = New OleDbCommand(sql1, conn)

                conn.Open()
                Dim r1 As OleDbDataReader = cmd.ExecuteReader

                If (r1.HasRows) Then
                    If (r1.Read()) Then

                        txtSalaryID.Text = r1("Salary_ID")
                        txtBasicPay.Text = r1("Basic_Pay")
                        txtGradeLevel.Text = r1("Grade_Level").ToString()
                        txtGradePay.Text = r1("Grade_Pay")
                        txtHRA.Text = r1("HRA")
                        txtDA.Text = r1("DA")
                        txtTA.Text = r1("TA")
                        txtGrossSalary.Text = r1("Gross_Salary")
                        txtPF.Text = r1("PF")
                        txtAdditionalDeduction.Text = r1("Additional_Deduction")
                        txtNetSalary.Text = r1("Net_Salary")
                        txtStaffID.Text = r1("Staff_ID")
                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r1.Close()
                conn.Close()
            End If
        End If

    End Sub

End Class