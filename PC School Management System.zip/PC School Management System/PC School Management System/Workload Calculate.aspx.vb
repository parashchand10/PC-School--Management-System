﻿Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports CrystalDecisions.Web

Public Class Workload_Calculate
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        txtStaffID.Text = Teacher1.salary
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Dim reportdocument As New ReportDocument()
        reportdocument.Load(Server.MapPath("Timetable Report.rpt"))

        reportdocument.SetParameterValue("@ID", txtStaffID.Text)
        CrystalReportViewer1.ReportSource = reportdocument

    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class