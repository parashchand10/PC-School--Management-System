﻿Imports System.Data.OleDb

Public Class Admin_Detail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call detail()

        Dim pass As String = txtPassword.Text
        txtPassword.TextMode = TextBoxMode.Password
        txtPassword.Attributes.Add("value", pass)

    End Sub

    Private Sub detail()
        If Not Me.IsPostBack Then
            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then
                txtEmailID.Text = Request.QueryString("tmp1").ToString()
                Dim sql = "select Admin_Email_ID,Admin_Password from [Admin] where Admin_Email_ID='" & txtEmailID.Text & "'"
                cmd = New OleDbCommand(sql, conn)

                conn.Open()
                Dim r As OleDbDataReader = cmd.ExecuteReader

                If (r.HasRows) Then
                    If (r.Read()) Then
                        txtEmailID.Text = r("Admin_Email_ID").ToString()
                        txtPassword.Text = r("Admin_Password").ToString()
                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r.Close()
                conn.Close()
            End If
        End If
    End Sub



    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub
   

    Protected Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            Dim pass As String = txtPassword.Text
            txtPassword.TextMode = TextBoxMode.Password
            txtPassword.Attributes.Add("value", pass)
        End If

        If CheckBox1.Checked Then
            txtPassword.TextMode = TextBoxMode.SingleLine
        End If
    End Sub

End Class