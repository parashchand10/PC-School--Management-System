﻿Imports System.Data.OleDb

Public Class Student_Attendance
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call attendance()
        Call detail()

        Calendar2.Visible = False

        txtAttendance.Visible = False
        TextBox1.Visible = False
        txtClassStd.Visible = False
        lblAttendanceID.Visible = False
        txtAttendance_ID.Visible = False
        txtStudentID.Visible = False
        txtClassID.Visible = False

        If Not IsPostBack Then

            BindGrid()
        End If

    End Sub

    'Bind Data with GridView Control
    Private Sub BindGrid()
        Dim sql = "SELECT a.Attendance_ID,a.Student_Attendance_Type,a.Attendance_Date,b.Student_ID,b.Student_Name,b.Student_Roll_Number,c.Class_Standard FROM [Student Attendance] a,[Student] b,[Class] c WHERE b.Student_ID=a.Student_ID AND c.Class_ID=b.Class_ID"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        grid.DataSource = cmd.ExecuteReader()
        grid.DataBind()
        conn.Close()

    End Sub

    Private Sub detail()
        If Not Me.IsPostBack Then
            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then
                txtClassStd.Text = Request.QueryString("tmp1").ToString()

                Dim sql = "select b.Staff_Name,b.Staff_Class_Standard from [Subject] a,[Staff] b,[Class] c where a.Staff_ID=b.Staff_ID and a.Class_ID=c.Class_ID and b.Staff_Class_Standard='" & txtClassStd.Text & "'"
                cmd = New OleDbCommand(sql, conn)

                conn.Open()
                Dim r As OleDbDataReader = cmd.ExecuteReader

                If (r.HasRows) Then
                    If (r.Read()) Then
                        txtStaffName.Text = r("Staff_Name").ToString
                        txtClassID.Text = r("Staff_Class_Standard").ToString
                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r.Close()
                conn.Close()
            End If

            If txtClassID.Text <> "" Then

                Using cmd As New OleDbCommand("select a.Student_Roll_Number from [Student] a,[Class] b where b.Class_ID=a.Class_ID and b.Class_Standard='" & txtClassStd.Text & "'")
                    cmd.CommandType = CommandType.Text
                    cmd.Connection = conn
                    conn.Open()
                    ListBox1.DataSource = cmd.ExecuteReader()
                    ListBox1.DataTextField = "Student_Roll_Number"

                    ListBox1.DataBind()
                    conn.Close()
                End Using

                ListBox1.Items.Insert(0, New ListItem("--Select Roll Number--", "0"))
            End If
        End If
    End Sub

    Private Sub attendance()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(50000, 80000)  ' Get random numbers 
        txtAttendance_ID.Text = intResult.ToString
    End Sub

    Protected Sub ListBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ListBox1.SelectedIndexChanged
        Dim query As String = "select a.Student_Roll_Number,a.Student_Name,a.Student_ID,b.Class_Standard from Student a,Class b where b.Class_ID=a.Class_ID and a.Student_Roll_Number = " & ListBox1.Text & " "
        cmd = New OleDbCommand(query, conn)

        Try
            conn.Open()
            Dim r As OleDbDataReader = cmd.ExecuteReader

            While r.Read()
                Dim rno As String = CStr(r("Student_Roll_Number").ToString)
                Dim sname As String = CStr(r("Student_Name"))
                Dim sid As String = CStr(r("Student_ID"))
                Dim classname As String = CStr(r("Class_Standard"))

                txtRollNumber.Text = rno
                txtStudentName.Text = sname
                txtStudentID.Text = sid
                txtClassName.Text = classname

            End While

        Catch es As Exception
            MsgBox(es.Message)
        End Try

    End Sub


    Private Sub Insert(ByVal name As String, ByVal country As String, ByVal country1 As Date, ByVal country2 As Integer, ByVal country4 As String)

        Using cmd As OleDbCommand = New OleDbCommand("INSERT INTO [Student Attendance] VALUES (@Attendance_ID,@Student_Attendance_Type,@Attendance_Date,@Student_ID,@Class_Standard)", conn)
            cmd.CommandType = CommandType.Text

            cmd.Parameters.AddWithValue("@Attendance_ID", name)
            cmd.Parameters.AddWithValue("@Student_Attendance_Type", country)
            cmd.Parameters.AddWithValue("@Attendance_Date", country1)
            cmd.Parameters.AddWithValue("@Student_ID", country2)
            cmd.Parameters.AddWithValue("@Class_Standard", country4)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
        End Using

    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try

            Using cmd As OleDbCommand = New OleDbCommand("SELECT Student_ID,Attendance_Date FROM [Student Attendance] WHERE Student_ID=@Student_ID AND Attendance_Date=@Attendance_Date", conn)
                cmd.CommandType = CommandType.Text
                cmd.Parameters.AddWithValue("@Student_ID", Me.txtStudentID.Text.Trim())
                cmd.Parameters.AddWithValue("@Attendance_Date", Me.txtAttendanceDate.Text.Trim())

                conn.Open()
                Dim result As String = Convert.ToString(cmd.ExecuteScalar())
                conn.Close()
                If String.IsNullOrEmpty(result) Then
                    Insert(Me.txtAttendance_ID.Text.Trim(), Me.ddType.Text.Trim(), Me.txtAttendanceDate.Text.Trim(), Me.txtStudentID.Text.Trim(), Me.txtClassStd.Text.Trim())
                    Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Student Attendance.aspx"
                    Me.Page.Header.Controls.Add(meta)
                Else
                    Response.Write("<script language=""javascript"">alert('Record Already Exists');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Student Attendance.aspx"
                    Me.Page.Header.Controls.Add(meta)
                End If
            End Using

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Calendar1_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles Calendar1.DayRender
        If e.Day.Date.DayOfWeek = DayOfWeek.Sunday Then
            e.Day.IsSelectable = False
        End If

        If e.Day.Date.DayOfWeek = DayOfWeek.Sunday Then
            e.Cell.BackColor = System.Drawing.Color.Blue
            e.Cell.ForeColor = System.Drawing.Color.Black

        End If
    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar1.SelectionChanged
        txtAttendanceDate.Text = Calendar1.SelectedDate.ToShortDateString()

    End Sub


    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub ImageButton1_Click(sender As Object, e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Calendar2.Visible = True
    End Sub

    Protected Sub Calendar2_SelectionChanged(sender As Object, e As EventArgs) Handles Calendar2.SelectionChanged
        txtDate.Text = Calendar2.SelectedDate.ToShortDateString()
        Calendar2.Visible = False
    End Sub

    Protected Sub cmdFilter_Click(sender As Object, e As EventArgs) Handles cmdFilter.Click
        conn.Open()
        Dim da As OleDbDataAdapter = New OleDbDataAdapter("SELECT a.Attendance_ID,a.Student_Attendance_Type,a.Attendance_Date,b.Student_ID,b.Student_Name,b.Student_Roll_Number,c.Class_Standard FROM [Student Attendance] a,[Student] b,[Class] c WHERE b.Student_ID=a.Student_ID AND c.Class_ID=b.Class_ID AND b.Student_Name like '%" & txtStudentName.Text & "%' AND a.Attendance_Date like '%" & txtDate.Text & "%'", conn)
        Dim ds As DataSet = New DataSet()
        da.Fill(ds)
        grid.DataSource = ds
        grid.DataBind()

    End Sub

    Private Sub grid_RowUpdating(sender As Object, e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles grid.RowUpdating
        Dim sql1 = "update [Student Attendance] set Student_Attendance_Type='" & ddType.Text & "' where Attendance_ID=" & txtAttendance.Text & ""
        cmd = New OleDbCommand(sql1, conn)

        'ADD PARAMETERS

        cmd.Parameters.AddWithValue("@Student_Attendance_Type", ddType.Text)


        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then

                Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Staff Register.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()

        Catch ex As Exception

            Response.Write("<script language=""javascript"">alert('Please Select Data');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Staff Register.aspx"
            Me.Page.Header.Controls.Add(meta)
            conn.Close()
        End Try


    End Sub

    Protected Sub grid_SelectedIndexChanged(sender As Object, e As EventArgs) Handles grid.SelectedIndexChanged

        Dim selectedRowIndex As Integer
        selectedRowIndex = grid.SelectedIndex
        Dim row As GridViewRow = grid.Rows(selectedRowIndex)

        txtAttendance.Text = row.Cells(0).Text
        ddType.Text = row.Cells(1).Text
        txtAttendanceDate.Text = row.Cells(2).Text
        txtStudentName.Text = row.Cells(4).Text
        txtRollNumber.Text = row.Cells(5).Text
        txtClassName.Text = row.Cells(6).Text
    End Sub

End Class