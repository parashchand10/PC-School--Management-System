﻿Imports System.Data.OleDb

Public Class Student
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call detail()
     

        Dim pass As String = txtPassword.Text
        txtPassword.TextMode = TextBoxMode.Password
        txtPassword.Attributes.Add("value", pass)


        Label2.Visible = False
        txtStudentID.Visible = False
        lblClassID.Visible = False
        txtClassID.Visible = False

        lblClassID.Visible = False
        txtAdmissionID.Visible = False
        txtFee.Visible = False
        txtFeeID.Visible = False
        lblAdmissionID.Visible = False

        txtActivity.Visible = False

        If txtStudentID.Text <> txtFee.Text Then
            cmdExit.Visible = False
        ElseIf txtStudentID.Text = txtFee.Text Then
            cmdExit.Visible = True
        End If
    End Sub

    Private Sub fee()
        Dim sql1 = "SELECT a.Student_ID FROM [StudentClass] a,[Student] b WHERE a.Student_ID=b.Student_ID AND a.Student_ID=" & txtStudentID.Text & ""
        cmd = New OleDbCommand(sql1, conn)

        conn.Open()
        Dim r As OleDbDataReader = cmd.ExecuteReader

        If (r.HasRows) Then
            If (r.Read()) Then

                txtFee.Text = r("Student_ID").ToString

            Else

                MsgBox("No rows found!")

            End If
        End If

        r.Close()
        conn.Close()
    End Sub

    Private Sub activity()
        Dim sql1 = "SELECT a.Activity_Form_ID FROM [Activity Form] a,[Student] b WHERE b.Student_ID=a.Student_ID AND a.Student_ID=" & txtStudentID.Text & ""
        cmd = New OleDbCommand(sql1, conn)

        conn.Open()
        Dim r As OleDbDataReader = cmd.ExecuteReader

        If (r.HasRows) Then
            If (r.Read()) Then

                txtActivity.Text = r("Activity_Form_ID").ToString

            Else

                MsgBox("No rows found!")

            End If
        End If

        r.Close()
        conn.Close()
    End Sub

    Private Sub detail()
        If Not Me.IsPostBack Then
            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then
                txtStudentID.Text = Request.QueryString("tmp1").ToString()


                Dim sql1 = "SELECT a.Student_ID,a.Student_Email_ID,a.Student_Roll_Number,a.Student_Password,a.Student_Name,a.Student_Address,a.Student_Caste,a.Student_Gender,a.Student_Date_of_Birth,a.Student_Mobile_Number,a.Student_Father_Name,a.Student_Mother_Name,c.Photo,c.Admission_ID,b.Class_ID,b.Class_Standard FROM [Student] a,[Class] b,[Admission] c WHERE c.Admission_ID=a.Admission_ID AND b.Class_ID=a.Class_ID AND a.Student_ID=" & txtStudentID.Text & ""
                cmd = New OleDbCommand(sql1, conn)

                conn.Open()
                Dim r1 As OleDbDataReader = cmd.ExecuteReader

                If (r1.HasRows) Then
                    If (r1.Read()) Then

                        txtStudentID.Text = r1("Student_ID")
                        txtRollNumber.Text = r1("Student_Roll_Number")
                        txtEmailID.Text = r1("Student_Email_ID").ToString
                        txtPassword.Text = r1("Student_Password").ToString
                        txtStudentName.Text = r1("Student_Name").ToString
                        txtAddress.Text = r1("Student_Address").ToString
                        txtCaste.Text = r1("Student_Caste").ToString
                        txtGender.Text = r1("Student_Gender").ToString
                        txtDateofBirth.Text = r1("Student_Date_of_Birth").ToString
                        txtStudentMobileNumber.Text = r1("Student_Mobile_Number").ToString

                        txtFatherName.Text = r1("Student_Father_Name").ToString
                        txtMotherName.Text = r1("Student_Mother_Name").ToString
                        txtPhoto.Text = r1("Photo").ToString
                        txtAdmissionID.Text = r1("Admission_ID")
                        Image1.ImageUrl = "Student.ashx?ID=" + txtAdmissionID.Text
                        txtClassID.Text = r1("Class_ID")
                        txtClassStandard.Text = r1("Class_Standard").ToString

                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r1.Close()
                conn.Close()
            End If
        End If
    
    End Sub

    Protected Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click

        Dim sql = "update [Student] set Student_Email_ID='" & txtEmailID.Text & "',Student_Password='" & txtPassword.Text & "',Student_Name='" & txtStudentName.Text & "',Student_Address='" & txtAddress.Text & "',Student_Mobile_Number=" & txtStudentMobileNumber.Text & " where Student_ID=" & txtStudentID.Text & ""
        cmd = New OleDbCommand(sql, conn)


        'ADD PARAMETERS
        cmd.Parameters.AddWithValue("@Student_Email_ID", txtEmailID.Text)
        cmd.Parameters.AddWithValue("@Student_Password", txtPassword.Text)
        cmd.Parameters.AddWithValue("@Student_Name", txtStudentName.Text)
        cmd.Parameters.AddWithValue("@Student_Address", txtAddress.Text)
        cmd.Parameters.AddWithValue("@Student_Mobile_Number", txtStudentMobileNumber.Text)



        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
             
            End If
            conn.Close()

        Catch ex As Exception

            conn.Close()
        End Try

    End Sub


    Public Shared fees As Integer
    Public Shared feedback As Integer
    Public Shared feedback1 As Integer
    Protected Sub DropDownList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DropDownList1.SelectedIndexChanged
        If DropDownList1.SelectedValue = "School Feedback" Then
            feedback1 = txtStudentID.Text
            Response.Redirect("Add School Feedback.aspx?tmp1=" + txtClassStandard.Text)
        End If

        If DropDownList1.SelectedValue = "Student Feedback" Then
            feedback = txtStudentID.Text
            Response.Redirect("Add Feedback.aspx?tmp1=" + txtClassID.Text)
        End If


        If DropDownList1.SelectedValue = "Activity Registration" Then
            Response.Redirect("Activity Registration Form.aspx?tmp=" + txtStudentID.Text)
        End If


        If DropDownList1.SelectedValue = "Attendance" Then
            fees = txtStudentID.Text
            Response.Redirect("Student Attendance Report.aspx")
        End If
    End Sub

    Protected Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            Dim pass As String = txtPassword.Text
            txtPassword.TextMode = TextBoxMode.Password
            txtPassword.Attributes.Add("value", pass)
        End If

        If CheckBox1.Checked Then
            txtPassword.TextMode = TextBoxMode.SingleLine
        End If
    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class
