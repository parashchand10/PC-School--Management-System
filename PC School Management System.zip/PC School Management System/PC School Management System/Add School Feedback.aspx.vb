﻿Imports System.Data.OleDb

Public Class Add_School_Feedback
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call feeback()
        Call detail()

        txtStudentID.Text = Student.feedback1

        lblClass.Visible = False
        txtStudentID.Visible = False
        txtClassID.Visible = False
        lblSchoolFeedback.Visible = False
        txtSchoolFeedbackID.Visible = False
    End Sub

    Private Sub feeback()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(50000, 80000)  ' Get random numbers 
        txtSchoolFeedbackID.Text = intResult.ToString
    End Sub

    Private Sub detail()
        If Not Me.IsPostBack Then
            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then
                txtClassStd.Text = Request.QueryString("tmp1").ToString()

                Dim sql1 = "SELECT b.Class_Standard,b.Class_ID,a.Student_ID,a.Student_Name FROM [Student] a,[Class] b WHERE b.Class_ID=a.Class_ID AND b.Class_Standard='" & txtClassStd.Text & "'"
                cmd = New OleDbCommand(sql1, conn)

                conn.Open()
                Dim r1 As OleDbDataReader = cmd.ExecuteReader

                If (r1.HasRows) Then
                    If (r1.Read()) Then
                        txtClassStd.Text = r1("Class_Standard")
                        txtClassID.Text = r1("Class_ID")
                        txtStudentID.Text = r1("Student_ID")
                        txtStudentName.Text = r1("Student_Name")
                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r1.Close()
                conn.Close()
            End If
        End If

    End Sub

    Private Sub Insert(ByVal name As Integer, ByVal country2 As String, ByVal country4 As String, ByVal country5 As String, ByVal country7 As String, ByVal country8 As String, ByVal country9 As Integer)

        Using cmd As OleDbCommand = New OleDbCommand("INSERT INTO [School Feedback] VALUES (@School_Feedback_ID,@Q1,@Q2,@Q3,@Suggestion,@Student_ID,@Class_ID)", conn)
            cmd.CommandType = CommandType.Text

            cmd.Parameters.AddWithValue("@School_Feedback_ID", name)

            cmd.Parameters.AddWithValue("@Q1", country2)
            cmd.Parameters.AddWithValue("@Q2", country4)
            cmd.Parameters.AddWithValue("@Q3", country5)

            cmd.Parameters.AddWithValue("@Suggestion", country7)
            cmd.Parameters.AddWithValue("@Student_ID", country8)
            cmd.Parameters.AddWithValue("@Class_ID", country9)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
        End Using

    End Sub


    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try

            Using cmd As OleDbCommand = New OleDbCommand("SELECT b.Student_ID FROM [School Feedback] a,[Student] b WHERE b.Student_ID=a.Student_ID AND b.Student_ID=b.@Student_ID", conn)
                cmd.CommandType = CommandType.Text
                cmd.Parameters.AddWithValue("@Student_ID", Me.txtStudentID.Text.Trim())
                conn.Open()
                Dim result As String = Convert.ToString(cmd.ExecuteScalar())
                conn.Close()
                If String.IsNullOrEmpty(result) Then
                    Insert(Me.txtSchoolFeedbackID.Text.Trim(), Me.rbQ1.Text.Trim(), Me.rbQ2.Text.Trim(), Me.rbQ3.Text.Trim(), Me.txtSuggestion.Text.Trim(), Me.txtStudentID.Text.Trim(), Me.txtClassID.Text.Trim())

                    Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Homepage.aspx"
                    Me.Page.Header.Controls.Add(meta)

                Else
                    Response.Write("<script language=""javascript"">alert('Record Already Exists');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Homepage.aspx"
                    Me.Page.Header.Controls.Add(meta)

                End If
            End Using

        Catch ex As Exception

        End Try
    End Sub
  
    Protected Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class