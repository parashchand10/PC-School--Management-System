﻿Imports System.Data.OleDb

Public Class E_Book
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call Pdf()

        If Not IsPostBack Then
            BindGrid()
        End If

        


    End Sub

    Private Sub BindGrid()
        conn.Open()
        Dim Query = "Select E_Book_ID,E_Book_Title,E_Book_Category from E_Book"
        Dim da As OleDb.OleDbDataAdapter = New OleDb.OleDbDataAdapter(Query, conn)
        Dim ds As DataSet = New DataSet()
        da.Fill(ds)
        GridView1.DataSource = ds
        GridView1.DataBind()
        conn.Close()

    End Sub

    Private Sub Pdf()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [E_Book_Category] FROM [E_Book]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddBookCategory.DataSource = cmd.ExecuteReader()
                ddBookCategory.DataTextField = "E_Book_Category"

                ddBookCategory.DataBind()
                conn.Close()
            End Using
            ddBookCategory.Items.Insert(0, New ListItem("--Select E-Book--", ""))
        End If
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

   
    Protected Sub ddBookCategory_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddBookCategory.SelectedIndexChanged
        Dim dt As New DataTable()

        conn.Open()
        If ddBookCategory.SelectedValue <> "" Then
            Dim cmd As New OleDb.OleDbCommand("SELECT E_Book_ID,E_Book_Title,E_Book_Category from [E_Book] WHERE E_Book_Category=@Book", conn)
            cmd.Parameters.AddWithValue("@Book", ddBookCategory.SelectedValue)
            Dim da As New OleDb.OleDbDataAdapter(cmd)
            da.Fill(dt)
        End If
        conn.Close()

        GridView1.DataSource = dt
        GridView1.DataBind()

        GridView1.Visible = True

    End Sub

    Protected Sub GridView1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles GridView1.SelectedIndexChanged

        conn.Open()
        Dim com As OleDb.OleDbCommand = New OleDb.OleDbCommand("select E_Book_Title,E_Book_Category,ContentType,Data from E_Book where E_Book_ID=@id", conn)
        com.Parameters.AddWithValue("id", GridView1.SelectedRow.Cells(1).Text)
        Dim dr As OleDb.OleDbDataReader = com.ExecuteReader()

        If dr.Read() Then
            Response.Clear()
            Response.Buffer = True
            Response.ContentType = dr("ContentType").ToString()
            Response.AddHeader("content-disposition", "attachment;filename=" & dr("E_Book_Title").ToString())
            Response.Charset = ""
            Response.Cache.SetCacheability(HttpCacheability.NoCache)
            Response.BinaryWrite(CType(dr("Data"), Byte()))
            Response.[End]()
        End If

    End Sub

End Class