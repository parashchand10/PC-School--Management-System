﻿Imports System.Data.OleDb

Public Class Add_Timetable
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call selectclass()
        Call period()
        Call day()
        Call timetable()

        If Not IsPostBack Then
            BindGrid()
        End If

        txtTimetable.Visible = False
        txtSubjectName.Visible = False
        txtClassStandard.Visible = False
        txtPeriodName.Visible = False
        txtTiming.Visible = False
        lblTimeTableID.Visible = False
        txtTimetableID.Visible = False
        txtDayID.Visible = False
        txtPeriodID.Visible = False
        txtClassID.Visible = False
        txtStaffID.Visible = False
        txtSubjectID.Visible = False

        grid.Columns(0).Visible = False
        grid.Columns(1).Visible = False
        grid.Columns(2).Visible = False
        grid.Columns(3).Visible = False
        grid.Columns(4).Visible = False
        grid.Columns(5).Visible = False

        If ddDayName.SelectedValue <> "" Then

            Using cmd As New OleDbCommand("SELECT a.Timetable_ID,d.Class_ID,c.Day_ID,e.Subject_ID,f.Staff_ID,b.Period_ID,c.Day_Name,b.Period_Name,b.Timing,f.Staff_Name,d.Class_Standard from [Timetable] a,[Period] b,[Day] c,[Class] d,[Subject] e,[Staff] f where a.Period_ID=b.Period_ID and a.Day_ID=c.Day_ID and a.Class_ID=d.Class_ID and a.Subject_ID=e.Subject_ID and a.Staff_ID=f.Staff_ID and c.Day_Name='" & ddDayName.SelectedValue & "'")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                grid.DataSource = cmd.ExecuteReader()
                grid.DataBind()
                conn.Close()
            End Using

        End If
    End Sub

    'Bind Data with GridView Control
    Private Sub BindGrid()
        Dim sql = "SELECT a.Timetable_ID,d.Class_ID,c.Day_ID,e.Subject_ID,f.Staff_ID,b.Period_ID,c.Day_Name,b.Period_Name,b.Timing,d.Class_Standard,e.Subject_Name,f.Staff_Name from [Timetable] a,[Period] b,[Day] c,[Class] d,[Subject] e,[Staff] f WHERE a.Period_ID=b.Period_ID AND a.Day_ID=c.Day_ID AND a.Class_ID=d.Class_ID AND a.Subject_ID=e.Subject_ID AND a.Staff_ID=f.Staff_ID"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        grid.DataSource = cmd.ExecuteReader()
        grid.DataBind()
        conn.Close()

    End Sub

    Private Sub timetable()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(50000, 90000)  ' Get random numbers 
        txtTimetableID.Text = intResult.ToString
    End Sub

  

    Private Sub day()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Day_Name] FROM [Day]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddDayName.DataSource = cmd.ExecuteReader()
                ddDayName.DataTextField = "Day_Name"

                ddDayName.DataBind()
                conn.Close()
            End Using

            ddDayName.Items.Insert(0, New ListItem("--Select Day--", ""))
        End If

    End Sub

    Private Sub period()

        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Period_Name] FROM [Period]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddPeriodName.DataSource = cmd.ExecuteReader()
                ddPeriodName.DataTextField = "Period_Name"

                ddPeriodName.DataBind()
                conn.Close()
            End Using

            ddPeriodName.Items.Insert(0, New ListItem("--Select Period--", ""))
        End If
    End Sub

    Private Sub selectclass()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddClassStandard.DataSource = cmd.ExecuteReader()
                ddClassStandard.DataTextField = "Class_Standard"

                ddClassStandard.DataBind()
                conn.Close()
            End Using
            ddClassStandard.Items.Insert(0, New ListItem("--Select Class--", ""))
        End If

    End Sub

    Protected Sub ddClassStandard_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddClassStandard.SelectedIndexChanged
        Try

        If ddClassStandard.SelectedValue <> "" Then

            Using cmd As New OleDbCommand("select a.Subject_Name from Subject a,Class b where a.Class_ID=b.Class_ID and b.Class_Standard='" & ddClassStandard.SelectedValue & "'")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()

                ddSubjectName.DataSource = cmd.ExecuteReader()
                ddSubjectName.DataTextField = "Subject_Name"

                ddSubjectName.DataBind()
                conn.Close()

            End Using

            ddSubjectName.Items.Insert(0, New ListItem("--Select Class--", "0"))
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ddDayName_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddDayName.SelectedIndexChanged
        Dim query As String = "select Day_ID,Day_Name from [Day] where Day_Name='" & ddDayName.SelectedValue & "'"
        cmd = New OleDbCommand(query, conn)

        Try
            conn.Open()
            Dim r As OleDbDataReader = cmd.ExecuteReader

            If (r.HasRows) Then
                If (r.Read()) Then
                    txtDayID.Text = r("Day_ID").ToString()
                    ddDayName.Text = r("Day_Name").ToString()
                End If
            End If

        Catch es As Exception

        End Try
    End Sub

    Protected Sub ddSubjectName_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddSubjectName.SelectedIndexChanged

        Dim query As String = "select a.Subject_ID,a.Subject_Name,b.Staff_ID,b.Staff_Name,c.Class_ID,c.Class_Standard from [Subject] a,[Staff] b,[Class] c where a.Staff_ID=b.Staff_ID and a.Class_ID=c.Class_ID and a.Subject_Name='" & ddSubjectName.SelectedValue & "'"
        cmd = New OleDbCommand(query, conn)

        Try
            conn.Open()
            Dim r As OleDbDataReader = cmd.ExecuteReader

            If (r.HasRows) Then
                If (r.Read()) Then
                    txtSubjectID.Text = r("Subject_ID").ToString()
                    txtSubjectName.Text = r("Subject_Name").ToString()

                    txtStaffID.Text = r("Staff_ID").ToString()
                    txtStaffName.Text = r("Staff_Name").ToString()

                    txtClassID.Text = r("Class_ID").ToString()
                    txtClassStandard.Text = r("Class_Standard").ToString()
             
                End If
            End If

        Catch es As Exception

        End Try

        If ddSubjectName.SelectedValue = txtSubjectName.Text Then
            Response.Write("<script language=""javascript"">alert('Data will match');</script>")
        Else
            Response.Write("<script language=""javascript"">alert('Data will not match');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Add Timetable.aspx"
            Me.Page.Header.Controls.Add(meta)
        End If

    End Sub

    Protected Sub ddPeriodName_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddPeriodName.SelectedIndexChanged
        Dim query As String = "select Period_ID,Period_Name,Timing from [Period] where Period_Name='" & ddPeriodName.SelectedValue & "'"
        cmd = New OleDbCommand(query, conn)

        Try
            conn.Open()
            Dim r As OleDbDataReader = cmd.ExecuteReader

            If (r.HasRows) Then
                If (r.Read()) Then
                    txtPeriodID.Text = r("Period_ID").ToString()
                    txtPeriodName.Text = r("Period_Name").ToString()
                    txtTiming.Text = r("Timing").ToString()
                End If
            End If

        Catch es As Exception

        End Try
    End Sub


    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try

            Using cmd As OleDbCommand = New OleDbCommand("SELECT Period_ID,Subject_ID,Staff_ID FROM Timetable WHERE Day_ID=@Day_ID AND Period_ID = @Period_ID AND Class_ID=@Class_ID AND Subject_ID=@Subject_ID AND Staff_ID=@Staff_ID", conn)
                cmd.CommandType = CommandType.Text
                cmd.Parameters.AddWithValue("@Day_ID", Me.txtDayID.Text.Trim())
                cmd.Parameters.AddWithValue("@Period_ID", Me.txtPeriodID.Text.Trim())
                cmd.Parameters.AddWithValue("@Class_ID", Me.txtClassID.Text.Trim())
                cmd.Parameters.AddWithValue("@Subject_ID", Me.txtSubjectID.Text.Trim())
                cmd.Parameters.AddWithValue("@Staff_ID", Me.txtStaffID.Text.Trim())
                conn.Open()
                Dim result As String = Convert.ToString(cmd.ExecuteScalar())
                conn.Close()
                If String.IsNullOrEmpty(result) Then
                    Insert(Me.txtTimetableID.Text.Trim(), Me.txtDayID.Text.Trim(), Me.txtPeriodID.Text.Trim(), Me.txtClassID.Text.Trim(), Me.txtSubjectID.Text.Trim(), Me.txtStaffID.Text.Trim(), Me.txtClassStandard.Text.Trim())

                    Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Add Timetable.aspx"
                    Me.Page.Header.Controls.Add(meta)

                Else
                    Response.Write("<script language=""javascript"">alert('Record Already Exists');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Add Timetable.aspx"
                    Me.Page.Header.Controls.Add(meta)

                End If
            End Using

        Catch ex As Exception

        End Try

    End Sub

    Private Sub Insert(ByVal name As Integer, ByVal country As Integer, ByVal country1 As Integer, ByVal country2 As Integer, ByVal country4 As Integer, ByVal country5 As Integer, ByVal country6 As String)

        Using cmd As OleDbCommand = New OleDbCommand("INSERT INTO Timetable VALUES (@Timetable_ID,@Day_ID,@Period_ID,@Class_ID,@Subject_ID,@Staff_ID,@Class_Standard)", conn)
            cmd.CommandType = CommandType.Text
            cmd.Parameters.AddWithValue("@Timetable_ID", name)
            cmd.Parameters.AddWithValue("@Day_ID", country)
            cmd.Parameters.AddWithValue("@Period_ID", country1)
            cmd.Parameters.AddWithValue("@Class_ID", country2)
            cmd.Parameters.AddWithValue("@Subject_ID", country4)
            cmd.Parameters.AddWithValue("@Staff_ID", country5)
            cmd.Parameters.AddWithValue("@Class_Standard", country6)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
        End Using

    End Sub

    Protected Sub cmdRefresh_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdRefresh.Click
        Response.Redirect(Request.Url.AbsoluteUri)
    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Private Sub grid_RowDeleting(sender As Object, e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grid.RowDeleting
        Dim sql1 = "delete from [Timetable] where Timetable_ID=" & Trim(txtTimetable.Text) & ""
        cmd = New OleDbCommand(sql1, conn)


        'ADD PARAMETERS
        cmd.Parameters.AddWithValue("@Class_ID", txtClassID.Text)
        cmd.Parameters.AddWithValue("@Class_Year", txtDayID.Text)
        cmd.Parameters.AddWithValue("@Class_Standard", txtPeriodID.Text)
        cmd.Parameters.AddWithValue("@Student_Intake", txtSubjectID.Text)


        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Removed');</script>")
            End If
            conn.Close()

        Catch ex As Exception

            conn.Close()
        End Try
        grid.DataBind()
        Dim meta As New HtmlMeta()
        meta.HttpEquiv = "Refresh"
        meta.Content = "0;url=Add Timetable.aspx"
        Me.Page.Header.Controls.Add(meta)

       
    End Sub

    Private Sub grid_RowUpdating(sender As Object, e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles grid.RowUpdating
        Dim sql1 = "update Timetable set Class_ID=" & txtClassID.Text & ",Day_ID=" & txtDayID.Text & ",Period_ID=" & txtPeriodID.Text & ",Subject_ID=" & txtSubjectID.Text & ",Staff_ID=" & txtStaffID.Text & " where Timetable_ID=" & txtTimetable.Text & ""
        cmd = New OleDbCommand(sql1, conn)

        'ADD PARAMETERS

        cmd.Parameters.AddWithValue("@Class_ID", txtClassID.Text)
        cmd.Parameters.AddWithValue("@Day_ID", txtDayID.Text)
        cmd.Parameters.AddWithValue("@Period_ID", txtPeriodID.Text)
        cmd.Parameters.AddWithValue("@Subject_ID", txtSubjectID.Text)
        cmd.Parameters.AddWithValue("@Staff_ID", txtStaffID.Text)

        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then

                Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Add Timetable.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()

        Catch ex As Exception
            Response.Write("<script language=""javascript"">alert('Please Select Data');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Add Timetable.aspx"
            Me.Page.Header.Controls.Add(meta)
            conn.Close()
        End Try
        grid.DataBind()

    End Sub

    Protected Sub grid_SelectedIndexChanged(sender As Object, e As EventArgs) Handles grid.SelectedIndexChanged
        Dim selectedRowIndex As Integer
        selectedRowIndex = grid.SelectedIndex
        Dim row As GridViewRow = grid.Rows(selectedRowIndex)

        txtClassID.Text = row.Cells(0).Text
        txtDayID.Text = row.Cells(1).Text
        txtSubjectID.Text = row.Cells(2).Text
        txtStaffID.Text = row.Cells(3).Text
        txtPeriodID.Text = row.Cells(4).Text
        txtTimetable.Text = row.Cells(5).Text

    End Sub

End Class