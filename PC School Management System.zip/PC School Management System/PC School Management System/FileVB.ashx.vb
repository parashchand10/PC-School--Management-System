﻿Imports System.Web
Imports System.Web.Services
Imports System.Data.OleDb

Public Class FileVB
    Implements System.Web.IHttpHandler

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        Dim id As Integer = context.Request.QueryString("ID").ToString()

        Dim fileName As String = 0

        Dim dt As DataTable = New DataTable
        Dim Sql = "SELECT [E-Book_Title],[E-Book_Category],[Content_Type],[Data] FROM [E-Book] WHERE [E-Book_ID]=@ID"
        cmd = New OleDbCommand(Sql, conn)
        cmd.Parameters.Add("@ID", OleDbType.Integer).Value = id

        Try
            conn.Open()
            Dim reader As OleDbDataReader = cmd.ExecuteReader
            dt.Load(reader)
            Dim name As String = dt.Rows(0)("E-Book_Title").ToString()
            Dim documentbytes As Byte() = dt.Rows(0)("Data")
            Dim contenttype As String = dt.Rows(0)("Content_Type").ToString()

            context.Response.Buffer = True
            context.Response.Charset = ""

            If context.Request.QueryString("download") = "1" Then
                context.Response.AppendHeader("Content-Disposition", "attachment; filename=" & fileName)
            End If

            context.Response.Cache.SetCacheability(HttpCacheability.NoCache)
            context.Response.ContentType = "application/pdf"
            context.Response.BinaryWrite(documentbytes)
            context.Response.Flush()
            context.Response.End()

        Catch ex As Exception
            MsgBox(ex.Message)
            conn.Close()
        End Try
        context.Response.ContentType = "text/plain"
        context.Response.Write("Hello World!")

    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class