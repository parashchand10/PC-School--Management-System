﻿Imports System.Data.OleDb

Public Class Student_Fee_Details
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call classst()

        If Not IsPostBack Then

            BindGrid()
        End If

        grid.Columns(1).Visible = False

        Dim currentQuarter As Integer = (DateTime.Now.Month - 1) / 3
        Dim nextQuarterStartDate As DateTime = New DateTime(DateTime.Now.Year, currentQuarter * 3, 1)
        Dim currentQuarterEndDate As DateTime = nextQuarterStartDate.AddMonths(3).AddDays(-1)

        txtQuarterStart.Text = currentQuarter
        txtQuarterStart.Text = nextQuarterStartDate
        txtQuarterEnd.Text = currentQuarterEndDate

    End Sub

    Private Sub classst()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddClass.DataSource = cmd.ExecuteReader()
                ddClass.DataTextField = "Class_Standard"

                ddClass.DataBind()
                conn.Close()
            End Using

            ddClass.Items.Insert(0, New ListItem("--Select Class--", "0"))
        End If
    End Sub

    Private Sub BindGrid()
        Dim sql = " SELECT a.Student_ID,a.Acdemic_Year,a.Student_Name,b.Class_ID,b.Class_Standard,c.Fee_ID,c.Quarterly_Fee,c.Fee_Start_Date,c.Fee_End_Date,c.Late_Fee FROM [Student] a,[Class] b,[Fee] c WHERE b.Class_ID=a.Class_ID AND c.Class_ID=b.Class_ID"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        grid.DataSource = cmd.ExecuteReader()
        grid.DataBind()
        conn.Close()

    End Sub

    Protected Sub cmdFilter_Click(sender As Object, e As EventArgs) Handles cmdFilter.Click
        conn.Open()
        Dim da As OleDbDataAdapter = New OleDbDataAdapter(" SELECT a.Student_ID,a.Acdemic_Year,a.Student_Name,b.Class_ID,b.Class_Standard,c.Fee_ID,c.Quarterly_Fee,c.Fee_Start_Date,c.Fee_End_Date,c.Late_Fee FROM [Student] a,[Class] b,[Fee] c WHERE b.Class_ID=a.Class_ID AND c.Class_ID=b.Class_ID AND a.Student_Name like '%" & txtStudentName.Text & "%'", conn)
        Dim ds As DataSet = New DataSet()
        da.Fill(ds)
        grid.DataSource = ds
        grid.DataBind()
    End Sub

    Dim status As String = "Fee Pending"

    Private Sub Insert(ByVal studfee As Integer, ByVal feeid As Integer, ByVal feestatus As String, ByVal studdid As Integer, ByVal classid As Integer)
        Try

        Using cmd As OleDbCommand = New OleDbCommand("INSERT INTO StudentClass VALUES (@StudentClass_ID,@Fee_ID,@Fee_Status,@Student_ID,@Class_ID)", conn)
            cmd.CommandType = CommandType.Text
            cmd.Parameters.AddWithValue("@StudentClass_ID", studfee)
            cmd.Parameters.AddWithValue("@Fee_ID", feeid)
            cmd.Parameters.AddWithValue("@Fee_Status", feestatus)

            cmd.Parameters.AddWithValue("@Student_ID", studdid)
            cmd.Parameters.AddWithValue("@Class_ID", classid)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
        End Using

        Catch ex As Exception

        End Try

    End Sub

    Protected Sub cmdFee_Click(sender As Object, e As EventArgs) Handles cmdFee.Click
        For Each gvrow As GridViewRow In grid.Rows
            Dim checkbox = TryCast(gvrow.FindControl("CheckBox1"), CheckBox)

            If checkbox.Checked Then
                Dim lblsid = TryCast(gvrow.FindControl("lblsid"), Label)
                Dim lblfeeid = TryCast(gvrow.FindControl("lblfeeid"), Label)
                Dim lblNumber = TryCast(gvrow.FindControl("lblNumber"), Label)
                Dim Label1 = TryCast(gvrow.FindControl("Label1"), Label)
                Dim Label3 = TryCast(gvrow.FindControl("Label3"), Label)


                Using cmd As OleDbCommand = New OleDbCommand("SELECT Student_ID,Class_ID FROM StudentClass WHERE Student_ID=@Student_ID AND Class_ID=@Class_ID", conn)
                    cmd.CommandType = CommandType.Text
                    cmd.Parameters.AddWithValue("@Student_ID", Label1.Text.Trim())
                    cmd.Parameters.AddWithValue("@Class_ID", Label3.Text.Trim())
                    conn.Open()
                    Dim result As String = Convert.ToString(cmd.ExecuteScalar())
                    conn.Close()
                    If String.IsNullOrEmpty(result) Then
                        Insert(lblsid.Text.Trim(), lblfeeid.Text.Trim(), status, Label1.Text.Trim(), Label3.Text.Trim())
                        Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                        Dim meta As New HtmlMeta()
                        meta.HttpEquiv = "Refresh"
                        meta.Content = "0;url=Student Fee Details.aspx"
                        Me.Page.Header.Controls.Add(meta)

                    Else
                        Response.Write("<script language=""javascript"">alert('Record Already Exits');</script>")
                        Dim meta As New HtmlMeta()
                        meta.HttpEquiv = "Refresh"
                        meta.Content = "0;url=Student Fee Details.aspx"
                        Me.Page.Header.Controls.Add(meta)

                    End If
                End Using
            End If
        Next
    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub ddClass_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddClass.SelectedIndexChanged
        Dim dt As New DataTable()

        conn.Open()
        If ddClass.SelectedValue <> "" Then
            Dim cmd As New OleDb.OleDbCommand("SELECT a.Student_ID,a.Student_Roll_Number,a.Acdemic_Year,a.Student_Name,b.Class_ID,b.Class_Standard,c.Fee_ID,c.Quarterly_Fee,c.Fee_Start_Date,c.Fee_End_Date,c.Late_Fee FROM [Student] a,[Class] b,[Fee] c WHERE b.Class_ID=a.Class_ID AND c.Class_ID=b.Class_ID AND b.Class_Standard=@Book", conn)
            cmd.Parameters.AddWithValue("@Book", ddClass.SelectedValue)
            Dim da As New OleDb.OleDbDataAdapter(cmd)
            da.Fill(dt)
        End If
        conn.Close()

        grid.DataSource = dt
        grid.DataBind()

    End Sub

    Protected Sub CheckAll(ByVal sender As Object, ByVal e As EventArgs)
        Dim chckheader As CheckBox = CType(grid.HeaderRow.FindControl("CheckBox2"), CheckBox)

        For Each row As GridViewRow In grid.Rows
            Dim chckrw As CheckBox = CType(row.FindControl("CheckBox1"), CheckBox)

            If chckheader.Checked = True Then
                chckrw.Checked = True
            Else
                chckrw.Checked = False
            End If
        Next
    End Sub

End Class