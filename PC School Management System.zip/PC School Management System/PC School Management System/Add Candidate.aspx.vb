﻿Imports System.Data.OleDb
Imports System.IO

Public Class Add_Candidate
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call candidate()

        lblCandidate.Visible = False
        txtCandidateID.Visible = False
      
        txtVacancyID.Visible = False
        lblVacancyID.Visible = False
        txtVacancyID.Text = Vacancy.number
    End Sub

    Private Sub candidate()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(40000, 80000)  ' Get random numbers 
        txtCandidateID.Text = intResult.ToString

    End Sub

    Dim status As String = "In Progress"

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try

            Dim filename As String = Path.GetFileName(Candidate_Photo.PostedFile.FileName)
            Dim contentType As String = Candidate_Photo.PostedFile.ContentType

            Dim filename1 As String = Path.GetFileName(ResumeUpload.PostedFile.FileName)
            Dim contentType1 As String = ResumeUpload.PostedFile.ContentType

            Using fs As Stream = Candidate_Photo.PostedFile.InputStream

                Using br As BinaryReader = New BinaryReader(fs)

                    Dim bytes As Byte() = br.ReadBytes(CType(fs.Length, Int32))

                    Using fs1 As Stream = ResumeUpload.PostedFile.InputStream

                        Using br1 As BinaryReader = New BinaryReader(fs1)

                            Dim bytes1 As Byte() = br1.ReadBytes(CType(fs1.Length, Int32))

                            Dim sql1 = "INSERT INTO [Candidate] ([Candidate_ID],[Candidate_Email_ID],[Candidate_Password],[Candidate_Name],[Candidate_YOP],[Canadidate_Qualification],[Candidate_Mobile_Number],[Candidate_Status],[Candidate_Photo],[Candidate_Data],[Candidate_Contenttype],[CandidateResume],[CandidateData],[CandidateContenttype],[Vacancy_ID]) VALUES (@Candidate_ID, @Candidate_Email_ID,@Candidate_Password,@Candidate_Name,@Candidate_YOP,@Canadidate_Qualification,@Candidate_Mobile_Number,@Candidate_Status,@Candidate_Photo,@Candidate_Data,@Candidate_Contenttype,@CandidateResume,@CandidateData,@CandidateContenttype,@Vacancy_ID)"
                            cmd = New OleDbCommand(sql1, conn)

                            'ADD PARAMETERS
                            cmd.Parameters.AddWithValue("@Candidate_ID", txtCandidateID.Text)
                            cmd.Parameters.AddWithValue("@Candidate_Email_ID", txtCandidateEmailID.Text)
                            cmd.Parameters.AddWithValue("@Candidate_Password", txtCandidatePassword.Text)
                            cmd.Parameters.AddWithValue("@Candidate_Name", txtCandidateFullName.Text)
                            cmd.Parameters.AddWithValue("@Candidate_YOP", txtCandidateYearofExp.Text)
                            cmd.Parameters.AddWithValue("@Canadidate_Qualification", txtCandidateQualification.Text)
                            cmd.Parameters.AddWithValue("@Candidate_Mobile_Number", txtCandidateMobileNumber.Text)

                            cmd.Parameters.AddWithValue("@Candidate_Status", status)

                            cmd.Parameters.Add("@Candidate_Photo", OleDbType.Char).Value = filename
                            cmd.Parameters.Add("@Candidate_Data", OleDbType.VarBinary).Value = bytes
                            cmd.Parameters.Add("@Candidate_Contenttype", OleDbType.Char).Value = contentType

                            cmd.Parameters.Add("@CandidateResume", OleDbType.Char).Value = filename1
                            cmd.Parameters.Add("@CandidateData", OleDbType.VarBinary).Value = bytes1
                            cmd.Parameters.Add("@CandidateContenttype", OleDbType.Char).Value = contentType1

                            'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION

                            cmd.Parameters.AddWithValue("@Vacancy_ID", txtVacancyID.Text)

                            conn.Open()
                            If cmd.ExecuteNonQuery() > 0 Then

                                Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                                Dim meta As New HtmlMeta()
                                meta.HttpEquiv = "Refresh"
                                meta.Content = "0;url=Homepage.aspx"
                                Me.Page.Header.Controls.Add(meta)

                            End If
                            conn.Close()
                        End Using
                    End Using
                End Using
            End Using

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub CheckBox1_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            Dim pass As String = txtCandidatePassword.Text
            txtCandidatePassword.TextMode = TextBoxMode.Password
            txtCandidatePassword.Attributes.Add("value", pass)
        End If

        If CheckBox1.Checked Then
            txtCandidatePassword.TextMode = TextBoxMode.SingleLine
        End If
    End Sub

    Protected Sub cmdVerify_Click1(ByVal sender As Object, ByVal e As EventArgs) Handles cmdVerify.Click
        If Candidate_Photo.HasFile Then
            Dim FileType As String = Path.GetExtension(Candidate_Photo.PostedFile.FileName).ToLower().Trim()

            If FileType <> ".jpeg" Then
                Response.Write("<script language=""javascript"">alert('Image is not correct. Only .jpeg file formats are allowed.');</script>")

            Else
                Response.Write("<script language=""javascript"">alert('Image is correct');</script>")


            End If
        End If
    End Sub

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class