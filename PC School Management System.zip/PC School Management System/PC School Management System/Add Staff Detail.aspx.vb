﻿Imports System.Data.OleDb
Imports System.IO

Public Class Add_Staff_Detail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call vacancy()
        Call staff()

        lblStaffID.Visible = False
        txtStaffID.Visible = False

        Calendar3.Visible = False

        lblPhoto.Visible = False
        txtStaffPhoto.Visible = False
        lblData.Visible = False
        txtData.Visible = False
        lblContenttype.Visible = False
        txtContenttype.Visible = False

    End Sub


    Private Sub staff()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(40000, 80000)  ' Get random numbers 
        txtStaffID.Text = intResult.ToString
        txtCandidateID.Visible = False
        lblCandidate.Visible = False
    End Sub

    Private Sub vacancy()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Vacancy_Designation] FROM [Vacancy]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddDesignation.DataSource = cmd.ExecuteReader()
                ddDesignation.DataTextField = "Vacancy_Designation"

                ddDesignation.DataBind()
                conn.Close()
            End Using

            ddDesignation.Items.Insert(0, New ListItem("--Select Designation--", "0"))
        End If
    End Sub

    Protected Sub ddPost_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddPost.SelectedIndexChanged
        If ddPost.SelectedValue = "Director" Or ddPost.SelectedValue = "Principal" Or ddPost.SelectedValue = "Head Master" Or ddPost.SelectedValue = "Non Teaching Staff" Then

            lblDesignation.Visible = False
            txtDesignation.Visible = False
            lblTeacherType.Visible = False
            ddTeacherType.Visible = False
            Label19.Visible = False

            Label27.Visible = False
            ddDesignation.Visible = False
            ListBox1.Visible = False
           
            Label12.Visible = True
            CandidatePhoto.Visible = True
        ElseIf ddPost.SelectedValue = "Teacher" Then

            Label12.Visible = False
            CandidatePhoto.Visible = False
            lblDesignation.Visible = True
            txtDesignation.Visible = True
            lblTeacherType.Visible = True
            ddTeacherType.Visible = True
            Label19.Visible = True

            Label27.Visible = True
            ddDesignation.Visible = True
            ListBox1.Visible = True

        End If
    End Sub


    Protected Sub ddDesignation_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddDesignation.SelectedIndexChanged
        If ddDesignation.SelectedValue <> "" Then

            Using cmd As New OleDbCommand("select b.Candidate_ID from Vacancy a,Candidate b where a.Vacancy_ID=b.Vacancy_ID and Candidate_Status='Selected' and a.Vacancy_Designation='" & ddDesignation.SelectedValue & "'")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ListBox1.DataSource = cmd.ExecuteReader()
                ListBox1.DataTextField = "Candidate_ID"

                ListBox1.DataBind()
                conn.Close()
            End Using

            ListBox1.Items.Insert(0, New ListItem("--Select--", "0"))
        End If


    End Sub


    Protected Sub ListBox1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ListBox1.SelectedIndexChanged
        Image1.ImageUrl = "Candidate.ashx?ID=" + ListBox1.Text

        Dim sql1 = "SELECT * FROM [Candidate] where Candidate_ID=" & ListBox1.Text & ""
        cmd = New OleDbCommand(sql1, conn)

        conn.Open()
        Dim r As OleDbDataReader = cmd.ExecuteReader

        If (r.HasRows) Then
            If (r.Read()) Then

                txtStaffID.Text = r("Candidate_ID").ToString
                txtStaffEmailID.Text = r("Candidate_Email_ID").ToString
                txtStaffPassword.Text = r("Candidate_Password").ToString
                txtStaffName.Text = r("Candidate_Name").ToString
                txtYop.Text = r("Candidate_YOP").ToString
                txtQualification.Text = r("Canadidate_Qualification").ToString
                txtStaffMobileNumber.Text = r("Candidate_Mobile_Number").ToString
                txtCandidateID.Text = r("Candidate_ID").ToString
            Else

                MsgBox("No rows found!")

            End If
        End If

        r.Close()
        conn.Close()


        Dim sql = "select a.Vacancy_Designation,b.Candidate_Photo,b.Candidate_Data,b.Candidate_Contenttype,b.Candidate_Password from Vacancy a,Candidate b where a.Vacancy_ID=b.Vacancy_ID and b.Candidate_ID=" & ListBox1.Text & ""
        cmd = New OleDbCommand(sql, conn)

        conn.Open()
        Dim r1 As OleDbDataReader = cmd.ExecuteReader

        If (r1.HasRows) Then
            If (r1.Read()) Then
                txtDesignation.Text = r1("Vacancy_Designation").ToString
                txtStaffPhoto.Text = r1("Candidate_Photo").ToString
                txtData.Text = r1("Candidate_Data").ToString
                txtContenttype.Text = r1("Candidate_Contenttype").ToString
                txtStaffPassword.Text = r1("Candidate_Password").ToString


                Dim pass As String = txtStaffPassword.Text
                txtStaffPassword.TextMode = TextBoxMode.Password
                txtStaffPassword.Attributes.Add("value", pass)
            Else
                MsgBox("No rows found!")

            End If
        End If

        r1.Close()
        conn.Close()

    End Sub


    Public Shared staffid As String
    Public status As String = "Done"
    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
  

        If ddPost.SelectedValue = "Director" Or ddPost.SelectedValue = "Principal" Or ddPost.SelectedValue = "Non Teaching Staff" Then

            Dim filename As String = Path.GetFileName(CandidatePhoto.PostedFile.FileName)
            Dim contentType As String = CandidatePhoto.PostedFile.ContentType

            Using fs As Stream = CandidatePhoto.PostedFile.InputStream

                Using br As BinaryReader = New BinaryReader(fs)

                    Dim bytes As Byte() = br.ReadBytes(CType(fs.Length, Int32))

                    Dim sql = "INSERT INTO [Staff] ([Staff_ID],[Staff_Email_ID],[Staff_Password],[Staff_Name],[Post],[Staff_Date_of_Joining],[Year_of_Exprience],[Qualification],[Staff_Mobile_Number],[Staff_Photo],[Data],[Contenttype]) VALUES (@Staff_ID,@Staff_Email_ID,@Staff_Password,@Staff_Name,@Post,@Staff_Date_of_Joining,@Year_of_Exprience,@Qualification,@Staff_Mobile_Number,@Staff_Photo,@Data,@Contenttype)"
                    cmd = New OleDbCommand(sql, conn)


                    'ADD PARAMETERS
                    cmd.Parameters.AddWithValue("@Staff_ID", txtStaffID.Text)
                    cmd.Parameters.AddWithValue("@Staff_Email_ID", txtStaffEmailID.Text)
                    cmd.Parameters.AddWithValue("@Staff_Password", txtStaffPassword.Text)
                    cmd.Parameters.AddWithValue("@Staff_Name", txtStaffName.Text)
                    cmd.Parameters.AddWithValue("@Post", ddPost.Text)

                    cmd.Parameters.AddWithValue("@Staff_Date_of_Joining", txtDateofJoining.Text)
                    cmd.Parameters.AddWithValue("@Year_of_Exprience", txtYop.Text)
                    cmd.Parameters.AddWithValue("@Qualification", txtQualification.Text)
                    cmd.Parameters.AddWithValue("@Staff_Mobile_Number", txtStaffMobileNumber.Text)
                    cmd.Parameters.Add("@Staff_Photo", OleDbType.Char).Value = filename
                    cmd.Parameters.Add("@Data", OleDbType.VarBinary).Value = bytes
                    cmd.Parameters.Add("@Contenttype", OleDbType.Char).Value = contentType



                    'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
                    Try
                        conn.Open()
                        If cmd.ExecuteNonQuery() > 0 Then
                            Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                            Dim meta As New HtmlMeta()
                            meta.HttpEquiv = "Refresh"
                            meta.Content = "0;url=Add Staff Detail.aspx"
                            Me.Page.Header.Controls.Add(meta)

                        End If
                        conn.Close()

                    Catch ex As Exception
                        MsgBox(ex.Message)
                        conn.Close()
                    End Try
                End Using
            End Using

        ElseIf ddPost.SelectedValue = "Teacher" Then

            Dim sql = "INSERT INTO [Staff] ([Staff_ID],[Staff_Email_ID],[Staff_Password],[Staff_Name],[Post],[Staff_Designation],[Teacher_Type],[Staff_Date_of_Joining],[Year_of_Exprience],[Qualification],[Staff_Mobile_Number],[Staff_Photo],[Data],[Contenttype],[Candidate_ID],[Staff_Status]) VALUES (@Staff_ID,@Staff_Email_ID,@Staff_Password,@Staff_Name,@Post,@Staff_Designation,@Teacher_Type,@Staff_Date_of_Joining,@Year_of_Exprience,@Qualification,@Staff_Mobile_Number,@Staff_Photo,@Data,@Contenttype,@Candidate_ID,@Staff_Status)"
            cmd = New OleDbCommand(sql, conn)

            'ADD PARAMETERS
            cmd.Parameters.AddWithValue("@Staff_ID", txtStaffID.Text)
            cmd.Parameters.AddWithValue("@Staff_Email_ID", txtStaffEmailID.Text)
            cmd.Parameters.AddWithValue("@Staff_Password", txtStaffPassword.Text)
            cmd.Parameters.AddWithValue("@Staff_Name", txtStaffName.Text)
            cmd.Parameters.AddWithValue("@Post", ddPost.Text)
            cmd.Parameters.AddWithValue("@Staff_Designation", txtDesignation.Text)
            cmd.Parameters.AddWithValue("@Teacher_Type", ddTeacherType.Text)
            cmd.Parameters.AddWithValue("@Staff_Date_of_Joining", txtDateofJoining.Text)
            cmd.Parameters.AddWithValue("@Year_of_Exprience", txtYop.Text)
            cmd.Parameters.AddWithValue("@Qualification", txtQualification.Text)
            cmd.Parameters.AddWithValue("@Staff_Mobile_Number", txtStaffMobileNumber.Text)
            cmd.Parameters.AddWithValue("@Staff_Photo", txtStaffPhoto.Text)
            cmd.Parameters.AddWithValue("@Data", txtData.Text)
            cmd.Parameters.AddWithValue("@Contenttype", txtContenttype.Text)
            cmd.Parameters.AddWithValue("@Candidate_ID", txtCandidateID.Text)
            cmd.Parameters.AddWithValue("@Staff_Status", status)

            'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
            Try
                conn.Open()

                If cmd.ExecuteNonQuery() > 0 Then
                    Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Add Staff Detail.aspx"
                    Me.Page.Header.Controls.Add(meta)

                    ' staffid = txtStaffID.Text
                    'Response.Redirect("Allocation Class.aspx")
                End If
                conn.Close()

            Catch ex As Exception

                conn.Close()
            End Try

        End If
    End Sub

    Protected Sub ImageButton3_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton3.Click
        Calendar3.Visible = True
    End Sub

    Private Sub Calendar3_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles Calendar3.DayRender
        If e.Day.Date.DayOfWeek = DayOfWeek.Saturday OrElse e.Day.Date.DayOfWeek = DayOfWeek.Sunday Then
            e.Day.IsSelectable = False
        End If

        If e.Day.Date.DayOfWeek = DayOfWeek.Saturday OrElse e.Day.Date.DayOfWeek = DayOfWeek.Sunday Then
            e.Cell.BackColor = System.Drawing.Color.Blue
            e.Cell.ForeColor = System.Drawing.Color.Black

        End If

    End Sub

    Protected Sub Calendar3_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar3.SelectionChanged
        txtDateofJoining.Text = Calendar3.SelectedDate.ToShortDateString()
        Calendar3.Visible = False
    End Sub

    
    Protected Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class