﻿Imports System.Data.OleDb

Public Class Forgot_Password
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
    End Sub

    Protected Sub CheckBox1_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            Dim pass As String = txtPassword.Text
            txtPassword.TextMode = TextBoxMode.Password
            txtPassword.Attributes.Add("value", pass)
        End If

        If CheckBox1.Checked Then
            txtPassword.TextMode = TextBoxMode.SingleLine
        End If

        If CheckBox1.Checked = False Then
            Dim pass As String = txtConfirmPassword.Text
            txtConfirmPassword.TextMode = TextBoxMode.Password
            txtConfirmPassword.Attributes.Add("value", pass)
        End If

        If CheckBox1.Checked Then
            txtConfirmPassword.TextMode = TextBoxMode.SingleLine
        End If
    End Sub

    Private Sub student()
       conn.Open()
        Dim str1 As String = "select * from Student where Student_Email_ID ='" & txtEmailID.Text & "'"
        Dim cmd As OleDbCommand = New OleDbCommand(str1, conn)
        Dim dr As OleDbDataReader = cmd.ExecuteReader()

        If dr.Read() Then


            Dim str As String = "update Student set Student_Password='" & txtPassword.Text & "'where Student_Password='" + txtConfirmPassword.Text & "'"
            Dim cmd1 As OleDbCommand = New OleDbCommand(str, conn)
            cmd1.ExecuteNonQuery()

            Response.Write("<script language=""javascript"">alert('Your Password has been changed successfully');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Forgot Password.aspx"
            Me.Page.Header.Controls.Add(meta)
        Else
            Response.Write("<script language=""javascript"">alert('Your Email ID is incorrect');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Forgot Password.aspx"
            Me.Page.Header.Controls.Add(meta)
        End If
        conn.Close()
    End Sub

    Private Sub staff()
      conn.Open()
        Dim str1 As String = "select * from Staff where Staff_Email_ID ='" & txtEmailID.Text & "'"
        Dim cmd As OleDbCommand = New OleDbCommand(str1, conn)
        Dim dr As OleDbDataReader = cmd.ExecuteReader()

        If dr.Read() Then


            Dim str As String = "update Staff set Staff_Password='" & txtPassword.Text & "'where Staff_Password='" + txtConfirmPassword.Text & "'"
            Dim cmd1 As OleDbCommand = New OleDbCommand(str, conn)
            cmd1.ExecuteNonQuery()

            Response.Write("<script language=""javascript"">alert('Your Password has been changed successfully');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Forgot Password.aspx"
            Me.Page.Header.Controls.Add(meta)
        Else
            Response.Write("<script language=""javascript"">alert('Your Email ID is incorrect');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Forgot Password.aspx"
            Me.Page.Header.Controls.Add(meta)
        End If
        conn.Close()

        Response.Redirect(Request.Url.AbsoluteUri)
    End Sub

    Private Sub admin()
        conn.Open()
        Dim str1 As String = "select * from Admin where Admin_Email_ID ='" & txtEmailID.Text & "'"
        Dim cmd As OleDbCommand = New OleDbCommand(str1, conn)
        Dim dr As OleDbDataReader = cmd.ExecuteReader()

        If dr.Read() Then


            Dim str As String = "update Admin set Admin_Password='" & txtPassword.Text & "'where Admin_Password= '" + txtConfirmPassword.Text & "'"
            Dim cmd1 As OleDbCommand = New OleDbCommand(str, conn)
            cmd1.ExecuteNonQuery()

            Response.Write("<script language=""javascript"">alert('Your Password has been changed successfully');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Forgot Password.aspx"
            Me.Page.Header.Controls.Add(meta)
        Else
            Response.Write("<script language=""javascript"">alert('Your Email ID is incorrect');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Forgot Password.aspx"
            Me.Page.Header.Controls.Add(meta)
        End If
        conn.Close()
    End Sub

    Private Sub candidate()
        conn.Open()
        Dim str1 As String = "select * from Candidate where Candidate_Email_ID ='" & txtEmailID.Text & "'"
        Dim cmd As OleDbCommand = New OleDbCommand(str1, conn)
        Dim dr As OleDbDataReader = cmd.ExecuteReader()

        If dr.Read() Then


            Dim str As String = "update Candidate set Candidate_Password='" & txtPassword.Text & "'where Candidate_Password= '" + txtConfirmPassword.Text & "'"
            Dim cmd1 As OleDbCommand = New OleDbCommand(str, conn)

            cmd1.ExecuteNonQuery()
            Response.Write("<script language=""javascript"">alert('Your Password has been changed successfully');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Forgot Password.aspx"
            Me.Page.Header.Controls.Add(meta)
        Else
            Response.Write("<script language=""javascript"">alert('Your Email ID is incorrect');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Forgot Password.aspx"
            Me.Page.Header.Controls.Add(meta)

        End If
        conn.Close()

    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        If ddUser.SelectedValue = "Admin" Then
            Call admin()
        ElseIf ddUser.SelectedValue = "Staff" Then
            Call staff()
        ElseIf ddUser.SelectedValue = "Candidate" Then
            Call candidate()
        ElseIf ddUser.SelectedValue = "Student" Then
            Call student()

        Else
            Response.Write("<script language=""javascript"">alert('Please Select User');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Forgot Password.aspx"
            Me.Page.Header.Controls.Add(meta)

        End If

    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
        Response.Redirect("Homepage.aspx")
    End Sub

   
End Class