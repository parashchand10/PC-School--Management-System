﻿Imports System.Data.OleDb

Public Class Add_Vacancy
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call Vacancy()

        Calendar1.Visible = False
        Calendar2.Visible = False
        txtVacancy.Visible = False
        txtVacancyID.Visible = False
        lblVacancy.Visible = False

        If Not IsPostBack Then

            BindGrid()
        End If
    End Sub

    Private Sub Vacancy()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(20000, 80000)  ' Get random numbers 
        txtVacancyID.Text = intResult.ToString
    End Sub

    'Bind Data with GridView Control
    Private Sub BindGrid()
        Dim sql = "SELECT [Vacancy_ID],[Vacancy_Designation],[Vacancy_Start_Date],[Vacancy_End_Date] FROM [Vacancy]"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        grid.DataSource = cmd.ExecuteReader()
        grid.DataBind()
        conn.Close()

    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        If Trim(txtVacancyEndDate.Text) > Trim(txtVacancyStartDate.Text) Then
            Dim sql1 = "INSERT INTO [Vacancy] ([Vacancy_ID],[Vacancy_Designation],[Vacancy_Start_Date],[Vacancy_End_Date]) VALUES (@Vacancy_ID,@Vacancy_Designation,@Vacancy_Start_Date,@Vacancy_End_Date)"
            cmd = New OleDbCommand(sql1, conn)


            'ADD PARAMETERS
            cmd.Parameters.AddWithValue("@Vacancy_ID", txtVacancyID.Text)
            cmd.Parameters.AddWithValue("@Vacancy_Designation", txtVacancyDesignation.Text)
            cmd.Parameters.AddWithValue("@Vacancy_Start_Date", txtVacancyStartDate.Text)
            cmd.Parameters.AddWithValue("@Vacancy_End_Date", txtVacancyEndDate.Text)

            'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
            Try
                conn.Open()
                If cmd.ExecuteNonQuery() > 0 Then
                    Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Add Vacancy.aspx"
                    Me.Page.Header.Controls.Add(meta)

                End If
                conn.Close()

            Catch ex As Exception
                MsgBox("Duplicate Data", vbInformation)
                conn.Close()
            End Try

        Else
            Response.Write("<script language=""javascript"">alert('Incorrect Date! Please Select Correct Date');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Add Vacancy.aspx"
            Me.Page.Header.Controls.Add(meta)

        End If

    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Calendar1.Visible = True
    End Sub

    Protected Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Calendar2.Visible = True
    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar1.SelectionChanged
        txtVacancyStartDate.Text = Calendar1.SelectedDate.ToShortDateString()
        Calendar1.Visible = False
    End Sub

    Protected Sub Calendar2_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar2.SelectionChanged
        txtVacancyEndDate.Text = Calendar2.SelectedDate.ToShortDateString()
        Calendar2.Visible = False
    End Sub


    Dim sql As String
    Private Sub grid_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grid.RowDeleting
        If MsgBox("Are you sure you want to delete " & Trim(txtVacancyDesignation.Text) & " ?", 4 + 32) = vbNo Then

        Else
            sql = "delete from [Vacancy] where [Vacancy_ID]=" & Trim(txtVacancy.Text) & ""
        End If

        cmd = New OleDbCommand(sql, conn)

        'ADD PARAMETERS
        cmd.Parameters.AddWithValue("@Vacancy_ID", txtVacancy.Text)
        cmd.Parameters.AddWithValue("@Vacancy_Designation", txtVacancyDesignation.Text)
        cmd.Parameters.AddWithValue("@Vacancy_Start_Date", txtVacancyStartDate.Text)
        cmd.Parameters.AddWithValue("@Vacancy_End_Date", txtVacancyEndDate.Text)

        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Removed');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Add Vacancy.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
            conn.Close()
        End Try

    End Sub

    Private Sub grid_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles grid.RowUpdating
        If Trim(txtVacancyEndDate.Text) > Trim(txtVacancyStartDate.Text) Then
            Dim sql = "update [Vacancy] set Vacancy_Designation='" & txtVacancyDesignation.Text & "',Vacancy_Start_Date='" & txtVacancyStartDate.Text & "',Vacancy_End_Date='" & txtVacancyEndDate.Text & "' where Vacancy_ID=" & txtVacancy.Text & ""
            cmd = New OleDbCommand(sql, conn)


            'ADD PARAMETERS

            cmd.Parameters.AddWithValue("@Vacancy_Designation", txtVacancyDesignation.Text)
            cmd.Parameters.AddWithValue("@Vacancy_Start_Date", txtVacancyStartDate.Text)
            cmd.Parameters.AddWithValue("@Vacancy_End_Date", txtVacancyEndDate.Text)


            'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
            Try
                conn.Open()
                If cmd.ExecuteNonQuery() > 0 Then
                    Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Add Vacancy.aspx"
                    Me.Page.Header.Controls.Add(meta)

                End If
                conn.Close()

            Catch ex As Exception
                MsgBox(ex.Message)
                conn.Close()
            End Try

        Else
            Response.Write("<script language=""javascript"">alert('Incorrect Date! Please Select Correct Date');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Add Vacancy.aspx"
            Me.Page.Header.Controls.Add(meta)

        End If

    End Sub

    Protected Sub grid_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles grid.SelectedIndexChanged
        Dim selectedRowIndex As Integer
        selectedRowIndex = grid.SelectedIndex
        Dim row As GridViewRow = grid.Rows(selectedRowIndex)

        txtVacancy.Text = row.Cells(0).Text
        txtVacancyDesignation.Text = row.Cells(1).Text
        txtVacancyStartDate.Text = row.Cells(2).Text
        txtVacancyEndDate.Text = row.Cells(3).Text
    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class