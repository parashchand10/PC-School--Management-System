﻿Imports System.Data.OleDb

Public Class Add_Admission_Detail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call Addmission()

        Calendar1.Visible = False
        Calendar2.Visible = False

        Label2.Visible = False
        txtAdmissionDetailID.Visible = False
        txtAdmissionDetail.Visible = False
    End Sub

    Private Sub Addmission()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(10000, 50000)  ' Get random numbers 
        txtAdmissionDetail.Text = intResult.ToString
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try

            If Trim(txtAdmissionEndDate.Text) > Trim(txtAdmissionStartDate.Text) Then

                Dim sql = "INSERT INTO [Admission Detail] ([Admission_Detail_ID],[Admission_Type],[Admission_Start_Date],[Admission_End_Date],[Admission_Amount]) VALUES (@Admission_Detail_ID,@Admission_Type,@Admission_Start_Date,@Admission_End_Date,@Admission_Amount)"
                cmd = New OleDbCommand(sql, conn)


                'ADD PARAMETERS
                cmd.Parameters.AddWithValue("@Admission_Detail_ID", txtAdmissionDetail.Text)
                cmd.Parameters.AddWithValue("@Admission_Type", ddAdmissionType.Text)
                cmd.Parameters.AddWithValue("@Admission_Start_Date", txtAdmissionStartDate.Text)
                cmd.Parameters.AddWithValue("@Admission_End_Date", txtAdmissionEndDate.Text)
                cmd.Parameters.AddWithValue("@Admission_Amount", txtAdmissionAmount.Text)

                'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
                Try
                    conn.Open()
                    If cmd.ExecuteNonQuery() > 0 Then
                        Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                        Dim meta As New HtmlMeta()
                        meta.HttpEquiv = "Refresh"
                        meta.Content = "0;url=Add Admission Detail.aspx"
                        Me.Page.Header.Controls.Add(meta)

                    End If
                    conn.Close()

                Catch ex As Exception
                    MsgBox(ex.Message)
                    conn.Close()
                End Try

            Else

                Response.Write("<script language=""javascript"">alert('Incorrect Date! Please Select Correct Date');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Add Admission Detail.aspx"
                Me.Page.Header.Controls.Add(meta)
            End If

        Catch ex As Exception

        End Try
    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Calendar1.Visible = True
    End Sub


    Private Sub ImageButton2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Calendar2.Visible = True
    End Sub

    Protected Sub Calendar1_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar1.SelectionChanged
        txtAdmissionStartDate.Text = Calendar1.SelectedDate.ToShortDateString()
        Calendar1.Visible = False
    End Sub

    Protected Sub Calendar2_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) Handles Calendar2.SelectionChanged
        txtAdmissionEndDate.Text = Calendar2.SelectedDate.ToShortDateString()
        Calendar2.Visible = False
    End Sub

    Protected Sub ddAdmissionType_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddAdmissionType.SelectedIndexChanged
        Dim sql11 = "SELECT * FROM [Admission Detail] where Admission_Type='" & ddAdmissionType.SelectedValue & "'"
        cmd = New OleDbCommand(sql11, conn)

        conn.Open()
        Dim r2 As OleDbDataReader = cmd.ExecuteReader

        If (r2.HasRows) Then
            If (r2.Read()) Then
                txtAdmissionDetailID.Text = r2("Admission_Detail_ID")
                ddAdmissionType.Text = r2("Admission_Type")
                txtAdmissionStartDate.Text = r2("Admission_Start_Date")
                txtAdmissionEndDate.Text = r2("Admission_End_Date")

            Else

                txtAdmissionAmount.Text = "No rows found!"

            End If
        End If

        r2.Close()
        conn.Close()


        Dim sql1 = "SELECT Admission_Fee FROM [Fee] where Admission_Fee=" & ddAdmissionType.SelectedValue & ""
        cmd = New OleDbCommand(sql1, conn)

        conn.Open()
        Dim r As OleDbDataReader = cmd.ExecuteReader

        If (r.HasRows) Then
            If (r.Read()) Then
                txtAdmissionAmount.Text = r("Admission_Fee")

            Else

                txtAdmissionAmount.Text = "No rows found!"

            End If
        End If

        r.Close()
        conn.Close()

        Dim sql = "SELECT Re_Admission_Fee FROM [Fee] where Re_Admission_Fee=" & ddAdmissionType.SelectedValue & ""
        cmd = New OleDbCommand(sql, conn)

        conn.Open()
        Dim r1 As OleDbDataReader = cmd.ExecuteReader

        If (r1.HasRows) Then
            If (r1.Read()) Then

                txtAdmissionAmount.Text = r1("Re_Admission_Fee")
            Else

                txtAdmissionAmount.Text = "No rows found!"

            End If
        End If

        r1.Close()
        conn.Close()

    End Sub



    Protected Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
        If Trim(txtAdmissionEndDate.Text) > Trim(txtAdmissionStartDate.Text) Then


            Dim sql = "update [Admission Detail] set Admission_Type='" & ddAdmissionType.Text & "',Admission_Start_Date='" & txtAdmissionStartDate.Text & "',Admission_End_Date='" & txtAdmissionEndDate.Text & "' where Admission_Detail_ID=" & txtAdmissionDetailID.Text & ""
            cmd = New OleDbCommand(sql, conn)

            'ADD PARAMETERS
            cmd.Parameters.AddWithValue("@Admission_Detail_ID", txtAdmissionDetailID.Text)
            cmd.Parameters.AddWithValue("@Admission_Type", ddAdmissionType.Text)
            cmd.Parameters.AddWithValue("@Admission_Start_Date", txtAdmissionStartDate.Text)
            cmd.Parameters.AddWithValue("@Admission_End_Date", txtAdmissionEndDate.Text)



            'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
            Try
                conn.Open()
                If cmd.ExecuteNonQuery() > 0 Then
                    Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Add Admission Detail.aspx"
                    Me.Page.Header.Controls.Add(meta)
                End If
                conn.Close()

            Catch ex As Exception
                MsgBox(ex.Message)
                conn.Close()
            End Try

        Else
            Response.Write("<script language=""javascript"">alert('Incorrect Date! Please Select Correct Date');</script>")
            Dim meta As New HtmlMeta()
            meta.HttpEquiv = "Refresh"
            meta.Content = "0;url=Add Admission Detail.aspx"
            Me.Page.Header.Controls.Add(meta)
        End If

    End Sub

    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class