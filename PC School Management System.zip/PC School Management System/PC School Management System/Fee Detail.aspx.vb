﻿Imports System.Data.OleDb

Public Class Fee_Detail
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call detail()
        
        txtFeeType.Text = "School Fee"

        lblFeeType.Visible = False
        txtFeeType.Visible = False

        txtCurrentDate.Visible = False
        txtDays.Visible = False
        txtTotalLateFee.Visible = False

        txtCurrentDate.Text = Date.Today.Date

        txtFeeID.Visible = False
        lblFeeID.Visible = False

        If txtFeeType.Text = "School Fee" Then
            lblAddFee.Visible = False
            txtAdmissionFee.Visible = False
            txtReAdmissionFee.Visible = False
            lblReAddFee.Visible = False
        End If

        txtClassID.Visible = False

    End Sub

    Private Sub detail()
        If Not Me.IsPostBack Then
            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then
                txtStudentID.Text = Request.QueryString("tmp1").ToString()
                Dim sql = "select a.Fee_ID,a.Class_Name,a.Admission_Fee,a.Re_Admission_Fee,a.Tution_Fee,a.Computer_Fee,a.Development_Fee,a.Late_Fee,a.Fee_Start_Date,a.Fee_End_Date,a.Quarterly_Period,a.Quarterly_Fee,a.Fee_Amount,a.Total_Fee,a.Total_Month_Period,a.Class_ID,b.Student_ID from [Fee] a,[StudentClass] b,[Student] c where a.Fee_ID=b.Fee_ID and b.Student_ID=c.Student_ID and c.Student_ID=" & txtStudentID.Text & ""
                cmd = New OleDbCommand(sql, conn)

                conn.Open()
                Dim r As OleDbDataReader = cmd.ExecuteReader

                If (r.HasRows) Then
                    If (r.Read()) Then
                        txtStudentID.Text = r("Student_ID").ToString()
                        txtFeeID.Text = r("Fee_ID").ToString()
                        txtClassStandard.Text = r("Class_Name").ToString()
                        txtAdmissionFee.Text = r("Admission_Fee").ToString()
                        txtReAdmissionFee.Text = r("Re_Admission_Fee").ToString()

                        txtTutionFee.Text = r("Tution_Fee").ToString()
                        txtComputerFee.Text = r("Computer_Fee").ToString()
                        txtDevelopmentFee.Text = r("Development_Fee").ToString()
                        txtLateFee.Text = r("Late_Fee").ToString()
                        txtStartDate.Text = r("Fee_Start_Date").ToString()
                        txtEndDate.Text = r("Fee_End_Date").ToString()
                        txtQuarterlyPeriod.Text = r("Quarterly_Period").ToString()
                        txtQuarterlyFee.Text = r("Quarterly_Fee").ToString()

                        txtFeeAmount.Text = r("Fee_Amount").ToString()
                        txtTotalFee.Text = r("Total_Fee").ToString()
                        txtTotalMonth.Text = r("Total_Month_Period").ToString()
                        txtClassID.Text = r("Class_ID").ToString()



                        txtClassID.Visible = False
                        lblFeeID.Visible = False
                        txtFeeID.Visible = False
                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r.Close()
                conn.Close()
            End If
        End If
    End Sub

    Public Shared a As String
    Public Shared b As String
    Public Shared c As String

    Public Sub fee()
        txtFeeType.Text = "School Fee"

        a = txtFeeType.Text
        c = txtQuarterlyPeriod.Text

        If txtCurrentDate.Text > txtEndDate.Text Then
            txtDays.Text = Val(txtCurrentDate.Text) - Val(txtEndDate.Text)
            txtTotalLateFee.Text = Val(txtFeeAmount.Text) + (Val(txtLateFee.Text) * Val(txtDays.Text))
            b = txtTotalLateFee.Text
        Else
            b = txtQuarterlyFee.Text
        End If
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Call fee()
        Response.Redirect("Fee Payment.aspx?tmp1=" + txtStudentID.Text)

    End Sub

   
    
    Protected Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class