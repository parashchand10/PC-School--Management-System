﻿Imports System.Data.OleDb

Public Class Staff_Detail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()

        Call d()

    End Sub

    Private Sub d()

        If Not Me.IsPostBack Then
            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then
                txtStaffID.Text = Request.QueryString("tmp1").ToString()

                Image1.ImageUrl = "Staff.ashx?ID=" + txtStaffID.Text
                Dim sql = "select a.Post,a.Staff_Email_ID,a.Staff_Password,a.Staff_Name,a.Staff_Designation,a.Teacher_Type,a.Staff_Date_of_Joining,a.Year_of_Exprience,a.Qualification,a.Staff_Mobile_Number,a.Staff_Photo,c.Class_ID,a.Staff_Class_Standard from [Staff] a,[Subject] b,[Class] c where b.Class_ID=c.Class_ID and b.Staff_ID=a.Staff_ID and a.Staff_ID=" & txtStaffID.Text & ""
                cmd = New OleDbCommand(sql, conn)

                conn.Open()
                Dim r As OleDbDataReader = cmd.ExecuteReader

                If (r.HasRows) Then
                    If (r.Read()) Then


                        txtPost.Text = r("Post").ToString
                        txtStaffEmailID.Text = r("Staff_Email_ID").ToString
                        txtStaffPassword.Text = r("Staff_Password").ToString
                        txtStaffName.Text = r("Staff_Name").ToString

                        txtStaffDesignation.Text = r("Staff_Designation").ToString
                        txtTeacherType.Text = r("Teacher_Type").ToString
                        txtDOJ.Text = r("Staff_Date_of_Joining").ToString
                        txtYOP.Text = r("Year_of_Exprience")
                        txtQualification.Text = r("Qualification").ToString
                        txtStaffMobileNumber.Text = r("Staff_Mobile_Number").ToString
                        txtStaffPhoto.Text = r("Staff_Photo").ToString
                        txtClassID.Text = r("Class_ID").ToString
                        txtClassStd.Text = r("Staff_Class_Standard").ToString
                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r.Close()
                conn.Close()
            End If
        End If


    End Sub


   

   

    Protected Sub cmdUpdate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdUpdate.Click
        If txtStaffID.Text = "" Then
            MsgBox("Enter Staff ID")
            Exit Sub
        End If

        Dim sql = "update [Staff] set Staff_Email_ID='" & txtStaffEmailID.Text & "',Staff_Password='" & txtStaffPassword.Text & "',Staff_Name='" & txtStaffName.Text & "',Staff_Mobile_Number='" & txtStaffMobileNumber.Text & "' where Staff_ID=" & txtStaffID.Text & ""
        cmd = New OleDbCommand(sql, conn)


        'ADD PARAMETERS
        cmd.Parameters.AddWithValue("@Staff_Email_ID", txtStaffEmailID.Text)
        cmd.Parameters.AddWithValue("@Staff_Password", txtStaffPassword.Text)
        cmd.Parameters.AddWithValue("@Staff_Name", txtStaffName.Text)
        cmd.Parameters.AddWithValue("@Staff_Mobile_Number", txtStaffMobileNumber.Text)



        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                MsgBox("Successfully Update")

            End If
            conn.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
            conn.Close()
        End Try
        Response.Redirect(Request.Url.AbsoluteUri)

    End Sub

  
    Protected Sub cmdAttendance_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdAttendance.Click
        Response.Redirect("Student Attendance.aspx?tmp1=" + txtClassStd.Text)
    End Sub

    Protected Sub cmdSalary_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSalary.Click
        Response.Redirect("Staff Salary.aspx?tmp1=" + txtStaffID.Text)
    End Sub

    Protected Sub cmdActivity_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdActivity.Click
        Response.Redirect("Student Detail.aspx?tmp1=" + txtClassStd.Text)
    End Sub

    Protected Sub cmdExpense_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExpense.Click
        Response.Redirect("Expense Detail.aspx")
    End Sub

    Protected Sub cmdCandidate_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCandidate.Click
        Response.Redirect("Candidate Selection.aspx")
    End Sub

    Protected Sub cmdStudentFeedback_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdStudentFeedback.Click
        Response.Redirect("Student Feedback.aspx")
    End Sub

    Protected Sub cmdSchoolFeedback_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSchoolFeedback.Click
        Response.Redirect("School Feedback.aspx")
    End Sub

    Protected Sub cmdFeePending_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdFeePending.Click
        Response.Redirect("Fee Pending.aspx")
    End Sub
End Class