﻿Imports System.Data.OleDb

Public Class Add_Feedback
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call feeback()
        Call detail()
        Call selectsubject()

        txtStudentID.Text = Student.feedback
        lblClass.Visible = False
        lblFeedback.Visible = False
        txtFeedbackID.Visible = False
        txtClassID.Visible = False
        txtStudentID.Visible = False
        txtStaffID.Visible = False
        txtSubjectID.Visible = False

    End Sub

    Private Sub feeback()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(10000, 50000)  ' Get random numbers 
        txtFeedbackID.Text = intResult.ToString
    End Sub

    Private Sub detail()
        If Not Me.IsPostBack Then
            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then

                txtClassID.Text = Request.QueryString("tmp1").ToString()

                Dim sql1 = "SELECT b.Class_Standard,b.Class_ID,a.Student_ID,a.Student_Name,c.Subject_ID FROM [Student] a,[Class] b,[Subject] c WHERE c.Class_ID=b.Class_ID AND b.Class_ID=a.Class_ID AND b.Class_ID=" & txtClassID.Text & ""
                cmd = New OleDbCommand(sql1, conn)

                conn.Open()
                Dim r1 As OleDbDataReader = cmd.ExecuteReader

                If (r1.HasRows) Then
                    If (r1.Read()) Then
                        txtClassStd.Text = r1("Class_Standard")
                        txtClassID.Text = r1("Class_ID")
                        txtStudentID.Text = r1("Student_ID")
                        txtStudentName.Text = r1("Student_Name")
                        txtSubjectID.Text = r1("Subject_ID")
                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r1.Close()
                conn.Close()
            End If
        End If

    End Sub

    Private Sub selectsubject()
        If Not Me.IsPostBack Then
            Using cmd As New OleDbCommand("select a.Subject_Name from Subject a,Class b where a.Class_ID=b.Class_ID and b.Class_ID=" & txtClassID.Text & "")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddSubject.DataSource = cmd.ExecuteReader()
                ddSubject.DataTextField = "Subject_Name"

                ddSubject.DataBind()
                conn.Close()
            End Using

            ddSubject.Items.Insert(0, New ListItem("--Select Subject Name--", "0"))

        End If
    End Sub

    

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        Try

        
        Using cmd As OleDbCommand = New OleDbCommand("SELECT Student_ID,Staff_ID,Subject_ID FROM [Student Feedback] WHERE Student_ID=@Student_ID AND Staff_ID=@Staff_ID AND Subject_ID=@Subject_ID", conn)
            cmd.CommandType = CommandType.Text
            cmd.Parameters.AddWithValue("@Student_ID", Me.txtStudentID.Text.Trim())
            cmd.Parameters.AddWithValue("@Staff_ID", Me.txtStaffID.Text.Trim())
            cmd.Parameters.AddWithValue("@Subject_ID", Me.txtSubjectID.Text.Trim())

            conn.Open()
            Dim result As String = Convert.ToString(cmd.ExecuteScalar())
            conn.Close()
            If String.IsNullOrEmpty(result) Then
                Insert(Me.txtFeedbackID.Text.Trim(), Me.txtClassStd.Text.Trim(), Me.rbQ1.Text.Trim(), Me.rbQ2.Text.Trim(), Me.rbQ3.Text.Trim(), Me.rbQ4.Text.Trim(), Me.rbQ5.Text.Trim(), Me.txtClassID.Text.Trim(), Me.txtStudentID.Text.Trim(), Me.txtStaffID.Text.Trim(), Me.txtSubjectID.Text.Trim())

                Response.Write("<script language=""javascript"">alert('Successfully Added');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Homepage.aspx"
                Me.Page.Header.Controls.Add(meta)
            Else
                Response.Write("<script language=""javascript"">alert('Record Already Exists');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Homepage.aspx"
                Me.Page.Header.Controls.Add(meta)
            End If
        End Using
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Insert(ByVal name As Integer, ByVal country1 As String, ByVal country2 As String, ByVal country4 As String, ByVal country5 As String, ByVal country6 As String, ByVal country7 As String, ByVal country8 As Integer, ByVal country9 As Integer, ByVal country10 As Integer, ByVal country11 As Integer)

        Using cmd As OleDbCommand = New OleDbCommand("INSERT INTO [Student Feedback] VALUES (@Feedback_ID,@Class_Standard,@Q1,@Q2,@Q3,@Q4,@Q5,@Class_ID,@Student_ID,@Staff_ID,@Subject_ID)", conn)
            cmd.CommandType = CommandType.Text

            cmd.Parameters.AddWithValue("@Feedback_ID", name)
            cmd.Parameters.AddWithValue("@Class_Standard", country1)
            cmd.Parameters.AddWithValue("@Q1", country2)
            cmd.Parameters.AddWithValue("@Q2", country4)
            cmd.Parameters.AddWithValue("@Q3", country5)
            cmd.Parameters.AddWithValue("@Q4", country6)
            cmd.Parameters.AddWithValue("@Q5", country7)
            cmd.Parameters.AddWithValue("@Class_ID", country8)
            cmd.Parameters.AddWithValue("@Student_ID", country9)
            cmd.Parameters.AddWithValue("@Staff_ID", country10)
            cmd.Parameters.AddWithValue("@Subject_ID", country11)
            conn.Open()
            cmd.ExecuteNonQuery()
            conn.Close()
        End Using

    End Sub

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

   
    Protected Sub ddTeacher_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddTeacher.SelectedIndexChanged
        Dim sql1 = "SELECT Staff_ID FROM [Staff] WHERE Staff_Name='" & ddTeacher.SelectedValue & "'"
        cmd = New OleDbCommand(sql1, conn)

        conn.Open()
        Dim r1 As OleDbDataReader = cmd.ExecuteReader

        If (r1.HasRows) Then
            If (r1.Read()) Then
                txtStaffID.Text = r1("Staff_ID")

            Else

                MsgBox("No rows found!")
            End If
        End If

        r1.Close()
        conn.Close()
    End Sub

    Protected Sub ddSubject_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddSubject.SelectedIndexChanged
        If ddSubject.SelectedValue <> "" Then

            Using cmd As New OleDbCommand("select c.Staff_Name from Subject a,Class b,Staff c where b.Class_ID=a.Class_ID and a.Staff_ID=c.Staff_ID and Post='Teacher' and a.Subject_Name='" & ddSubject.SelectedValue & "'")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()

                ddTeacher.DataSource = cmd.ExecuteReader()
                ddTeacher.DataTextField = "Staff_Name"

                ddTeacher.DataBind()
                conn.Close()

            End Using

            ddTeacher.Items.Insert(0, New ListItem("--Select Staff Name--", "0"))
        End If
    End Sub

End Class