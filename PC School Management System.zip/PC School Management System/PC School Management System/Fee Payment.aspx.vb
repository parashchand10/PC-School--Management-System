﻿Imports System.Data.OleDb

Public Class Fee_Payment
    Inherits System.Web.UI.Page

    Dim status As String = "Paid"
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call detail()
        Call detail1()
        Call payment()

        txtQuater.Visible = False

        txtFeeStatus.Text = "Paid"
        txtFeeStatus.Visible = False
        txtStudentFee.Visible = False

        txtPaymentDate.Text = Calendar1.TodaysDate.Date

        Calendar1.Visible = False

        txtPaymentID.Visible = False
        txtStudentID.Visible = False
        lblPayment.Visible = False
        lblStudent.Visible = False

        lblFee.Visible = False
        txtFeeID.Visible = False
        lblAdmission.Visible = False
        txtAdmissionID.Visible = False
        txtStudentFee.Visible = False

        If txtPaymentType.Text = "New Admission" Or txtPaymentType.Text = "ReAdmission" Then
            lblStudent.Visible = False
            lblFee.Visible = False
            txtStudentID.Visible = False
            txtFeeID.Visible = False
        End If

        If txtPaymentType.Text = "School Fee" Then
            lblAdmission.Visible = False
            txtAdmissionID.Visible = False
            cmdExit.Visible = False
        End If
    End Sub

   

    Private Sub payment()
        Dim rnd = New System.Random             ' Create an instance
        Dim intResult = rnd.Next(20000, 50000)  ' Get random numbers 
        txtPaymentID.Text = intResult.ToString

    End Sub

    Public Sub detail1()
        If Not Me.IsPostBack Then
            If Request.QueryString("tmp2") IsNot Nothing AndAlso Request.QueryString("tmp2") <> String.Empty Then
                txtAdmissionID.Text = Request.QueryString("tmp2").ToString()
                txtPaymentType.Text = Admission_Form.a
                txtPayAmount.Text = Admission_Form.b

            End If
        End If
    End Sub

    Private Sub detail()
        If Not Me.IsPostBack Then

            If Request.QueryString("tmp1") IsNot Nothing AndAlso Request.QueryString("tmp1") <> String.Empty Then
                txtStudentID.Text = Request.QueryString("tmp1").ToString()
                txtPaymentType.Text = Fee_Detail.a
                txtPayAmount.Text = Fee_Detail.b
                txtQuater.Text = Fee_Detail.c
                Dim sql = "select a.Fee_ID,b.Student_ID,b.StudentClass_ID from [Fee] a,[StudentClass] b where a.Fee_ID=b.Fee_ID and b.Student_ID=" & txtStudentID.Text & ""
                cmd = New OleDbCommand(sql, conn)

                conn.Open()
                Dim r As OleDbDataReader = cmd.ExecuteReader

                If (r.HasRows) Then
                    If (r.Read()) Then

                        txtFeeID.Text = r("Fee_ID").ToString()

                        txtStudentID.Text = r("Student_ID").ToString()

                        txtStudentFee.Text = r("StudentClass_ID").ToString()

                    Else

                        MsgBox("No rows found!")
                    End If
                End If

                r.Close()
                conn.Close()
            End If
        End If
    End Sub




    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        If txtPaymentType.Text = "School Fee" Then

            Dim sql = "INSERT INTO [Payment] ([Payment_ID],[Payment_Date],[Payment_Type],[Payment_Mode],[Pay_Amount],[Payment_Status],[Student_ID],[Fee_ID]) VALUES (@Payment_ID,@Payment_Date,@Payment_Type,@Payment_Mode,@Pay_Amount,@Payment_Status,@Student_ID,@Fee_ID)"
            cmd = New OleDbCommand(sql, conn)

            'ADD PARAMETERS

            cmd.Parameters.AddWithValue("@Payment_ID", txtPaymentID.Text)
            cmd.Parameters.AddWithValue("@Payment_Date", txtPaymentDate.Text)
            cmd.Parameters.AddWithValue("@Payment_Type", txtPaymentType.Text)
            cmd.Parameters.AddWithValue("@Payment_Mode", ddPaymentMode.Text)
            cmd.Parameters.AddWithValue("@Pay_Amount", txtPayAmount.Text)

           

            cmd.Parameters.AddWithValue("@Payment_Status", status)
            cmd.Parameters.AddWithValue("@Student_ID", txtStudentID.Text)
            cmd.Parameters.AddWithValue("@Fee_ID", txtFeeID.Text)

            conn.Open()
            cmd.ExecuteScalar()
            conn.Close()

            Dim sql1 = "update [StudentClass] set Fee_Status='" & txtFeeStatus.Text & "' where StudentClass_ID=" & txtStudentFee.Text & ""
            cmd = New OleDbCommand(sql1, conn)

            'ADD PARAMETERS

            cmd.Parameters.AddWithValue("@Fee_Status", txtFeeStatus.Text)

            'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION

            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Payment');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Homepage.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()


        ElseIf txtPaymentType.Text = "Admission_Fee" Or txtPaymentType.Text = "Re_Admission_Fee" Then

            Dim sql = "INSERT INTO [Payment] ([Payment_ID],[Payment_Date],[Payment_Type],[Payment_Mode],[Pay_Amount],[Payment_Status],[Admission_ID]) VALUES (@Payment_ID,@Payment_Date,@Payment_Type,@Payment_Mode,@Pay_Amount,@Payment_Status,@Admission_ID)"
            cmd = New OleDbCommand(sql, conn)

            'ADD PARAMETERS

            cmd.Parameters.AddWithValue("@Payment_ID", txtPaymentID.Text)
            cmd.Parameters.AddWithValue("@Payment_Date", txtPaymentDate.Text)
            cmd.Parameters.AddWithValue("@Payment_Type", txtPaymentType.Text)
            cmd.Parameters.AddWithValue("@Payment_Mode", ddPaymentMode.Text)
            cmd.Parameters.AddWithValue("@Pay_Amount", txtPayAmount.Text)


            cmd.Parameters.AddWithValue("@Payment_Status", status)
            cmd.Parameters.AddWithValue("@Admission_ID", txtAdmissionID.Text)

            'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION

            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Payment');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Homepage.aspx"
                Me.Page.Header.Controls.Add(meta)

            End If
            conn.Close()

        End If

    End Sub

    Dim Sql As String

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        If MsgBox("Are you sure you want to delete " & Trim(txtAdmissionID.Text) & " ?", 4 + 32) = vbNo Then

        Else
            Sql = "delete from [Admission] where [Admission_ID]=" & Trim(txtAdmissionID.Text) & ""
        End If


        cmd = New OleDbCommand(Sql, conn)


        'ADD PARAMETERS
        cmd.Parameters.AddWithValue("@Admission_ID", txtAdmissionID.Text)

        'OPEN CONNECTION And INSERT INTO DATABASE THEN CLOSE CONNECTION
        Try
            conn.Open()
            If cmd.ExecuteNonQuery() > 0 Then
                Response.Write("<script language=""javascript"">alert('Successfully Cancel');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Homepage.aspx"
                Me.Page.Header.Controls.Add(meta)

                cmdSubmit.Visible = False

            End If

        Catch ex As Exception

            conn.Close()
        End Try

    End Sub

End Class