﻿Imports System.Data.OleDb

Public Class Student_Detail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
        Call classst()
        Call year()

        If Not IsPostBack Then

            BindGrid()
        End If

        grid.Columns(1).Visible = False
        grid.Columns(5).Visible = False

        lblClass.Visible = False
        lblD.Visible = False
        lblDiv.Visible = False
        lblDivNum.Visible = False
        lblYear.Visible = False

        TextBox1.Visible = False
        txtClasss.Visible = False
        txtClasssID.Visible = False
        txtD.Visible = False
        txtDiv.Visible = False
        txtDivNum.Visible = False
        txtNewYear.Visible = False
        txtyear.Visible = False

        Dim a As Integer = Trim(DateTime.Now.Year.ToString().Substring(2))
        txtyear.Text = a
        If ddClass.SelectedValue = "Playgroup" Then
            txtDiv.Text = 1
            txtD.Text = txtyear.Text + txtDiv.Text
        ElseIf ddClass.SelectedValue = "Nursery" Then
            txtDiv.Text = 2
            txtD.Text = txtyear.Text + txtDiv.Text
        End If

        txtClasss.Text = txtDiv.Text
        Dim number As String = TextBox1.Text

    End Sub

    Private Sub classst()
        If Not Me.IsPostBack Then

            Using cmd As New OleDbCommand("SELECT [Class_Standard] FROM [Class]")
                cmd.CommandType = CommandType.Text
                cmd.Connection = conn
                conn.Open()
                ddClass.DataSource = cmd.ExecuteReader()
                ddClass.DataTextField = "Class_Standard"

                ddClass.DataBind()
                conn.Close()
            End Using

            ddClass.Items.Insert(0, New ListItem("--Select Class--", "0"))
        End If
    End Sub

    Private Sub BindGrid()
        Dim sql = " SELECT a.Student_ID,a.Student_Roll_Number,a.Acdemic_Year,a.Student_Name,a.Student_Address,a.Student_Caste,a.Student_Gender,a.Student_Date_of_Birth,a.Student_Mobile_Number,a.Student_Father_Name,a.Student_Mother_Name,b.Class_ID,b.Class_Standard FROM [Student] a,[Class] b WHERE b.Class_ID=a.Class_ID"
        cmd = New OleDbCommand(sql, conn)
        conn.Open()
        grid.DataSource = cmd.ExecuteReader()
        grid.DataBind()
        conn.Close()

    End Sub

    Private Sub year()
        Dim currentyyear, futureyear As Integer
        Dim thedate As Date = Date.Now
        currentyyear = thedate.Year
        thedate = thedate.AddYears(2)
        futureyear = thedate.Year
        'txtNewYear.Text = futureyear.ToString
        txtNewYear.Text = Date.Today.Year
    End Sub

    Protected Sub cmdSubmit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdSubmit.Click
        For Each gvrow As GridViewRow In grid.Rows
            Dim checkbox = TryCast(gvrow.FindControl("CheckBox1"), CheckBox)

            If checkbox.Checked Then
                Dim lbladds = TryCast(gvrow.FindControl("Label1"), Label)
                Dim lblrno = TryCast(gvrow.FindControl("lblrno"), Label)
                Dim lblacdemicyear = TryCast(gvrow.FindControl("lblacdemicyear"), Label)

                lblacdemicyear.Text = txtNewYear.Text

                cmd = New OleDbCommand("update Student set Acdemic_Year=" & Trim(lblacdemicyear.Text) & ", Student_Roll_Number=" & Trim(txtD.Text + lblrno.Text) & " where Student_ID=" & lbladds.Text & "", conn)

                cmd.Parameters.AddWithValue("Student_Roll_Number", Trim(txtD.Text + lblrno.Text))

                conn.Open()
                If cmd.ExecuteNonQuery() > 0 Then

                    Response.Write("<script language=""javascript"">alert('Successfully Changed');</script>")
                    Dim meta As New HtmlMeta()
                    meta.HttpEquiv = "Refresh"
                    meta.Content = "0;url=Student Detail.aspx"
                    Me.Page.Header.Controls.Add(meta)
                End If
                conn.Close()

            End If
        Next
    

    End Sub

    Protected Sub ddClass_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles ddClass.SelectedIndexChanged
        Dim dt As New DataTable()

        conn.Open()
        If ddClass.SelectedValue <> "" Then
            Dim cmd As New OleDb.OleDbCommand("SELECT a.Student_ID,a.Student_Roll_Number,a.Acdemic_Year,a.Student_Name,a.Student_Address,a.Student_Caste,a.Student_Gender,a.Student_Date_of_Birth,a.Student_Mobile_Number,a.Student_Father_Name,a.Student_Mother_Name,b.Class_ID,b.Class_Standard FROM [Student] a,[Class] b WHERE b.Class_ID=a.Class_ID AND b.Class_Standard=@Book", conn)
            cmd.Parameters.AddWithValue("@Book", ddClass.SelectedValue)
            Dim da As New OleDb.OleDbDataAdapter(cmd)
            da.Fill(dt)
        End If
        conn.Close()

        grid.DataSource = dt
        grid.DataBind()

    End Sub


    Protected Sub CheckAll(ByVal sender As Object, ByVal e As EventArgs)
        Dim chckheader As CheckBox = CType(grid.HeaderRow.FindControl("CheckBox2"), CheckBox)

        For Each row As GridViewRow In grid.Rows
            Dim chckrw As CheckBox = CType(row.FindControl("CheckBox1"), CheckBox)

            If chckheader.Checked = True Then
                chckrw.Checked = True
            Else
                chckrw.Checked = False
            End If
        Next
    End Sub

    Protected Sub cmdExit_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdExit.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub cmdFilter_Click(sender As Object, e As EventArgs) Handles cmdFilter.Click
        conn.Open()
        Dim da As OleDbDataAdapter = New OleDbDataAdapter(" SELECT a.Student_ID,a.Student_Roll_Number,a.Acdemic_Year,a.Student_Name,a.Student_Address,a.Student_Caste,a.Student_Gender,a.Student_Date_of_Birth,a.Student_Mobile_Number,a.Student_Father_Name,a.Student_Mother_Name,b.Class_ID,b.Class_Standard,c.Fee_ID,c.Quarterly_Fee,c.Fee_Start_Date,c.Fee_End_Date,c.Late_Fee FROM [Student] a,[Class] b,[Fee] c WHERE b.Class_ID=a.Class_ID AND c.Class_ID=b.Class_ID AND a.Student_Name like '%" & txtStudentName.Text & "%'", conn)
        Dim ds As DataSet = New DataSet()
        da.Fill(ds)
        grid.DataSource = ds
        grid.DataBind()

    End Sub

End Class