﻿Imports System.Data.OleDb

Public Class Admin_Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Call connection()
    End Sub

    Protected Sub CheckBox1_CheckedChanged(ByVal sender As Object, ByVal e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = False Then
            Dim pass As String = txtPassword.Text
            txtPassword.TextMode = TextBoxMode.Password
            txtPassword.Attributes.Add("value", pass)
        End If

        If CheckBox1.Checked Then
            txtPassword.TextMode = TextBoxMode.SingleLine
        End If
    End Sub

    Protected Sub cmdLogin_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdLogin.Click

        Try
            Dim cmd As New OleDbCommand("select * from Admin where Admin_Email_ID =@Admin_Email_ID and Admin_Password=@Admin_Password", conn)

            cmd.Parameters.AddWithValue("@Admin_Email_ID", txtEmailID.Text)
            cmd.Parameters.AddWithValue("@Admin_Password", txtPassword.Text)
            Dim da As New OleDbDataAdapter(cmd)
            Dim dt As New DataTable()
            da.Fill(dt)
            If dt.Rows.Count > 0 Then

                Response.Write("<script language=""javascript"">alert('Login Successfully');</script>")
                Dim meta As New HtmlMeta()
                meta.HttpEquiv = "Refresh"
                meta.Content = "0;url=Admin Detail.aspx?tmp1=" + txtEmailID.Text
                Me.Page.Header.Controls.Add(meta)
            Else
                Response.Write("<script language=""javascript"">alert('Invalid Login');</script>")
            End If

        Catch ex As Exception

        End Try
        conn.Close()

    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles LinkButton1.Click
        Response.Redirect("Forgot Password.aspx")
    End Sub

    Protected Sub cmdCancel_Click(ByVal sender As Object, ByVal e As EventArgs) Handles cmdCancel.Click
        Response.Redirect("Homepage.aspx")
    End Sub

End Class